/************************************************************************/
/*  Routines to process current input record.				*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef lint
static const char sccsid[] = "$Id: process_block.c,v 1.29 2014/09/15 23:23:35 doug Exp $ ";
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "qlib2.h"

#include "params.h"
#include "st_info.h"
#include "procs.h"
#include "externals.h"

static DATA_HDR *last_hdr;	/* header of last packet used.		*/
#define	RECORD_LIST_SIZE	100

/************************************************************************/
/*  process_block:							*/
/*	Process input record for output.				*/
/*									*/
/*  This may involve any or all of the following:			*/
/*  1.  Detecting and discarding duplicate records.			*/
/*  2.  Trimming data from either end of the record in order to satisfy	*/
/*	time interval or in order to splice data from different files	*/
/*	into the output stream (requires unpacking/repacking).		*/
/*  3.	Re-blocking the data into a different output blksize.  If the	*/
/*	output blksize is smaller than the input blksize, it requires	*/
/*	unpacking the data and repacking it into multiple records.	*/
/*  4.  Determining what blockettes get put into the output stream.	*/
/*  5.	Appending the resulting data and blockettes to output stream.	*/
/*									*/
/*  Return boolean to indicated whether data from this record was used.	*/
/************************************************************************/
int process_block 
   (ST_INFO	*st_p,		/* ptr to input stream info.		*/
    int		new_stream)	/* boolean flag - true if new stream.	*/
{
    INT_TIME	    exptime;
    ST_INFO	    *out = st_head_out.next;
    int		    seconds, usecs;
    double	    usecs_per_point;
    int		    begin_trim_pts;
    int		    end_trim_pts;
    int		    ntrim;
    double	    bdif, edif;
    int		    output_slew;
    int		    ok_to_merge;
    int		    x0, xm1, d0;
    int		    output_slew_threshold;
    char	    debug_buf[1024];
    static int	    same_stream_as_last = 0;
    int		    discard_packet = 0;
    int		    orig_blksize;
    int		    h;
    int		    steim_comp;
    RECORD_LIST	    record_list[RECORD_LIST_SIZE];
    BS		    *bs;		/* ptr to blockette structure.	*/
    int		    split_offset;	/* offset in data to split rec.	*/
    int		    data_type_out;
    int		    used_data = 0;


#if 0
    fprintf (stderr, "Entering process_block\n");   /*:: debug */
#endif
    if (qverify) {
	static EXT_TIME et;
	static INT_TIME it_prev;
	/* Verify channel information if requested.			*/
	/* Allow empty network field for pre-V2.3 SDR records.		*/
	if ((verify.station_flag && strcmp(st_p->cur_hdr->station_id, verify.station_id)) ||
	    (verify.network_flag && st_p->cur_hdr->network_id[0] && 
	     strcmp(st_p->cur_hdr->network_id, verify.network_id)) ||
	    (verify.channel_flag && strcmp(st_p->cur_hdr->channel_id, verify.channel_id)) ||
	    (verify.location_flag && strcmp(st_p->cur_hdr->location_id, verify.location_id))) 
	{
	    fprintf (info, "Error: file %s Found stream = %s.%s.%s.%s ",
		     verify.filename,
		     st_p->cur_hdr->station_id,
		     st_p->cur_hdr->network_id,
		     st_p->cur_hdr->channel_id,
		     st_p->cur_hdr->location_id);
	    fprintf (info, "expected = %s.%s.%s.%s\n",
		     (verify.station_flag) ? verify.station_id : "*",
		     (verify.network_flag) ? verify.network_id : "*",
		     (verify.channel_flag) ? verify.channel_id : "*",
		     (verify.location_flag) ? verify.location_id : "*");
	    exit(1);
	}
	/* Verify blksize if requested. */
	if (verify.blksize_flag && verify.blksize != st_p->cur_hdr->blksize) {
	    fprintf (info, "Error: file %s Found blksize = %d expected blksize = %d\n",
		     verify.filename, st_p->cur_hdr->blksize, verify.blksize);
	    exit(1);
	}
	/* Verify data format if requested. */
	if (verify.input_data_fmt_flag && verify.input_data_fmt != st_p->cur_hdr->data_type) {
	    fprintf (info, "Error: file %s Found data_format = %s ",
		     verify.filename, encode_data_format(st_p->cur_hdr->data_type));
	    fprintf (info, "expected data_format %s\n",
		     encode_data_format(verify.input_data_fmt));
	    exit(1);
	}
	/* Verify date if requested. */
	et = int_to_ext(st_p->cur_hdr->begtime);
	if ((verify.year_flag && et.year != verify.year) || 
	    (verify.doy_flag && et.doy != verify.doy) ||
	    (verify.month_flag && et.month != verify.month) ||
	    (verify.day_flag && et.day != verify.day) ||
	    (verify.hour_flag && et.hour != verify.hour) ||
	    (verify.minute_flag && et.minute != verify.minute)) 
	{
	    fprintf (info, "Error: file %s Found year=%d doy=%03d month=%02d day=%02d hour=%02d minute=%02d\n",
		     verify.filename, 
		     et.year, et.doy, et.month, et.day, et.hour, et.minute);
	    exit(1);
	}
	/* Verify explicit timespan if requested. */
	if (verify.start_flag && tdiff(st_p->cur_hdr->begtime,verify.start_time)<0) {
	    fprintf (info, "Error: file %s Found record time %s ",
		     verify.filename, time_to_str(st_p->cur_hdr->begtime,date_fmt));
	    fprintf (info, "before start time %s\n",
		     time_to_str(verify.start_time,date_fmt));
	    exit(1);
	}
	if (verify.end_flag && tdiff(st_p->cur_hdr->begtime,verify.end_time)>=0) {
	    fprintf (info, "Error: file %s Found record time %s ",
		     verify.filename, time_to_str(st_p->cur_hdr->begtime,date_fmt));
	    fprintf (info, "after end time %s\n",
		     time_to_str(verify.end_time,date_fmt));
	    exit(1);
	}
	/* Verify record quality if requested. */
	/* Use first record type found if none specified. */
	if (verify.record_type == ' ') verify.record_type = st_p->cur_hdr->record_type;
	if (verify.record_type && verify.record_type != st_p->cur_hdr->record_type) {
	    fprintf (info, "Error: file %s Found record_type = %c ",
		     verify.filename, st_p->cur_hdr->record_type);
	    fprintf (info, "expected record_type %c\n",
		     verify.record_type);
	    exit(1);
	}
	/* Verify time order (always done). */
	if (st_p->cur_hdr->sample_rate == 0 || st_p->cur_hdr->num_samples == 0) {
	    /* Non-data records can have the same timestamp. */
	    if (it_prev.year != 0 && tdiff (st_p->cur_hdr->begtime, it_prev) < 0) {
		fprintf (info, "Error: file %s Time order: %s followed by %s\n",
			 verify.filename, 
			 strdup(time_to_str(it_prev, date_fmt)),
			 strdup(time_to_str(st_p->cur_hdr->begtime, date_fmt)));
		exit(1);
	    }
	}
	else {
	    if (it_prev.year != 0 && tdiff (st_p->cur_hdr->begtime, it_prev) <= 0) {
	    /* Data records must have monotonically increasing timestamps. */
		fprintf (info, "Error: file %s Time order: %s followed by %s\n",
			 verify.filename, 
			 strdup(time_to_str(it_prev, date_fmt)),
			 strdup(time_to_str(st_p->cur_hdr->begtime, date_fmt)));
		exit(1);
	    }
	}
	it_prev = st_p->cur_hdr->begtime;
    }	/* End of qverify */

    /* Allocate buffers based on the size of this block.		*/
    /* Allocate the max size buffer for unpacked data for this block.	*/
    max_num_samples = st_p->cur_hdr->num_samples;
    if (databuff == NULL &&
        (databuff = (char *)malloc(max_num_samples * sizeof(double))) == NULL ) {
 	fprintf (stderr, "Error: unable to malloc databuff\n");
	exit(1);       
    }

    if (tmpbuff == NULL &&
        (tmpbuff = (char *)malloc(max_num_samples * sizeof(double))) == NULL ) {
 	fprintf (stderr, "Error: unable to malloc tmpbuff\n");
	exit(1);       
    }

    if (diffbuff == NULL && 
	(diffbuff = (int *)malloc(max_num_samples * sizeof(int))) == NULL ) {
	fprintf (stderr, "Error: unable to malloc diffbuff\n");
	exit(1);
    }

    if (new_stream) same_stream_as_last = 0;
    memset(record_list, 0, sizeof(record_list));

    /* Save place for original block into in record_list[0], but put it */
    /* in record_list[1].  We need to do this because we may have to 	*/  
    /* unpack and repack the data from this block into multiple blocks	*/
    /* due to trimming the data, changing blocksize, etc.		*/
    /* Process block starting with record_list[1].			*/
    /* Save the original block info later in record_list[0] if needed.	*/
    orig_blksize = st_p->blksize;
    record_list[0].hdr = NULL;
    record_list[0].iob = NULL;
    record_list[1].hdr = st_p->cur_hdr;
    record_list[1].iob = st_p->iob;
#if FOO    
    data_type_out = output_data_fmt;

#else
    data_type_out = st_p->cur_hdr->data_type;
#endif
    h = 1;

    /* Dump original input record */
    if (debug(DEBUG_HDRS)) {
	dump_hdr (record_list[h].hdr, debug_buf, date_fmt);
	fprintf (info, debug_buf);
	fflush (info);
    }

    while ((st_p->cur_hdr = record_list[h].hdr, st_p->iob = record_list[h].iob) != NULL) {
	/* Ensure that all headers for the output stream are 		*/
	/* allocated and initialized.					*/
	int same_rate = 0;
	int compatible_formats = 0;
	out = st_head_out.next;
	if (out->sum_hdr == NULL) make_out_sum_hdr(out, st_p);
	if (out->cur_hdr == NULL) make_out_cur_hdr(out);

	/* Perform sanity checks on the input stream.		*/
	same_rate = same_rate_data_stream (record_list[h].hdr, out->sum_hdr);
	if ((! same_type_data_stream (record_list[h].hdr, out->sum_hdr)) ||
	    ((! ignore_rate) && (! same_rate))) {
	    if (multichannel) {
		out = flush_file(out,0);
		if (out->sum_hdr == NULL) make_out_sum_hdr(out, st_p);
		if (out->cur_hdr == NULL) make_out_cur_hdr(out);
		continue;
	    }
	    fprintf (info, "Error: input block for different stream than output stream\n");
	    fprintf (info, "output = %s.%s.%s.%s ",
		    out->sum_hdr->station_id, out->sum_hdr->network_id,
		    out->sum_hdr->channel_id, out->sum_hdr->location_id);
	    if (out->sum_hdr->sample_rate_mult == 1)
		fprintf (info, "rate=%d, ", out->sum_hdr->sample_rate);
	    else
		fprintf (info, "rate=%.4lf, ", sps_rate(out->sum_hdr->sample_rate,
						       out->sum_hdr->sample_rate_mult));
	    fprintf (info, "input = %s.%s.%s.%s ",
		    record_list[h].hdr->station_id, record_list[h].hdr->network_id,
		    record_list[h].hdr->channel_id, record_list[h].hdr->location_id);
	    if (record_list[h].hdr->sample_rate_mult == 1)
		fprintf (info, "rate=%d\n", record_list[h].hdr->sample_rate);
	    else
		fprintf (info, "rate=%.4lf\n", sps_rate(record_list[h].hdr->sample_rate,
						       record_list[h].hdr->sample_rate_mult));
	    fflush (info);
	    exit(1);
	}

	/* Check for compatible input and output data formats.		*/
	/* Different STEIM data formats are compatible with each other.	*/
	compatible_formats = 
	    output_data_fmt != UNKNOWN_DATATYPE ||
	    out->cur_hdr->data_type == UNKNOWN_DATATYPE ||
	    out->cur_hdr->data_type == record_list[h].hdr->data_type ||
	    (IS_STEIM_COMP(out->cur_hdr->data_type) && IS_STEIM_COMP(record_list[h].hdr->data_type));
	if (! compatible_formats) {
	    if (multichannel) {
		out = flush_file(out,0);
		if (out->sum_hdr == NULL) make_out_sum_hdr(out, st_p);
		if (out->cur_hdr == NULL) make_out_cur_hdr(out);
		continue;
	    }
	    fprintf (info, "Error: input data format %s != ", 
		     encode_data_format(record_list[h].hdr->data_type));
	    fprintf (info, "output data format %s.\n",
		     encode_data_format(out->cur_hdr->data_type));
	    exit(1);
	}

	/* Don't continue if we have a non-data file. */
	if (qverify && (record_list[h].hdr->sample_rate == 0 || 
			record_list[h].hdr->num_samples == 0)) {
	    break;
	}

	begin_trim_pts = end_trim_pts = 0;
	bdif = edif = 0;
	if ((bs=find_blockette(st_p->cur_hdr, 100))) {
	    double actual_rate, dusecs;
	    BLOCKETTE_100 *b = (BLOCKETTE_100 *) bs->pb;
	    if (bs->wordorder != my_wordorder) {
		swab_blockette (bs->type, bs->pb, bs->len);
		bs->wordorder = my_wordorder;
	    }
	    actual_rate = b->actual_rate;
	    dusecs = ((double)(1.0/actual_rate))*USECS_PER_SEC;
	    usecs_per_point = dusecs;
	}
	else {
	    time_interval2 (1,record_list[h].hdr->sample_rate,
			    record_list[h].hdr->sample_rate_mult,
			    &seconds,&usecs);
	    usecs_per_point = (double)seconds * USECS_PER_SEC + usecs;
	}

	/* 1.  If packet starts before start_time, compute # of points	*/
	/* to trim from the beginning of the input data.		*/

	if ((out->sum_hdr->num_samples == 0) && start_flag && (exact_trim) && 
	    ((bdif = tdiff(record_list[h].hdr->begtime,start_time)) < 0)) 
	    begin_trim_pts = ((-1*bdif) < DIHUGE) ? 
		ceil(-1*bdif/(double)usecs_per_point) :
	    record_list[h].hdr->num_samples;

	/* 2.  If packet ends at or after end_time, compute # of points	*/
	/* to trim from the end of the input data.			*/

	if (end_flag && (exact_trim) && 
	    ((edif = tdiff(record_list[h].hdr->endtime,end_time)) >= 0)) 
	    end_trim_pts = (edif < DIHUGE) ?
		ceil((edif+1)/(double)usecs_per_point) :
	    record_list[h].hdr->num_samples;

	/* 2a. Perform timespan calculations if we are breaking the 	*/
	/* output into separate files based on a duration.		*/
	split_offset = 0;
	if (file_duration) {
	    if (! init_duration) compute_duration (record_list[h].hdr);
	    if (after_duration (record_list[h].hdr)) {
		out = flush_file(out,1);
		if (out->sum_hdr == NULL) make_out_sum_hdr(out, st_p);
		if (out->cur_hdr == NULL) make_out_cur_hdr(out);
		compute_duration (record_list[h].hdr);
	    }
	    if (exact_trim && cross_duration (record_list[h].hdr)) {
		split_offset = intersect_duration (record_list[h].hdr);
	    }
	}

	/* 3.  If we already have any output data, check to see if 	*/
	/* there is any time slew between the expected time and the 	*/
	/* actual start of this packet.  If so, determine:		*/
	/* a.  Do we have to trim any points from the beginning of the	*/
	/* data to minimize the time slew?  If so, calculate new slew.	*/
	/* b.  Do we now have to start a new output packet?		*/

	if (out->sum_hdr->num_samples > 0 && record_list[h].hdr->num_samples > 0) {
	    /*  Calculate expected time of next point.			*/
	    exptime = add_dtime (out->sum_hdr->endtime, usecs_per_point);
	    bdif = tdiff (record_list[h].hdr->begtime, exptime);
	    if (bdif >= 0) {
		/* Positive time diff implies a gap between expected 	*/
		/* time and the beginning time of the input packet.	*/
		/* There is no way to reduce the gap.			*/
	    }
	    else {
		/* Negative time diff implies an overlap between	*/
		/* expected time and beginning time of the input packet.*/
		/* Compute the maximum number of points to trim such 	*/
		/* that the new bdif < 1 sample point difference.	*/
		/* We have 3 possibilities here:			*/
		/* 1.  We have truely overlapping data (from different	*/
		/* input files, and we must  trim the overlapping data.	*/
		/* 2.  We have a duplicate packet (should NEVER happen,	*/
		/* but it has ...).					*/
		/* 3.  Timing slew or clock reset, where data points are*/
		/* actually contiguous, but appear not to be contiguous.*/
		/* NOTE 1: If overlap ocurrs within a stream or between	*/
		/* the last block and the first block in a new stream 	*/
		/* with consecutive block sequence numbers, assume it 	*/
		/* to be one of the following time slews and		*/
		/* DO NOT TRIM it.					*/
		/* a.  small time slew due to clock adjustment.		*/
		/* b.  larger time overlap due to clock reset.		*/
		/* c.  duplicate blocks in data stream.  (This is the 	*/
		/* ONLY time we discard data for a negative slew	*/
		/* within a single input file.)				*/
		/* Otherwise, it is presumed to be overlapping data, 	*/
		/* and should be trimmed to the nearest point.		*/
		/* NOTE 2: If user has manually indicated that all data	*/
		/* is unique, then suppressed overlap trimming because	*/
		/* there is no duplicate data,				*/
		/* DO NOT TRIM it.					*/
		begin_trim_pts = roundoff(dsamples_in_time2(record_list[h].hdr->sample_rate,
							    record_list[h].hdr->sample_rate_mult,
							   -1*bdif));
		if (begin_trim_pts > 0) {
		    /* Discard duplicate packets.  It should NEVER	*/
		    /* happen but it has.				*/
		    if (unique_flag) {
			fprintf (info, "Warning: data overlap: seq=%d, expected_time=%s, ",
				 record_list[h].hdr->seq_no, time_to_str(exptime,date_fmt));
			fprintf (info, "packet_time=%s, overlap= %.1lf msec, input=%s\n", 
				 time_to_str(record_list[h].hdr->begtime,date_fmt), 
				 (double)(bdif/USECS_PER_MSEC), st_p->filename);
			fflush (info);
			begin_trim_pts = 0;
		    }
		    if ( st_p->prev_hdr && hdr_cmp(record_list[h].hdr,st_p->prev_hdr)==0 ) {
			if (! new_stream) {
			    dump_hdr (record_list[h].hdr, debug_buf, date_fmt);
			    fprintf (info, "Warning: discard dup packet based on identical hdr, %s",
				     debug_buf);
			    fflush (info);
			}
			++discard_packet;
		    }
		    else if ( last_hdr && hdr_cmp(record_list[h].hdr,last_hdr)==0 ) {
			if (! new_stream) {
			    dump_hdr (record_list[h].hdr, debug_buf, date_fmt);
			    fprintf (info, "Warning: discard dup packet based on identical "
				     "last_hdr, %s", debug_buf);
			    fflush (info);
			}
			++discard_packet;
		    }
		    else if ( last_hdr && last_hdr->seq_no == record_list[h].hdr->seq_no &&
			      tdiff(last_hdr->endtime,record_list[h].hdr->endtime) == 0. ) {
			if (! new_stream) {
			    dump_hdr (record_list[h].hdr, debug_buf, date_fmt);
			    fprintf (info, "Warning: discard dup packet based on identical "
				     "endtime, %s", debug_buf);
			    fflush (info);
			}
			++discard_packet;
		    }
		    else if ( (new_stream && !st_p->used && last_hdr && 
			       (last_hdr->seq_no+1 == record_list[h].hdr->seq_no)) ||
			      (same_stream_as_last && last_hdr && 
			       (last_hdr->seq_no+1 == record_list[h].hdr->seq_no)) ) {
			if (! new_stream) {
			    fprintf (info, "Warning: data overlap: seq=%d, expected_time=%s, ",
				     record_list[h].hdr->seq_no, time_to_str(exptime,date_fmt));
			    fprintf (info, "packet_time=%s, overlap= %.1lf msec, input=%s\n", 
				     time_to_str(record_list[h].hdr->begtime,date_fmt), 
				     (double)(bdif/USECS_PER_MSEC), st_p->filename);
			    fflush (info);
			}
			begin_trim_pts = 0;
		    }
		}
	    }
	}
	else bdif = 0;

	/* 4.  Determine whether we can use any of this input block.	*/
	if ((ntrim = begin_trim_pts + end_trim_pts) < record_list[h].hdr->num_samples ||
	    record_list[h].hdr->blksize > out->blksize || 
	    record_list[h].hdr->num_samples == 0 ||
/*::	    record_list[h].hdr->data_wordorder != out->cur_hdr->data_wordorder || ::*/
	    split_offset != 0) {
	    /*  We can use some (or all) points in the input block.	*/
	    used_data = 1;

	    /*  Save a copy of this header for reference next time.	*/
	    if (record_list[h].hdr->num_samples > 0 && ntrim < record_list[h].hdr->num_samples) {
		if (last_hdr) free_data_hdr(last_hdr);
		last_hdr = dup_data_hdr(record_list[h].hdr);
		if (last_hdr == NULL) {
		    fprintf (info, "Error: duplicating data_hdr\n");
		    exit(1);
		}
		same_stream_as_last = 1;
	    }

	    if (verify_data && verify_block(st_p) == UNKNOWN_DATATYPE && 
		record_list[h].hdr->num_samples > 0) {
		++discard_packet;
		if (qverify) {
		    fprintf (info, "Error: file %s Unknown datatype or compression error\n",
			     verify.filename);
		    exit(1);
		}
		break;
	    }
	    if (ntrim > 0 || record_list[h].hdr->blksize > out->blksize || split_offset > 0 || 
		record_list[h].hdr->data_wordorder != out->cur_hdr->data_wordorder ||
		(output_data_fmt != UNKNOWN_DATATYPE &&
		 record_list[h].hdr->data_type != output_data_fmt)) {

		/* Save original record and IOB if not already saved.	*/
		if (record_list[0].hdr == NULL) {
		    record_list[0].hdr = dup_data_hdr(record_list[h].hdr);
		    if (record_list[0].hdr == NULL) {
			fprintf (info, "Error: duplicating data_hdr\n");
			exit(1);
		    }
		    record_list[0].iob = dup_iob(record_list[h].iob);
		}
		trim_data (st_p, begin_trim_pts, end_trim_pts, split_offset, 0, 0, out->blksize, 
			   data_type_out, &record_list[h], RECORD_LIST_SIZE-h);
		/* It is possible that we trimmed all data and have no more record. */
		if (debug(DEBUG_STREAM)) {
		    if (record_list[h].hdr) {
			fprintf (info, "in:  trimmed to %d points (%s thru ",
				 record_list[h].hdr->num_samples,
				 time_to_str(record_list[h].hdr->begtime,date_fmt));
			fprintf (info, "%s)\n", 
				 time_to_str(add_dtime(record_list[h].hdr->endtime,usecs_per_point),date_fmt));
		    }
		    else {
			fprintf (info, "in:  trimmed to 0 points\n");
		    }
		    fflush (info);
		}
		if (record_list[h].hdr == NULL && h == 1) ++discard_packet;
		if (split_offset || record_list[h].hdr == NULL) {
		    continue;
		}
		/*	Recalculate bdif if we already have output.		*/
		if (out->sum_hdr->num_samples > 0) 
		    bdif = tdiff (record_list[h].hdr->begtime, exptime);
		if (verify_data && verify_block(st_p) == UNKNOWN_DATATYPE) {
		    ++discard_packet;
		    if (qverify) {
			fprintf (info, "Error: file %s Unknown datatype or compression error\n",
				 verify.filename);
			exit(1);
		    }
		    break;
		}
	    }
	    /* Do not let "small" data overlap split in output stream.	*/
	    if (same_rate && (fabs(bdif) < DIHUGE && (bdif <= 0 || bdif < tol(out->cur_hdr->sample_rate, out->cur_hdr->sample_rate_mult)))) {
		/* Since we think that this is supposedly a "continuous" data	*/
		/* stream, check to see that X0 diff of new block is based on	*/
		/* XN of the previous block.					*/

		steim_comp = IS_STEIM_COMP(record_list[h].hdr->data_type);
		if (steim_comp && out->sum_hdr->num_samples > 0 && 
		    record_list[h].hdr->num_samples > 0) {
		    xm1 = (out->cur_hdr->num_samples > 0) ? out->cur_hdr->xn :
			out->sum_hdr->xn;
		    /*  Get the first data value and first difference.	*/
		    /*  If we have already verified this block by unpacking	*/
		    /*  it, then we already have the first data value and	*/
		    /*  the first difference.				*/
		    /*  Otherwise, we have to unpack the first difference.	*/
		    if (! verify_data) {
			if (get_first_info(st_p, &x0, &d0) == UNKNOWN_DATATYPE) {
			    ++discard_packet;
			    if (qverify) {
				fprintf (info, "Error: file %s Unknown datatype or compression error\n",
					 verify.filename);
				exit(1);
			    }
			    break;
			}
		    }
		    else { 
			d0 = *diffbuff; 
			x0 = *(int*)databuff; 
		    }
		    if (d0 + xm1 != x0) {
			if ( !(ignore_d0_errors || ignore_d0_fixing) ) {
			    fprintf (info, "Warning: seq=%d X0 is %d, calculated value is %d, "
				     "diff value = %d, fixing\n",
				     record_list[h].hdr->seq_no, x0, d0 + xm1, d0);
			    fflush (info);
			}
			if (!ignore_d0_fixing || orig_blksize != out->blksize) {
			    if (record_list[h+1].hdr != NULL && file_duration) {
				/* 2007/08/30 If we have already have broken this record	*/
				/* into multiple records (ie record_list[h+1].hdr != NULL)	*/
				/* we have to compute the duration and split_offset based	*/
				/* on all of the remaining data in the multiple records.	*/
				/* Otherwise, we may re-merge records that were split due	*/
				/* to duration boundaries.					*/
				DATA_HDR *hdr;
				int i = h;
				hdr = dup_data_hdr(record_list[h].hdr);
				while (record_list[++i].hdr) {
				    hdr->num_samples += record_list[i].hdr->num_samples;
				    hdr->endtime = record_list[i].hdr->endtime;
				}
				init_duration = 0;
				if (! init_duration) compute_duration (hdr);
				if (after_duration (hdr)) {
				    out = flush_file(out,1);
				    if (out->sum_hdr == NULL) make_out_sum_hdr(out, st_p);
				    if (out->cur_hdr == NULL) make_out_cur_hdr(out);
				    compute_duration (hdr);
				}
				if (exact_trim && cross_duration (hdr)) {
				    split_offset = intersect_duration (hdr);
				}
				free_data_hdr(hdr);
			    }
			    /* Save original record and IOB if not already saved.	*/
			    if (record_list[0].hdr == NULL) {
				record_list[0].hdr = dup_data_hdr(record_list[h].hdr);
				if (record_list[0].hdr == NULL) {
				    fprintf (info, "Error: duplicating data_hdr\n");
				    exit(1);
				}
				record_list[0].iob = dup_iob(record_list[h].iob);
			    }
			    trim_data (st_p, 0, 0, split_offset, 1, x0-xm1, out->blksize, 
				       data_type_out, &record_list[h], RECORD_LIST_SIZE-h);
			    if (record_list[h].hdr->num_samples == 0) {
				++discard_packet;
				break;
			    }
			} 
			else {
			}
		    }
		}

		/* We are within tolerance for "continuous data".		*/
		/* Decide whether to pack the data into the current output	*/
		/* block, or whether to start a new block.			*/
		/* NOTE:	SPECIAL CASE FOR 80 SPS:			*/
		/* Ignore small msec jitter, since this is often caused by the	*/
		/* limited 1 msec accuracy of the Quanterra SHEAR timestamp.	*/
		/* Output slew is defined only by slew between output data 	*/
		/* data blocks.							*/

		output_slew = 0;
		output_slew_threshold = merge_tol(out->cur_hdr->sample_rate,
						  out->cur_hdr->sample_rate_mult);
		if (record_list[h].hdr->data_type == UNKNOWN_DATATYPE && 
		    record_list[h].hdr->num_samples > 0) {
		    if (verify_block(st_p) == UNKNOWN_DATATYPE) {
			++discard_packet;
			if (qverify) {
			    fprintf (info, "Error: file %s Unknown datatype or compression error\n",
				     verify.filename);
			    exit(1);
			}
			break;
		    }
		}
		if (add_required_blockettes(record_list[h].hdr) != 0) {
		    fprintf (info, "Error: adding require blockettes\n");
		    exit(1);
		}
		delete_unwanted_blockettes(record_list[h].hdr);
		ok_to_merge =  merge_check (out->cur_hdr, record_list[h].hdr, 
					    output_slew_threshold, bdif);
		if (! ok_to_merge) output_slew = bdif;

		/* If input record and output streams are different	*/
		/* data types, reprocess current record and convert it.	*/
		if (output_data_fmt != UNKNOWN_DATATYPE &&
		    record_list[h].hdr->data_type != output_data_fmt) 
		{
		    data_type_out = output_data_fmt;
		    continue;
		}

		if ((abs(output_slew) > 0) && debug(DEBUG_SLEW)) {
		    fprintf (info, "Output time slew: ");
		    fprintf (info, "stream = %s.%s.%s.%s, seq_no = %d, gap = %.3lf msec, ", 
			     record_list[h].hdr->station_id, 
			     record_list[h].hdr->network_id, 
			     record_list[h].hdr->channel_id, 
			     record_list[h].hdr->location_id, 
			     record_list[h].hdr->seq_no, 
			     (double)(bdif/USECS_PER_MSEC));
		    fprintf (info, "time should be = %s, ",
			     time_to_str(exptime,date_fmt));
		    fprintf (info, "is = %s\n", time_to_str(record_list[h].hdr->begtime,
							    date_fmt));
		    fflush (info);
		}

		if (!ok_to_merge) {
/*::		    fprintf (info, "flush from process_block - no merge\n");*/
		    fflush (info);
		    flush_record(out, -1);
		}
		if (append_to_output (st_p, output_slew) != 0) {
		    fprintf (info, "Error: appending data to output\n");
		    exit (1);
		}
		st_p->used = 1;
	    }
	    else {
		/* Too much slew for "continuous" data.			*/
		flush_record(out, -1);
		print_stream_summary(out);
		out->cont_blk = 0;
		out->min_slew = out->max_slew = out->max_step = out->total_slew = 0;
		/* Deallocate header structures and reallocate them for	*/
		/* a new contiguous segment.				*/
		free_data_hdr (out->sum_hdr);
		free_data_hdr (out->cur_hdr);
		free_data_hdr (out->prev_hdr);
		out->sum_hdr = out->cur_hdr = out->prev_hdr = NULL;
		data_type_out = output_data_fmt;
		continue;
	    }
	}
	else {
	    /*  We are discarding the entire packet.			*/
	    if (debug(DEBUG_TIME)||debug(DEBUG_STREAM)||debug(DEBUG_BLOCK)) {
		fprintf (info, "discarding entire input packet\n");
		fflush (info);
	    }
	    ++discard_packet;
	    break;
	}
	/* Ensure we maintain a copy of the initial record.		*/
	if (record_list[0].hdr == NULL) {
	    record_list[0].hdr = record_list[h].hdr;
	    record_list[0].iob = record_list[h].iob;
	    record_list[h].hdr = st_p->cur_hdr = NULL;
	    record_list[h].iob = st_p->iob = NULL;
	}
	/* Free current record and iob (if not initial record).		*/
	if (record_list[h].hdr != NULL) {
	    free_data_hdr (record_list[h].hdr);
	    free_iob(record_list[h].iob);
	    record_list[h].hdr = st_p->cur_hdr = NULL;
	    record_list[h].iob = st_p->iob = NULL;
	}
	h++;
    }

    /* Final cleanup.							*/

    /* Ensure we maintain a copy of the initial record.		*/
    if (record_list[0].hdr == NULL) {
	record_list[0].hdr = record_list[h].hdr;
	record_list[0].iob = record_list[h].iob;
	record_list[h].hdr = st_p->cur_hdr = NULL;
	record_list[h].iob = st_p->iob = NULL;
	h++;
    }
    /* Free any remaining headers in header list.			*/
    while (record_list[h].hdr != NULL) {
	free_data_hdr(record_list[h].hdr);
	free_iob(record_list[h].iob);
	h++;
    }

    /* Update input header structures.					*/
    /* Ensure that all created headers are freed.			*/
    st_p->cur_hdr = record_list[0].hdr;
    st_p->iob = record_list[0].iob;
    st_p->blksize = orig_blksize;
    st_p->iob->avail = st_p->blksize;
    if (! discard_packet) {
	if (st_p->prev_hdr != NULL) free_data_hdr (st_p->prev_hdr);
	st_p->prev_hdr = st_p->cur_hdr;
    }
    st_p->cur_hdr = NULL;
    st_p->used = 1;
	
    /* Free databuff, tmpbuff and diffbuff, since their size is block dependent.	*/
    free (databuff);
    databuff = NULL;
    free (diffbuff);
    diffbuff = NULL;
    free (tmpbuff);
    tmpbuff = NULL;
   
#if 0
    fprintf (stderr, "Exiting process_block\n");   /*:: debug */
#endif
    return (used_data);
}
