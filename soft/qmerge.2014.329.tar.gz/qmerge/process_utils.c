/************************************************************************/
/*  Utility routines to process current input record.			*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef lint
static const char sccsid[] = "$Id: process_utils.c,v 1.25 2014/11/25 20:01:56 doug Exp $ ";
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <math.h>

#include "qlib2.h"

#include "params.h"
#include "st_info.h"
#include "procs.h"
#include "externals.h"

#define	ANY_EVENT_FLAGS (ACTIVITY_BEGINNING_OF_EVENT | \
			     ACTIVITY_END_OF_EVENT | \
			     ACTIVITY_EVENT_IN_PROGRESS)

/************************************************************************/
/*  merge_tol:								*/
/*	Return tolerance for merging blocks of data for this stream.	*/
/*	Default value (if not overridded by cmdline argument)		*/
/*	is based on sample rate.					*/
/*	Special case 80 sps, since Quanterra SHEAR only provided time	*/
/*	to the msec, which was not sufficient for data blocks with	*/
/*	odd numbers of points (sample interval = 12.5 msec).		*/
/************************************************************************/
int merge_tol
   (int		rate,		/* sample rate in qlib convention.	*/
    int		rate_mult)	/* sample rate_mult in qlib convention.	*/
{
    int tol;
    if (block_tol >= 0) {
	tol = block_tol;
    }
    else {
	tol = MERGE_TOL(rate,rate_mult);
	if (rate == 80) tol = SPS_80_THRESHOLD;
    }
    return (tol);
}

/************************************************************************/
/*  tol:								*/
/*	Return tolerance for continuous data for this stream.		*/
/*	Default value (if not overridded by cmdline argument)		*/
/*	is based on sample rate.					*/
/************************************************************************/
int tol
   (int		rate,		/* sample rate in qlib convention.	*/
    int		rate_mult)	/* sample rate_mult in qlib convention.	*/
{
    if (stream_tol >= 0) 
	return (stream_tol);
    else
	return ((int)TOL(rate,rate_mult));
}

/************************************************************************/
/*  build_mseed_hdr:							*/
/*	Build mseed record header..					*/
/************************************************************************/
void build_mseed_hdr
   (ST_INFO	*st_p,		/* ptr to input stream struct.		*/
    SDR_HDR	*sh)		/* ptr to SEED Data Header.		*/
{
    DATA_HDR	*p = st_p->cur_hdr;

    /* Set up SEED header and data blockettes.				*/
    /*  Set station_id, channel_id, network_id based on version number	*/
    /*  and cmdline options.						*/
    if (station_id) strcpy (p->station_id, station_id);
    if (channel_id) strcpy (p->channel_id, channel_id);
    if (location_id) strcpy (p->location_id, location_id);
    if (seed_version >= 2.3) {
	if (network_id) {
	    strcpy (p->network_id, network_id);
	}
	else if (p->network_id[0]==0 || 
		 (p->network_id[0] == ' ' && p->network_id[1] == ' ')) {
	    strcpy (p->network_id, default_network_id);
	}
    }
    else {
	p->network_id[0] = p->network_id[1] = p->network_id[2] = 0;
    }

    init_sdr_hdr (sh, p, NULL);
    update_sdr_hdr (sh, p);
}

/************************************************************************/
/*  merge_flags:							*/
/*	Boolean function that determines whether flags from 2		*/
/*	different blocks can be safely merged.				*/
/************************************************************************/
int merge_flags 
   (DATA_HDR	*oh,		/* ptr to output record DATA_HDR.	*/
    DATA_HDR	*ih)		/* ptr to intput record DATA_HDR.	*/
{
    SEED_UWORD o_activity_flags = (SEED_UWORD) oh->activity_flags & 
	~ ACTIVITY_BEGINNING_OF_EVENT;

    /*	An ACTIVITY_BEGINNING_OF_EVENT flag on input header should	*/
    /*	a new block, but it should be ignored in the output header	*/
    /*	flag when compared to the input header flag.			*/

    /*  Do not merge data of different record types unless the record	*/
    /*  type is being explicitly set in the output record.		*/
    int	different_record_type = (output_record_type == 0 &&
				 (ih->record_type != oh->record_type));

    if ((o_activity_flags != ih->activity_flags) ||
	(oh->io_flags != ih->io_flags) ||
	(oh->data_quality_flags != ih->data_quality_flags) ||
	(different_record_type)) return (0);
    return(1);	    /* OK to merge. */
}

/************************************************************************/
/*  merge_check -							*/
/*	Determine whether it is OK to merge data & blockettes from the 	*/
/*	current block with data & blockettes already queued for output.	*/
/*	Assume that any required blockettes already exist.		*/
/*	Return 1 for OK, 0 for not OK.					*/
/************************************************************************/
int merge_check
   (DATA_HDR	*oh,		/* ptr to output record DATA_HDR.	*/
    DATA_HDR	*ih,		/* ptr to input record DATA_HDR.	*/
    int		output_slew_threshold,	/* max output slew threshold.	*/
    double	bdif)		/* slew between this and prev record.	*/
{
    int status;
    BS *bs, *obs;
    int type;
    int bl_len = 0;
    int tmp_first_data, tmp_num_samples;
    int datatype_checks;
    MS_ATTR oh_ms_attr, ih_ms_attr;
    
    /* If we are splitting output based on duration intervals:		*/
    /* Assume that any splitting of records to prevent a record from	*/
    /* spanning a duration (if exact_trim is set) has been done.	*/
    /* Check to see if this the start of this record falls within the	*/
    /* current duration.  If not, return false.				*/
    if (file_duration && after_duration (ih)) return (0);

    /* Compute current number of bytes for blockettes in output header.	*/
    for (bs=oh->pblockettes; bs != NULL; bs=bs->next) {
	type = bs->type;
	bl_len += bs->len;
    }
    /* Check to see how many bytes of new blockettes this input header	*/
    /* would add to the output header.					*/
    /* An input blockette is considered new if:				*/
    /*	1.  A output blockette of the same number is not found.		*/
    /*	2.  An output blockette of the same number is found, but is not */
    /*	    a per_record_blockette and the contents are different than	*/
    /*	    input blockette.						*/
    for (bs = ih->pblockettes; bs != NULL; bs = bs->next) {
	type = bs->type;
	if (find_pblockette(oh,oh->pblockettes,type) == NULL) {
	    bl_len += bs->len;		/* new blockette for output.	*/
	}
	obs = oh->pblockettes;
	while ((obs = find_pblockette(oh,obs,type)) != NULL) {
	    if (is_per_record_blockette(type)) break;
	    if (blockettecmp (bs,obs) != 0) bl_len += bs->len;
	    obs = obs->next;
	}
    }
    /* Temporarily set first_data in oh to account for space for the	*/
    /* current and proposed blockettes, which is required to compute	*/
    /* the space attributes for the output block being constructed.	*/
    tmp_first_data = oh->first_data;
    tmp_num_samples = oh->num_samples;
    oh->first_data = 48 + bl_len;
    if (repack_flag) oh->num_samples = 0;
    oh_ms_attr = get_ms_attr (oh);
    if (oh_ms_attr.alignment == 0) {
	fprintf (info, "Error: getting ms_attr\n");
	exit(1);
    }
    oh->first_data = tmp_first_data;
    oh->num_samples = tmp_num_samples;
    
    ih_ms_attr = get_ms_attr (ih);
    if (ih_ms_attr.alignment == 0) {
	fprintf (info, "Error: getting ms_attr\n");
	exit(1);
    }

    if (repack_flag) {
	datatype_checks = 1;
    }
    else {
	datatype_checks = ((oh->data_type == UNKNOWN_DATATYPE && oh_ms_attr.nbytes == 0) || 
	       (oh->data_type == ih->data_type));
    }
    status = (datatype_checks &&
	      (fabs(bdif) <= output_slew_threshold) &&
	      (ih_ms_attr.nbytes <= oh_ms_attr.bytelimit-oh_ms_attr.nbytes) && 
	      ((oh_ms_attr.nbytes == 0) || (merge_flags (oh, ih))));
#if QMERGE_DEBUG
    fprintf (stderr, "merge_check: %d\n", status);  /*:: debug */
#endif
    return (status);
}
    
/************************************************************************/
/* Static info required for repacking data. */

#define	MAX_REPACK  (MAX_BLKSIZE*MAX_SAMPLES_PER_BYTE)
#define	REPACK_SIZE (MAX_REPACK*2)
static int datab[REPACK_SIZE];
static int diffb[REPACK_SIZE];
#define bavail (bnstart + bnsamples)
static int bnsamples = 0;	/* # of samples in datab.		*/
static int bnstart = 0;		/* index of first sample in datab.	*/
static int bxm1 = 0;
static int bxn = 0;

/* Keep linked list of input hdrs that have time and sample count.	*/
/* Push new input hdr at the tail of the list.				*/
/* First hdr at head of list has time of first buffered sample.		*/
/* When removing buffered data, use the time from the first hdr	for the	*/
/* first sample, then reduce the sample count and increase the hdr time	*/
/* appropriately.  Discard the hdr when hdr sample count goes to 0 and	*/
/* move to next hdr.							*/

typedef struct _hdrq {
    struct _hdrq    *next;
    struct _hdrq    *prev;
    DATA_HDR	    *hdr;
} HDRQ;

HDRQ bhdr_head;

/************************************************************************/

/************************************************************************/
/*  push_hdr -								*/
/*	Push a copy of the DATA_HDR onto the tail of the list.		*/
/*	Return a ptr to the new DATA_HDR.				*/
/************************************************************************/
DATA_HDR *push_hdr (HDRQ* head, DATA_HDR *hdr)
{
    HDRQ *p;
    /* Initialize header to be linked to itself the first time. */
    if (head->next == NULL) head->next = head->prev = head;
    p = (HDRQ *)malloc(sizeof(HDRQ));
    p->hdr = dup_data_hdr(hdr);
    if (p->hdr == NULL) {
	fprintf (info, "Error: duplicating data_hdr\n");
	exit(1);
    }
    /* Put p on the tail of the list. */
    p->next = head;
    p->prev = head->prev;
    p->prev->next = p;
    p->next->prev = p;
    return (p->hdr);
}

/************************************************************************/
/*  shift_hdr -								*/
/*	Shift (remove) the first DATA_HDR from the list and return a	*/
/*	ptr to it.  Return NULL if list is empty.			*/
/************************************************************************/
DATA_HDR *shift_hdr (HDRQ* head)
{
    HDRQ *p;
    DATA_HDR *hdr;
    /* Initialize header to be linked to itself the first time. */
    if (head->next == NULL) head->next = head->prev = head;
    /* Check for emtpy list. */
    if (head->next == head) return ((DATA_HDR *)NULL);
    /* Remove the first item on the list, and pointer to its hdr.	*/
    p = head->next;
    hdr = p->hdr;
    p->prev->next = p->next;
    p->next->prev = p->prev;
    free(p);
    return (hdr);
}

/************************************************************************/
/*  get_hdr -								*/
/*	Return ptr to the first DATA_HDR on the list, but leave on list.*/
/************************************************************************/
DATA_HDR *get_hdr (HDRQ* head)
{
    DATA_HDR *hdr;
    /* Initialize header to be linked to itself the first time. */
    if (head->next == NULL) head->next = head->prev = head;
    /* Check for emtpy list. */
    if (head->next == head) return ((DATA_HDR *)NULL);
    hdr = head->next->hdr;
    return (hdr);
}

/************************************************************************/
/*  flush_file:								*/
/*	Flush any buffered output.					*/
/*	Print summary info.						*/
/*	Optionally close output file, and				*/
/*	Save output data format across stream closure.			*/
/************************************************************************/
ST_INFO *flush_file
   (ST_INFO	*out,		/* ptr to output stream struct.		*/
    int		close_flag)	/* flag to close file.			*/
{
    DATA_HDR *oh;
    int data_fmt;

#if QMERGE_DEBUG
    fprintf (stderr, "Entering flush_file, flag=%d\n", close_flag);	/*:: debug */
#endif
    if (out == NULL) {
	fprintf (info, "Error:  Flushing non-existing output stream\n");
	exit(1);
    }
    oh = out->cur_hdr;
    if (oh != NULL) {
	data_fmt = (output_data_fmt != UNKNOWN_DATATYPE) ? output_data_fmt :
		    (out->data_type != UNKNOWN_DATATYPE) ? oh->data_type :
		    (oh) ? oh->data_type : UNKNOWN_DATATYPE;
	flush_record(out, -1);
	oh = out->cur_hdr;
	if (oh->num_samples > 0 || oh->num_blockettes > 0) {
	    fprintf (info, "Error: unflushed output found - nsamples = %d\n", oh->num_samples);
	    exit (1);
	}
	print_stream_summary(out);
    }
    if (close_flag) {
	close_stream (out);
	out = NULL;
	out = open_stream (&st_head_out, "", "w");
	out->data_type = data_fmt;
    }
    else {
	/* Reset all output info, but do not close file.    */
	free_data_hdr (out->sum_hdr);
	free_data_hdr (out->cur_hdr);
	free_data_hdr (out->prev_hdr);
	out->sum_hdr = out->cur_hdr = out->prev_hdr = NULL;
	out->blksize = 0;
	out->cont_blk = 0;
	out->min_slew = 0;
	out->max_slew = 0;
	out->max_step = 0;
	out->total_slew = 0;
	out->num_samples = 0;
	out->num_blocks = 0;
	out->data_type = UNKNOWN_DATATYPE;
    }
#if QMERGE_DEBUG
    fprintf (stderr, "Exiting flush_file\n");	/*:: debug */
#endif
    return (out);
}

/************************************************************************/
/*  append_to_output:							*/
/*	Append input to output.						*/
/*  return:								*/
/*	0 on success.							*/
/*	negative QLIB2 error code on error.				*/
/************************************************************************/
int append_to_output 
   (ST_INFO	*st_p,		/* ptr to input stream struct.		*/
    int		slew)		/* slew between this and prev record.	*/
{
    ST_INFO	*out = st_head_out.next;
    DATA_HDR	*oh = out->cur_hdr;
    DATA_HDR	*ih = st_p->cur_hdr;
    DATA_HDR	*sh = out->sum_hdr;
    int		i_offset = ih->first_data;
    DATA_HDR	*hdr;
    int		i_len, o_offset;
    int		seconds, usecs;
    FRAME	*p_fr1, *p_fr2;
    BS		*bs;
    MS_ATTR	ih_ms_attr, oh_ms_attr;
    char	*filename;
    int		status = 0;

#if QMERGE_DEBUG
    fprintf (stderr, "Entering append_to_output - slew = %d\n", slew);	/*:: debug */
#endif

    /* If this record starts after the current duration, we need to	*/
    /* close the existing file (if open), and open a new file.		*/
    if (file_duration && after_duration (ih)) {
	/* Save last data value as bxm1 for later possible compression.	*/
  	int xn = bxn;
	out = flush_file (out,1);
	if (out->sum_hdr == NULL) make_out_sum_hdr(out, st_p);
	if (out->cur_hdr == NULL) make_out_cur_hdr(out);
	oh = out->cur_hdr;
	bxm1 = xn;
    }

    /* Ensure that the data_type is set for output.			*/
    /* If not specified on the command line, use type of first record.	*/
    if (out->data_type == UNKNOWN_DATATYPE) out->data_type = ih->data_type;
    if (oh->data_type == UNKNOWN_DATATYPE) oh->data_type = out->data_type;

    /* If the command line set the Quality record_type, use it.		*/
    /* Otherwise, use the input record_type.				*/
    oh->record_type = (output_record_type) ? output_record_type : ih->record_type;

    /* Wordorder should have been converted already if necessary.	*/
    if (ih->data_wordorder != oh->data_wordorder) {
	fprintf (stderr, "Error: input data_wordorder = %d, output data_wordorder = %d\n",
		 ih->data_wordorder, oh->data_wordorder);
	exit(1);
    }

    /* If file is not actually open, we need to compute a new duration	*/
    /* and open a new file based on the duration.			*/
    if (out == NULL) {
	fprintf (info, "Error: no output file open\n");
	exit(1);
    }
    if (out->iob->deferred) {
	int data_fmt = (output_data_fmt != UNKNOWN_DATATYPE) ? output_data_fmt :
		       (out->cur_hdr) ? out->cur_hdr->data_type : UNKNOWN_DATATYPE;
	compute_duration (ih);
	filename = build_filename (st_p->cur_hdr, filename_pattern);
	close_stream (out);
	out = open_stream (&st_head_out, filename, outmode);
	out->data_type = data_fmt;
	if (out->sum_hdr == NULL) make_out_sum_hdr(out, st_p);
	if (out->cur_hdr == NULL) make_out_cur_hdr(out);
    }
    oh = out->cur_hdr;
    sh = out->sum_hdr;
	
    /* Save input data hdr as the last data hdr seen, even if we do not	*/
    /* use the output data.  last_hdr is used by the find_best_block	*/
    /* function to determine which file to use for input.		*/
    if (out->last_hdr) free_data_hdr (out->last_hdr);
    out->last_hdr = dup_data_hdr(st_p->cur_hdr);
    if (out->last_hdr == NULL) {
	fprintf (info, "Error: duplicating data_hdr\n");
	exit(1);
    }
    if (event_only_flag && ! (st_p->cur_hdr->activity_flags & ANY_EVENT_FLAGS)) {
	return (status);
    }

    if (! (repack_flag)) {
	/* Copy any new blockettes from the input to the output hdr.	*/
	if ((status=merge_blockettes (oh, ih, BL_UNIQUE_COPY + BL_PER_RECORD_COPY)) != 0) {
	    fprintf (info, "Error: merging blockettes\n");
	    exit(1);
	}
	/* Get attributes of input and output data block.		*/
	ih_ms_attr = get_ms_attr (ih);
	if (ih_ms_attr.alignment == 0) {
	    fprintf (info, "Error: getting ms_attr\n");
	    exit(1);
	}
	oh_ms_attr = get_ms_attr (oh);
	if (oh_ms_attr.alignment == 0) {
	    fprintf (info, "Error: getting ms_attr\n");
	    exit(1);
	}
	i_len = ih_ms_attr.nbytes;

	/* The caller verified that we have sufficient space in the	*/
	/* current output record for this data and blockette info.	*/
	/* Incrementally add this data to the existing output record.	*/
	/* Compute the output buffer offset for the new data.		*/
	if (IS_STEIM_COMP(ih->data_type))
	    o_offset = oh->first_data + (oh->num_data_frames * sizeof(FRAME));
	else
	    o_offset = oh->first_data + oh_ms_attr.nbytes;

	/* Copy the data to the output buffer.				*/
	memcpy (out->iob->buf + o_offset, st_p->iob->buf + i_offset, i_len);

	/* For STEIM compressed data, if this is not the first		*/
	/* data in the output buffer, we must mask out the (now unused)	*/
	/* X0 and Xn in the input buffer.  We can leave the values there,	*/
	/* but we must change the flag to make them ignored values.	*/
	if (IS_STEIM_COMP(ih->data_type)) {
	    if (oh->num_samples > 0 && ih->num_data_frames > 0) {
		/*  Set the mask for the input's (now unused) X0 and Xn	*/
		/*  Clear the top 3 bits (control, old x0, old xn).		*/
		p_fr2 = (FRAME *)(out->iob->buf + o_offset);
		if (my_wordorder != oh->data_wordorder) {
		    swab4 ((int *)&p_fr2->ctrl);
		    p_fr2->ctrl &= ~ 0xfc000000;
		    swab4 ((int *)&p_fr2->ctrl);
		}
		else {
		    p_fr2->ctrl &= ~ 0xfc000000;
		}
		/*  Update output Xn to the new value of Xn.		*/
		p_fr1 = (FRAME *)(out->iob->buf + out->cur_hdr->first_data);
		p_fr1->w[1].fw = p_fr2->w[1].fw;
	    }
	}

	/* Update the flags and other header info (including flags).	*/
	/* Ensure that ACTIVITY_TIME_CORR_APPLIED is set ONLY from the	*/
	/* first input data block used in the output block.		*/
	if (oh->num_samples == 0) {
	    oh->activity_flags |= ih->activity_flags;
	    oh->hdrtime = ih->hdrtime;
	    oh->begtime = ih->begtime;
	    oh->num_ticks_correction = ih->num_ticks_correction;
	    if (IS_STEIM_COMP(ih->data_type)) oh->x0 = ih->x0;
	}
	else {
	    oh->activity_flags |= (ih->activity_flags & (~ ACTIVITY_TIME_CORR_APPLIED));
	}
	oh->io_flags |= ih->io_flags;
	oh->data_quality_flags |= ih->data_quality_flags;
	oh->num_data_frames += ih->num_data_frames;
	oh->data_type = ih->data_type;
	oh->num_samples += ih->num_samples;
	if (IS_STEIM_COMP(ih->data_type)) oh->xn = ih->xn;
	/* Update the endtime if we have a blockette 100.			*/
	if ((bs=find_blockette(st_p->cur_hdr, 100))) {
	    double actual_rate, dusecs;
	    BLOCKETTE_100 *b = (BLOCKETTE_100 *) bs->pb;
	    if (bs->wordorder != my_wordorder) {
		swab_blockette (bs->type, bs->pb, bs->len);
		bs->wordorder = my_wordorder;
	    }
	    actual_rate = b->actual_rate;
	    dusecs = ((double)((oh->num_samples-1)/actual_rate))*USECS_PER_SEC;
	    oh->endtime = add_dtime (oh->begtime,  dusecs);
	}
	else {
	    time_interval2 (oh->num_samples-1,ih->sample_rate,ih->sample_rate_mult,
			    &seconds,&usecs);
	    oh->endtime = add_time (oh->begtime, seconds, usecs);
	}
    }

    if (repack_flag) {
	int data_fmt;
	int nsamples = ih->num_samples;
	oh->num_data_frames = 0;

	/* Make room for incoming data to be unpacked.			*/
	/* Unpacked buffer should be large enough to accomodate data	*/
	/* for at least 2 output records.				*/
	if (nsamples > REPACK_SIZE) {
	    fprintf (info, "Error: repack buffer size %d < num_samples %d\n",
		     REPACK_SIZE, nsamples);
	    exit(1);
	}
	while (bavail + nsamples > REPACK_SIZE) {
	    flush_record (out, 1);
	    oh = out->cur_hdr;
	}

	/* Copy any new blockettes from the input to the output hdr.	*/
	/* If we are repacking data, make a copy of the input hdr, and	*/
	/* delete the blockettes from it as we copy them to the output hdr.	*/
	hdr = push_hdr (&bhdr_head, ih);
	if ((status=merge_blockettes (oh, hdr, BL_UNIQUE_MOVE + BL_PER_RECORD_MOVE)) != 0) {
	    fprintf (info, "Error: merging blockettes\n");
	    exit(1);
	}
	/* Get attributes of input and output data block.		*/
	ih_ms_attr = get_ms_attr (ih);
	if (ih_ms_attr.alignment == 0) {
	    fprintf (info, "Error: getting ms_attr\n");
	    exit(1);
	}
	oh_ms_attr = get_ms_attr (oh);
	if (oh_ms_attr.alignment == 0) {
	    fprintf (info, "Error: getting ms_attr\n");
	    exit(1);
	}
	i_len = ih_ms_attr.nbytes;

	/* Unpack the data. */
	data_fmt = unpack_sdr_data (st_p, datab+bavail, diffb+bavail, 0, nsamples);
#if QMERGE_DEBUG
	fprintf (stderr, "unpack_sdr_data: data fmt = %d\n", data_fmt); /*:: debug */
#endif
	if (data_fmt == UNKNOWN_DATATYPE) {
	    fprintf (stderr, "Error: unpacking %d samples into datab\n", nsamples);
	    exit(1);
	}
	if (! IS_STEIM_COMP(ih->data_type)) {
	    /* Compute the original data[-1] for possible recompression later. */
	    /* Compute the diff buffer now for possible recompression later. */
	    int prev = (bavail == 0) ? bxm1 : datab[bavail-1];
	    build_diff (datab+bavail, diffb+bavail, nsamples, prev);
	}

	/* Compute the original data[-1] for possible recompression later.	*/
	if (bnstart == 0) bxm1 = datab[0] - diffb[0];
	bnsamples += nsamples;
	if (bavail > 0) bxn = datab[bavail-1];

	/* Update the flags and other header info (including flags).	*/
	/* Ensure that ACTIVITY_TIME_CORR_APPLIED is set ONLY from the	*/
	/* first input data block used in the output block.		*/
	if (oh->num_samples == 0) {
	    init_out_hdr (oh, ih, out);
	    oh->activity_flags |= ih->activity_flags;
	    oh->hdrtime = ih->hdrtime;
	    oh->begtime = ih->begtime;
	    oh->num_ticks_correction = ih->num_ticks_correction;
	    oh->activity_flags |= ih->activity_flags;
	}
	else {
	    oh->activity_flags |= (ih->activity_flags & (~ ACTIVITY_TIME_CORR_APPLIED));
	}
	oh->io_flags |= ih->io_flags;
	oh->data_quality_flags |= ih->data_quality_flags;
	oh->num_data_frames = 0;
	/* Don't set out data_type from in data_type. */
	oh->num_samples += ih->num_samples;
	if (IS_STEIM_COMP(oh->data_type)) oh->xn = datab[bavail-1];
	time_interval2 (oh->num_samples-1,ih->sample_rate,ih->sample_rate_mult,
			&seconds,&usecs);
	oh->endtime = add_time (oh->begtime, seconds, usecs);

    }

    /*	Update the information in the output's sum_hdr.			*/
    /*	This header provides a running summary of information for data	*/
    /*	that has been directed to the output stream.  This INCLUDES	*/
    /*	data that is placed in the output buffer but not yet written.	*/
    /*	It is therefore updated NOW, NOT when the buffer is written.	*/
    /*	This provides a uniform place for begtime, endtime, num_samples,*/
    /*	and other info that is needed to reflect the state of data	*/
    /*	that has been directed for output.				*/
    if (sh->num_samples == 0) {
	sh->begtime = ih->begtime;
	if (IS_STEIM_COMP(oh->data_type)) sh->x0 = ih->x0;
    }
    sh->endtime = oh->endtime;
    sh->num_samples += ih->num_samples;
    if (IS_STEIM_COMP(oh->data_type)) sh->xn = (repack_flag) ? datab[bavail-1]: ih->xn;

    /*	Keep track of time slew information.			*/
    out->total_slew += slew;
#if QMERGE_DEBUG
    if (slew != 0 && debug(DEBUG_SLEW)) {
	fprintf (info, "total_slew = %d\n", out->total_slew/USECS_PER_MSEC);
    }
#endif
    out->max_slew = MAX(out->total_slew, out->max_slew);
    out->min_slew = MIN(out->total_slew, out->min_slew);
    out->max_step = MAX(out->max_step, abs(slew));

    if (repack_flag) {
	/* Repack and output the data only when we are guaranteed to	*/
	/* have enough data to fill an output record, or when we we are */
	/* required to start a new record for other reasons.		*/
	while (bnsamples >= output_blksize * MAX_SAMPLES_PER_BYTE) {
	    flush_record (out, 1);
	    oh = out->cur_hdr;
	}
    }
#if QMERGE_DEBUG
    fprintf (stderr, "Exiting append_to_output\n");	/*:: debug */
#endif
    return (status);
}

/************************************************************************/
/*  write_record:							*/
/*	Output fully constructed mseed record.				*/
/*	Update pointers to hdrs in output structure.			*/
/*	Release old hdrs.						*/
/*	Set the output format in the stream output header.		*/
/************************************************************************/
void write_record
   (ST_INFO	*out)
{
    DATA_HDR	    *oh = out->cur_hdr;

#if QMERGE_DEBUG
    fprintf (stderr, "In write_record\n");  /*:: debug */
#endif

    /* Save the output format in the stream output header.		*/
    out->data_type = oh->data_type;

    /* Output the fully constructed mseed record.			*/
    if (debug(DEBUG_ASCII|DEBUG_ASCII_1)) write_ascii_stream (out);
    else write_stream (out);
    if debug(DEBUG_OUT) {
	fprintf (info, "out: %s.%s.%s.%s, block %d, %d points (%s to ",
		 oh->station_id, oh->network_id, oh->channel_id, oh->location_id, 
		 oh->seq_no, oh->num_samples,
		 time_to_str(oh->begtime,date_fmt));
	fprintf (info, "%s)\n", time_to_str(oh->endtime,date_fmt));
    }

    /* Release old prev_hdr (if any), move cur_hdr to prev_hdr,		*/
    /* and get a new empty current header.				*/
    /* Set the data_type in the new header to current data_type.	*/
    if (out->prev_hdr != NULL) free_data_hdr(out->prev_hdr);
    out->prev_hdr = out->cur_hdr;
    out->cur_hdr = NULL;
    make_out_cur_hdr(out);
    out->cur_hdr->data_type = out->prev_hdr->data_type;
}

static unsigned char tmpspace[MAX_BLKSIZE];
/************************************************************************/
/*  flush_record:							*/
/*	Flush out specified number of output records.			*/
/*	A count of < 0 means flush out all data.			*/
/*	Buffered (repacked) data could span multiple output records.	*/
/*	Unbuffered data is at most one record.				*/
/************************************************************************/
int flush_record
   (ST_INFO	*out,		/* ptr to output stream struct.		*/
    int		nrecords)	/* # of records to flush (<0 -> all)	*/ 
{
    DATA_HDR	*oh = out->cur_hdr;
    int		o_offset;
    int		o_len;
    int		pad = 1;
    int		steim_comp;
    MS_ATTR	oh_ms_attr;
    int nbytes = 0;
    int nsamples = 0;
    int nleft = 0;

#if QMERGE_DEBUG
    fprintf (stderr, "Entering flush_record, out = %p, nrecords=%d\n", &out, nrecords);    /*:: debug */
#endif
    if (! repack_flag) {
	DATA_HDR	    *ch = out->cur_hdr;
	BS		    *bs;
	int		    nbytes_of_data;
	int		    bl_len = 0;
	int		    pad_len;
	int		    align;
	MS_ATTR		    ms_attr;

	if (ch == NULL) return 0;

	/* Final blockette update.  Update any blockettes that have 	*/
	/* block-specific info.						*/
	update_b1000 (oh, oh->blksize, oh->data_type);
	update_b1001 (oh, oh->num_data_frames);

	ms_attr = get_ms_attr (ch);
	if (ms_attr.alignment == 0) {
	    fprintf (info, "Error: getting ms_attr\n");
	    exit(1);
	}
	pad_len = ms_attr.bytelimit - ms_attr.nbytes;
	align = ms_attr.alignment;
	pad_out(out, ms_attr.nbytes, pad_len);

	/* Compute current number of bytes for blockettes in output header.	*/
	for (bs=ch->pblockettes; bs != NULL; bs=bs->next) {
	    bl_len += bs->len;
	}
	nbytes_of_data = ms_attr.nbytes;
	if (ch != NULL && nbytes_of_data > 0) {
	    /*	Since our total header + blockettes may now exceed the space	*/
	    /*	originally allocated for in the io buffer, we will need to	*/
	    /*	temporarily move the data in the i/o buffer to a temp buffer,	*/
	    /*	construct the output SEED header in the i/o buffer, and then	*/
	    /*	copy the data back into the i/o buffer for output.		*/
	    memcpy (tmpspace, out->iob->buf+ch->first_data, nbytes_of_data);
	    memset (out->iob->buf, 0, out->blksize);    /* clear output buf.*/
	    ch->first_data = 48 + bl_len;
	    if (align > 0) {
		ch->first_data = (int)((ch->first_data+align-1)/align) * align;
	    }
	    /* Create the seed header in the output buffer. */
	    build_mseed_hdr(out, (SDR_HDR *)out->iob->buf);
	    /* Copy the data into the output buffer.	    */
	    memcpy (out->iob->buf+ch->first_data, tmpspace, nbytes_of_data);

	    write_record (out);
	    oh = out->cur_hdr;
	}
    }

    if (repack_flag) {
	int status, seconds, usecs, bl_len, align, save_xn, saved_xn;
	void *p_repack;		/* ptr to repacked SEED Data.	*/
	BS *bs;

	/* Note: diffb buffer is now computed during record unpacking.	*/

	save_xn = (nrecords <= 0);
	if (save_xn) saved_xn = (bavail > 0) ? datab[bavail-1] : 0;
	steim_comp = IS_STEIM_COMP(oh->data_type);

	while (nrecords != 0 && bnsamples > 0) {
	    DATA_HDR *ih = get_hdr (&bhdr_head);
	    /* Ensure that we have an output block and required blockettes.	*/
	    if (out->cur_hdr == NULL) {
		make_out_cur_hdr(out);
		oh = out->cur_hdr;
	    }
	    if (oh->num_samples == 0) init_out_hdr (oh, ih, out);

	    /* Get attributes of input and output data block.		*/
	    oh_ms_attr = get_ms_attr (oh);
	    if (oh_ms_attr.alignment == 0) {
		fprintf (info, "Error: getting ms_attr\n");
		exit(1);
	    }
	    o_len = oh_ms_attr.nbytes;
	    align = oh_ms_attr.alignment;

	    /* Compute current number of bytes for blockettes in output header.	*/
	    bl_len = 0;
	    for (bs=oh->pblockettes; bs != NULL; bs=bs->next) {
		bl_len += bs->len;
	    }

	    /* Set the output buffer offset for the new data.			*/
	    /* Set the number of data frames available for data.		*/
	    oh->num_data_frames = 0;
	    oh->first_data = 48 + bl_len;
	    if (align > 0) 
		oh->first_data = (int)((oh->first_data+align-1)/align) * align;
	    if (steim_comp) 
		oh->num_data_frames = (oh->blksize - oh->first_data) / sizeof(FRAME);
	    o_offset = oh->first_data;

	    /* Repack buffered data into a single the output record.		*/
	    /* For STEIM compressed output:					*/
	    /* 1.  Fill in X0 and XN in the output hdr.				*/
	    /* 2.  Save this XN as the BXM1 for future compression.		*/
	    p_repack = (void *)(out->iob->buf+o_offset);
	    status = repack_sdr_data (p_repack, datab+bnstart, diffb+bnstart, bnsamples, 
				      oh->blksize - o_offset,
				      oh->data_type, pad, oh->data_wordorder, &nbytes, &nsamples);
#if QMERGE_DEBUG
	    fprintf (stderr, "repack_sdr_data: data fmt = %d nsamples = %d, x0 = %d, xn = %d\n", 
		     oh->data_type, nsamples, datab[bnstart], datab[bnstart+nsamples-1]);    /*:: debug */
#endif
	    if (status != 0) {
		fprintf (info, "Error: repacking data\n");
		exit(1);
	    }
	    if (steim_comp && nsamples > 0) {
		oh->x0 = datab[bnstart];
		oh->xn = datab[bnstart+nsamples-1];
	    }
	    if (nsamples > 0) bxm1 = datab[bnstart+nsamples-1];
	    bnstart += nsamples;
	    bnsamples -= nsamples;
	    oh->num_samples = nsamples;
	    oh->num_data_frames =  (steim_comp) ? (nbytes / sizeof(FRAME)) : 0;
	    oh->data_type = out->data_type;
	    oh->hdrtime = ih->hdrtime;
	    oh->begtime = ih->begtime;
	    oh->num_ticks_correction = ih->num_ticks_correction;
	    oh->activity_flags |= ih->activity_flags;

	    /* Output data may have come from multiple input blocks.	*/
	    /* Discard hdrs whose data was completely used in output.	*/
	    /* Update hdr whose data was partially used in output.	*/
	    while (nsamples > 0) {
		/* Update the flags and other header info (including flags).	*/
		/* Ensure that ACTIVITY_TIME_GAP is set ONLY from first data	*/
		/* block put in output block.					*/
		oh->activity_flags |= (ih->activity_flags & (~ ACTIVITY_TIME_CORR_APPLIED));
		oh->io_flags |= ih->io_flags;
		oh->data_quality_flags |= ih->data_quality_flags;
		if (nsamples >= ih->num_samples) {
		    /* Discard this hdr. */
		    nsamples -= ih->num_samples;
		    free_data_hdr(shift_hdr (&bhdr_head));
		    ih = get_hdr (&bhdr_head);
		    /* Sanity check */
		    if (nsamples > 0 && ih == NULL) {
			fprintf (stderr, "Error: no buffered hdr for buffered data\n");
			exit(1);
		    }
		    continue;
		}
		else {
		    /* Update this hdr.	*/
		    time_interval2 (nsamples, ih->sample_rate, ih->sample_rate_mult,
				    &seconds, &usecs);
		    ih->begtime = add_time (ih->begtime, seconds, usecs);
		    ih->hdrtime = add_time (ih->hdrtime, seconds, usecs);
		    ih->num_samples -= nsamples;
		    nsamples = 0;
		}
	    }

	    /* Fill in end time of the output record.				*/
	    time_interval2 (oh->num_samples-1,oh->sample_rate,oh->sample_rate_mult,
			    &seconds,&usecs);
	    oh->endtime = add_time (oh->begtime, seconds, usecs);

	    /* Final blockette update.  Update any blockettes that have 	*/
	    /* block-specific info.						*/
	    update_b1000 (oh, output_blksize, oh->data_type);
	    update_b1001 (oh, oh->num_data_frames);

	    /* Create the seed header in the output buffer. */
	    build_mseed_hdr(out, (SDR_HDR *)out->iob->buf);

	    write_record (out);
	    oh = out->cur_hdr;
	    --nrecords;
	}
	/* Shift the remaining data in the unpacked buffer to beginning.	*/
	memmove (datab, datab+bnstart, bnsamples * sizeof(int));
	memmove (diffb, diffb+bnstart, bnsamples * sizeof(int));
	bnstart = 0;
	if (save_xn) bxm1 = saved_xn;
	nleft = bnsamples;
    }
#if QMERGE_DEBUG
    fprintf (stderr, "Exiting flush_record, remaining = %d\n", nleft);    /*:: debug */
#endif
    return 0;
}

/************************************************************************/
/*  pad_out:								*/
/*	Pad the output buffer (if not empty).				*/
/************************************************************************/
int pad_out
   (ST_INFO	*out,	/* ptr to output stream struct.		*/
    int		data_bytes,	/* # of data bytes in output record.	*/
    int		pad_len)	/* # of bytes to pad record.		*/
{
    IOB		    *iob = out->iob;
    DATA_HDR	    *ch = out->cur_hdr;

    if (ch == NULL || (ch->pblockettes == NULL && ch->num_samples == 0))
	return(0);
    memset ((void *)(iob->buf + ch->first_data +  data_bytes), 
	    0, pad_len);
    return (0);
}

/************************************************************************/
/*  hdr_cmp:								*/
/*	Compare 2 DATA_HDR structures (except for pblockette field).	*/
/*	Return 0 if identical, non-zero otherwise.			*/
/************************************************************************/
int hdr_cmp
   (DATA_HDR	*hdr1,		/* ptr to first DATA_HDR.		*/
    DATA_HDR	*hdr2)		/* ptr to second DATA_HDR.		*/
{
    DATA_HDR h1 = *hdr1;
    DATA_HDR h2 = *hdr2;
    h1.pblockettes = h2.pblockettes = (BS *)NULL;
    return (memcmp((void *)&h1,(void *)&h2,sizeof(DATA_HDR)));
}

/************************************************************************/
/*  same_type_data_stream:						*/
/*	Boolean function to compare stream characteristics.		*/
/************************************************************************/
int same_type_data_stream 
   (DATA_HDR	*ih,		/* ptr to first DATA_HDR.		*/
    DATA_HDR	*oh)		/* ptr to second DATA_HDR.		*/
{
    int rc = 0;
    if ((strcmp(ih->station_id, oh->station_id) != 0) ||
	(strcmp(ih->channel_id, oh->channel_id) != 0) ||
	(strcmp(ih->network_id, oh->network_id) != 0) ||
	(strcmp(ih->location_id, oh->location_id) != 0)
	) rc = 0;
    else rc = 1;
    return (rc);
}

/************************************************************************/
/*  same_rate_data_stream:						*/
/*	Boolean function to compare stream rates.			*/
/************************************************************************/
int same_rate_data_stream 
   (DATA_HDR	*ih,		/* ptr to first DATA_HDR.		*/
    DATA_HDR	*oh)		/* ptr to second DATA_HDR.		*/
{
    double r1,r2;
    int rc = 0;
    if (
	!(((ih->sample_rate == oh->sample_rate) &&
	   (ih->sample_rate_mult == oh->sample_rate_mult)) ||
	  ((ih->sample_rate == 0 && ih->num_samples == 0) || 
	   (oh->sample_rate == 0 && oh->num_samples == 0)) ||
	  ((r1=sps_rate(ih->sample_rate,ih->sample_rate_mult)) ==
	   (r2=sps_rate(oh->sample_rate,oh->sample_rate_mult))) ||
	  ((r1=best_rate(ih)) == (r2=best_rate(oh))) ||
	  (r1<0.0 || r2<0.0))
	) rc = 0;
    else rc = 1;
    return (rc);
}

/************************************************************************/
/*  make_out_sum_hdr:							*/
/*	Alloc and init summary output header struct.			*/
/************************************************************************/
void make_out_sum_hdr
   (ST_INFO	*out,		/* output structure.			*/
    ST_INFO	*st_p)		/* input structure.			*/
{
    /*	Make and fill in summary header if we don't have one yet.	*/
    if (out->sum_hdr == NULL) {
	out->sum_hdr = new_data_hdr();
	if (out->sum_hdr == NULL) {
	    fprintf (info, "Error: creating new data_hdr\n");
	    exit(1);
	}
	/*  Copy info from current input stream to summary header.	*/
	strcpy (out->sum_hdr->station_id, st_p->cur_hdr->station_id);
	strcpy (out->sum_hdr->location_id, st_p->cur_hdr->location_id);
	strcpy (out->sum_hdr->channel_id, st_p->cur_hdr->channel_id);
	strcpy (out->sum_hdr->network_id, st_p->cur_hdr->network_id);
	out->sum_hdr->sample_rate = st_p->cur_hdr->sample_rate;
	out->sum_hdr->sample_rate_mult = st_p->cur_hdr->sample_rate_mult;
	out->sum_hdr->blksize = output_blksize;
	out->sum_hdr->data_type = out->data_type;
	/*  Fill in stream header structure also from summary header.	*/
	strcpy (out->station, out->sum_hdr->station_id);
	strcpy (out->channel, out->sum_hdr->channel_id);
	out->rate = out->sum_hdr->sample_rate;
	out->rate_mult = out->sum_hdr->sample_rate_mult;
	out->hdr_type = SDR_HDR_TYPE;
	out->blksize = output_blksize;
    }
}

/************************************************************************/
/*  make_out_cur_hdr:							*/
/*	Alloc and init current output header struct.			*/
/************************************************************************/
void make_out_cur_hdr
   (ST_INFO	*out)		/* ptr to output stream struct.		*/
{
    /*	Make and fill in current header if we don't have one yet.	*/
    if (out->cur_hdr == NULL) {
	out->cur_hdr = new_data_hdr();
	if (out->cur_hdr == NULL) {
	    fprintf (info, "Error: creating new data_hdr\n");
	    exit(1);
	}
	strcpy (out->cur_hdr->station_id, out->sum_hdr->station_id);
	strcpy (out->cur_hdr->location_id, out->sum_hdr->location_id);
	strcpy (out->cur_hdr->channel_id, out->sum_hdr->channel_id);
	strcpy (out->cur_hdr->network_id, out->sum_hdr->network_id);
	out->cur_hdr->sample_rate = out->sum_hdr->sample_rate;
	out->cur_hdr->sample_rate_mult = out->sum_hdr->sample_rate_mult;
	out->cur_hdr->first_data = 48;
	out->cur_hdr->blksize = output_blksize;
	out->cur_hdr->data_type = out->data_type;
	out->cur_hdr->seq_no = (out->prev_hdr == NULL) ? 1 : 
	    out->prev_hdr->seq_no + 1;
#if QMERGE_DEBUG
	fprintf (stderr, "make_out_cur_hdr: out->cur_hdr = %p\n", &(out->cur_hdr));   /*:: debug */
#endif
    }
}

/************************************************************************/
/*  verify_block:							*/
/*	Verify internal integrity of data packet.			*/
/*  return:								*/
/*	data type of input record.					*/
/************************************************************************/
int verify_block 
   (ST_INFO	*st_p)		/* ptr to input stream struct.		*/
{
    int data_type;
    /*	Unpack the input data from seed data records frames.		*/
    data_type = unpack_sdr_data (st_p, databuff, diffbuff, 0, 
				 st_p->cur_hdr->num_samples);
    return (data_type);
}

/************************************************************************/
/*  is_per_record_blockette:						*/
/*	Check if specified blockette is a per_record blockette.		*/
/*  return:								*/
/*	1 if blockette should per_record blockette, 0 otherwise.	*/
/************************************************************************/
int is_per_record_blockette 
   (int		n)		/* blockette number.			*/
{
    int i;
    for (i=0; per_record_blockette[i].blockette != 0; i++) {
	if (n == per_record_blockette[i].blockette) return (1);
    }
    return (0);
}

/************************************************************************/
/*  strip_blockette:							*/
/*	Check if specified blockette should be stripped from record.	*/
/*  return:								*/
/*	1 if blockette should be stripped, 0 otherwise.			*/
/************************************************************************/
int strip_blockette 
   (int		n)		/* blockette number.			*/
{
    int i;
    if (stripped_blockette == NULL) return (0);
    for (i=0; stripped_blockette[i].first != 0; i++) {
	if (stripped_blockette[i].first == -1 || 
	    (n >= stripped_blockette[i].first && n <= stripped_blockette[i].last))
	    return (1);
    }
    return (0);
}

/************************************************************************/
/*  add_required_blockettes:						*/
/*	Add any required blockettes to this hdr.			*/
/*  return:								*/
/*	0 on success.							*/
/*	MS_ERROR on error.						*/
/************************************************************************/
int add_required_blockettes 
   (DATA_HDR	*hdr)		/* DATA_HDR for record.			*/
{
    int status = 0;
    /* Currently only blockette 1000 is required for seed_version>=2.3	*/
    if (seed_version >= 2.3 && ! strip_blockette(1000) && 
	find_blockette(hdr, 1000) == NULL) {
	BLOCKETTE_1000 b1000;
	int ok;
	b1000.hdr.type = 1000;
	b1000.hdr.next = 0;
	b1000.format = hdr->data_type;
	b1000.word_order = SEED_BIG_ENDIAN;
	b1000.data_rec_len = roundoff(log2((double)hdr->blksize));
	b1000.reserved = 0;
	ok = add_blockette (hdr, (char *)&b1000, 1000, sizeof(BLOCKETTE_1000), 
			    my_wordorder, 0);
	if (ok != 1) status = MS_ERROR;
    }
    return (status);
}

/************************************************************************/
/*  delete_unwanted_blockettes:						*/
/*	Delete any blockettes from hdr that should not be in output.	*/
/*  return:								*/
/*	0 on success.							*/
/************************************************************************/
int delete_unwanted_blockettes 
   (DATA_HDR	*hdr)		/* DATA_HDR for record.			*/
{
    BS *bs, *delete_bs;
    short int bl_type;
    for (bs=hdr->pblockettes,delete_bs=NULL;
	 bs!=NULL; 
	 bs=bs->next,delete_pblockette(hdr,delete_bs),delete_bs=NULL) {
	bl_type = bs->type;
        if (hdr->hdr_wordorder != my_wordorder) {
	    swab2 ((short int *)&bl_type);
	}
	if (strip_blockette(bl_type)) delete_bs = bs;
    }
    return (0);
}

/************************************************************************/
/*  merge_blockettes:							*/
/*	Merge blockettes from input hdr to output hdr, making sure that:*/
/*	1.  We have only a single copies of per_record_blockettes.	*/
/*	2.  We have only a single unique copy of each unique blockette.	*/
/*	3.  Optionally delete the blockette from the input record	*/
/*	    if is is not a per_record_blockette.			*/
/*  return:								*/
/*	0 on success.							*/
/*	negative QLIB2 error code on error.				*/
/************************************************************************/
int merge_blockettes 
   (DATA_HDR	*oh,		/* output record DATA_HDR.		*/
    DATA_HDR	*ih,		/* input record DATA_HDR.		*/
    int		op)		/* operation to be performed.		*/
{
    BS *bs, *bs2, *del_bs;
    int bl_type, bl_pos;
    int n;
    int identical, is_per_record, found;
    int copy_src, del_src, del_dest;
    int status = 0;
    /* Add any new input blockettes to the output blockette list.	*/
    /* Allow unique copies of blockettes that are not specific		*/
    /* to a data record.						*/
    del_bs = NULL;
    for (bs = ih->pblockettes; bs != NULL; bs=bs->next) {
	/* Delete previous blockette if required.   */
	if (del_bs && ((n = delete_pblockette (ih, del_bs)) != 1)) {
	    fprintf (stderr, "Error: unable to delete blockette.\n");
	}
	del_bs = NULL;
	bl_type = bs->type;
	bl_pos = (bl_type == 1000) ? 0 : -1;
	is_per_record = is_per_record_blockette(bl_type);
	if (strip_blockette(bl_type)) {
	    continue;
	}
	bs2=find_blockette(oh,bl_type);

	identical = (blockettecmp(bs,bs2) == 0);
	while ((! is_per_record) && (bs2 != NULL) && (! identical)) {
	    bs2 = find_pblockette (oh, bs2->next, bl_type);
	    identical = (blockettecmp(bs,bs2) == 0);
	}

	found = (bs2 != NULL);
	copy_src = del_src = del_dest = 0;
	if (is_per_record) {
	    /* Only worry about PER_RECORD operations. */
	    del_dest = (found && (! identical) && (op & (BL_PER_RECORD_UPDATE)));
	    copy_src = del_dest || ((! found) && (op & (BL_PER_RECORD_COPY | BL_PER_RECORD_MOVE)));
	    del_src = (copy_src && (op & (BL_PER_RECORD_MOVE)));
	}
	if (! is_per_record) {
	    /* Only worry about UNIQUE operations. */
	    del_src = (found && (! identical) && (op & (BL_UNIQUE_MOVE)));
	    copy_src = 
		((! found) && (op & (BL_UNIQUE_COPY | BL_UNIQUE_MOVE))) ||
		(found && (! identical) && (op & (BL_UNIQUE_COPY | BL_UNIQUE_MOVE)));
	}

	if (del_dest) delete_pblockette (oh, bs2);
	if (copy_src) {
	    int ok = add_blockette (oh, bs->pb, bs->type, bs->len, 
				    bs->wordorder, bl_pos);
	    if (ok != 1) status = MS_ERROR;
	}
	if (del_src) del_bs = bs;
    }
    /* Delete previous blockette if required.   */
    if (del_bs && ((n = delete_pblockette (ih, del_bs)) != 1)) {
	fprintf (stderr, "Error: unable to delete blockette.\n");
    }
    return (status);
}

/************************************************************************/
/*  write_ascii_stream:							*/
/*	Output data from block in ascii.				*/
/************************************************************************/
void write_ascii_stream
   (ST_INFO	*out)		/* ptr to output stream struct.		*/
{
    void *databuff = NULL;
    int *diffbuff = NULL;
    char str[256];
    int data_type, i;

    /* Allocate buffers only once.					*/
    if (diffbuff == NULL && 
	(diffbuff = (int *)malloc(out->cur_hdr->num_samples * sizeof(int))) == NULL ) {
	fprintf (stderr, "Error: unable to malloc diffbuff\n");
	exit(1);
    }

    if (databuff == NULL) {
      switch (out->cur_hdr->data_type) {
      case IEEE_FP_SP:
          databuff = (float *)malloc(out->cur_hdr->num_samples * sizeof(float));
	  break;
      case IEEE_FP_DP:
          databuff = (double *)malloc(out->cur_hdr->num_samples * sizeof(double));
	  break;
      default:
          databuff = (int *)malloc(out->cur_hdr->num_samples * sizeof(int));
	  break;
      }
      if (databuff == NULL ) {
	fprintf (stderr, "Error: unable to malloc databuff\n");
	exit(1);
      }
    }

    data_type = unpack_sdr_data (out, databuff, diffbuff, 0,
				 out->cur_hdr->num_samples);

    dump_hdr (out->cur_hdr, str, date_fmt);

    if (out->iob->fp) {
      if ( ! (debug(DEBUG_ASCII_1) && out->cont_blk > 0)) fputs (str, out->iob->fp);
      for (i=0; i<out->cur_hdr->num_samples; i++) {
	switch (out->cur_hdr->data_type) {
	case IEEE_FP_SP:
	  fprintf (out->iob->fp, "%g\n", ((float*)databuff)[i]);
	  break;
	case IEEE_FP_DP: {
	  fprintf (out->iob->fp, "%.14g\n", ((double*)databuff)[i]);
	  break;
	}
	default:
	  fprintf (out->iob->fp, "%d\n", ((int*)databuff)[i]);
	  break;
	}
       }
       fflush (out->iob->fp);
    }
    free (databuff);
    free (diffbuff);

    ++(out->num_blk);
    ++(out->cont_blk);
    out->num_samples += out->cur_hdr->num_samples;
}

/************************************************************************/
/*  build_diff:								*/
/*	Build a first difference buffer required for STEIM compression.	*/
/************************************************************************/
void build_diff (
    int		*data,
    int		*diff,
    int		nsamples,
    int		prev)
{
    int i;
    for (i=0; i<nsamples; i++) {
	diff[i] = data[i] - prev;
	prev = data[i];
    }
}

/************************************************************************/
/*  init_out_hdr:							*/
/*	Initialize a output DATA_HDR structure with info derived from	*/
/*	the current input DATA_HDR and info from the output stream.	*/
/************************************************************************/
void init_out_hdr 
   (DATA_HDR	*oh,
    DATA_HDR	*ih,
    ST_INFO	*out)
{
    DATA_HDR	    *pcopy;
    int seq_no = oh->seq_no;
    if (oh->pblockettes != NULL) delete_blockette (oh, -1);
    pcopy = copy_data_hdr (oh, ih);
    if (pcopy == NULL) {
	fprintf (info, "Error: copying data_hdr\n");
	exit(1);
    }
    if (add_required_blockettes (oh) != 0) {
	fprintf (info, "Error: adding required blockettes\n");
	exit(1);
    }
    if (merge_blockettes (oh, ih, BL_UNIQUE_MOVE + BL_PER_RECORD_COPY + BL_PER_RECORD_UPDATE) != 0) {
	fprintf (info, "Error: merging blockettes\n");
	exit(1);
    }
    oh->data_type = out->data_type;
    oh->blksize = output_blksize;
    oh->num_samples = 0;
    oh->num_data_frames = 0;
    oh->first_data = 48;
    oh->data_wordorder = output_data_wordorder;
    oh->hdr_wordorder = output_hdr_wordorder;
    oh->seq_no = seq_no;
}

/************************************************************************/
/*  update_b1000:							*/
/*	Update a blockette 1000 with correct values for the record.	*/
/************************************************************************/
void update_b1000
   (DATA_HDR	*oh,
    int		blksize,
    int		data_type)
{
    BS *bs;
    if ((bs=find_blockette(oh, 1000))) {
	/* Ensure we have proper output blocksize in the blockette.	*/
	BLOCKETTE_1000 *b = (BLOCKETTE_1000 *) bs->pb;
	/* These are all byte values, so I can ignore wordorder.	*/
	b->data_rec_len = roundoff(log2((double)blksize));
	b->format = data_type;
    }
}

/************************************************************************/
/*  update_b1001:							*/
/*	Update a blockette 1001 with correct values for the record.	*/
/************************************************************************/
void update_b1001
   (DATA_HDR	*oh,
    int		num_data_frames)
{
    BS *bs;
    if ((bs=find_blockette(oh, 1001))) {
	/* Ensure we have proper # of frames in the blockette.		*/
	BLOCKETTE_1001 *b = (BLOCKETTE_1001 *) bs->pb;
	/* These are all byte values, so I can ignore wordorder.	*/
	b->frame_count = num_data_frames;
    }
}

/************************************************************************/
/*  best_rate:								*/
/*	Return "best" nominal sample rate for channel.			*/
/************************************************************************/
double best_rate (DATA_HDR *hdr)
{
    double drate = -1.0;
    BS *bs;
    if ((bs=find_blockette(hdr,100)) != NULL) {
	if (bs->wordorder == my_wordorder) {
	    BLOCKETTE_100 *b = (BLOCKETTE_100 *) bs->pb;
	    if (bs->wordorder != my_wordorder) {
		swab_blockette (bs->type, bs->pb, bs->len);
		bs->wordorder = my_wordorder;
	    }
	    drate = b->actual_rate;
	}
	else {
	    char *p;
	    int l = bs->len;
	    if ((p = (char *)malloc (l * sizeof(char)))!= NULL) {
		BLOCKETTE_100 *b = (BLOCKETTE_100 *) p;
		memcpy (p,bs->pb,l);
		swab_blockette (100,p,l);
		drate = b->actual_rate;
		free (p);
	    }
	}
    }
    else {
	drate = sps_rate(hdr->sample_rate,hdr->sample_rate_mult);
    }
    return (drate);
}

/************************************************************************/
/*  transform_data__buffer:						*/
/*	Transform buffer from one data type to another.		*/
/************************************************************************/
void transform_data_buffer (
    int		src_fmt,		/* source data format.		 */
    int		dest_fmt)		/* destination data format.	 */
{
  int *p_int;
  float *p_float;
  double *p_double;
  int i;

  if(src_fmt == dest_fmt)
    return;

  memcpy(tmpbuff, databuff, max_num_samples*sizeof(double));

  /* int -> float */
  if(src_fmt == DATA_FMT_INT) {
    p_int = (int*)tmpbuff;

    if(dest_fmt == DATA_FMT_FLOAT) {
      p_float = (float*)databuff;
      for(i=0; i<max_num_samples; i++) {
	p_float[i] = (float)p_int[i];
      }
    }

    /* int -> double */
    if(dest_fmt == DATA_FMT_DOUBLE) {
      p_double = (double*)databuff;
      for(i=0; i<max_num_samples; i++) {
	p_double[i] = (double)p_int[i];
      }
    }
  }

  if(src_fmt == DATA_FMT_FLOAT) {
    p_float = (float*)tmpbuff;

    /* float -> int */
    if(dest_fmt == DATA_FMT_INT) {
      p_int = (int*)databuff;
      for(i=0; i<max_num_samples; i++) {
	p_int[i] = (int)p_float[i];
      }
    }

    /* float -> double */
    if(dest_fmt == DATA_FMT_DOUBLE) {
      p_double = (double*)databuff;
      for(i=0; i<max_num_samples; i++) {
	p_double[i] = (double)p_float[i];
      }
    }
  }


  if(src_fmt == DATA_FMT_DOUBLE) {
    p_double = (double*)tmpbuff;

    /* double -> int */
    if(dest_fmt == DATA_FMT_INT) {
      p_int = (int*)databuff;
      for(i=0; i<max_num_samples; i++) {
	p_int[i] = (int)p_double[i];
      }
    }

    /* double -> float */
    if(dest_fmt == DATA_FMT_DOUBLE) {
      p_float = (float*)databuff;
      for(i=0; i<max_num_samples; i++) {
	p_float[i] = (float)p_double[i];
      }
    }
  }

  return;
}
