/************************************************************************/
/*  Routines for qmerge.						*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

/*	$Id: procs.h,v 1.12 2014/09/12 22:17:33 doug Exp $ 	*/

#ifdef __cplusplus
extern "C" {
#endif

ST_INFO *find_best_stream 
   (ST_INFO	*in_p,		/* ptr to current input stream.		*/
    ST_INFO	*out_p,		/* ptr to output stream.		*/
    INT_TIME	*stime,		/* ptr to desired start time, or NULL.	*/
    INT_TIME	*etime,		/* ptr to desired end time, or NULL.	*/
    int		bias);		/* bias flag for best stream selection.	*/

void get_block_info
   (ST_INFO	*st_p);		/* ptr to current stream header.	*/

int get_stream_info 
   (ST_INFO	*st_p);		/* ptr to current stream header.	*/

int get_header_type 
   (char    *p,			/* ptr to buffer containing header.	*/
    int	    nr);		/* max number of bytes for header.	*/

int unpack_sdr_data
   (ST_INFO	*st_p,		/* ptr to input stream structure.	*/
    void	*databuff,	/* ptr to data array.			*/
    int		*diffbuff,	/* ptr to difference array.		*/
    int         offset,         /* start index of data array            */
    int		req_samples);	/* # samples to request (neg -> fast).	*/

int get_first_info
   (ST_INFO	*st_p,		/* ptr to input stream structure.	*/
    int		*px0,		/* ptr to first value X0 (returned).	*/
    int		*pd0);		/* ptr to first difference (returned).	*/

int repack_sdr_data 
   (void	*p_sdf,		/* ptr to SDR structure.		*/
    void	*data,		/* unpacked data array.			*/
    int		diff[],		/* unpacked diff array.			*/
    int		ns,		/* num_samples.				*/
    int		nb,		/* max number of data bytes.		*/
    int		format,		/* current data format.			*/
    int		pad,		/* flag to specify padding to nf.	*/
    int		wordorder,	/* wordorder of data.			*/
    int		*pnbytes,	/* number of bytes actually packed.	*/
    int		*pnsamples);	/* number of samples actually packed.	*/

int parse_cmdline 
   (int		*pargc,		/* ptr to argc.				*/
    char	***pargv);	/* ptr to argv.				*/

int get_blksize
   (char	*str);		/* string containing blksize.		*/

RANGE *parse_range
   (char	*optarg);	/* string containing blockette range.	*/

RANGE *make_strip_list 
   (char	*str,		/* blockette list and/or range string.	*/
    double	version);	/* seed version number.			*/

int position_stream
   (ST_INFO	*st_p,		/* ptr to current input stream.		*/
    INT_TIME	*stime,		/* ptr to desired start time.		*/
    INT_TIME	*etime);	/* ptr to desired end time.		*/

int process_block 
   (ST_INFO	*st_p,		/* ptr to input stream info.		*/
    int		new_stream);	/* boolean flag - true if new stream.	*/

void trim_data 
   (ST_INFO	*st_p,		/* ptr to input stream struct.		*/
    int		begin_trim_pts,	/* # points to discard on head.		*/
    int		end_trim_pts,	/* # points to discard on tail.		*/
    int		split_offset,	/* sample offset to split record.	*/
    int		new_d0_flag,	/* flag to set new init diff.		*/
    int		new_d0,		/* new initial diff value.		*/
    int		blksize,	/* desired output blksize.		*/
    int		data_type_out,	/* desired output data format.		*/
    RECORD_LIST	record_list[],	/* list of records.			*/
    int		max_records);	/* max number of records in list.	*/

int merge_tol
   (int		rate,		/* sample rate in qlib convention.	*/
    int		rate_mult);	/* sample rate_mult in qlib convention.	*/

int tol
   (int		rate,		/* sample rate in qlib convention.	*/
    int		rate_mult);	/* sample rate_mult in qlib convention.	*/

void write_seed_hdr
   (ST_INFO	*st_p,		/* ptr to input stream struct.		*/
    SDR_HDR	*sh);		/* ptr to SEED Data Header.		*/

int merge_flags 
   (DATA_HDR	*oh,		/* ptr to output record DATA_HDR.	*/
    DATA_HDR	*ih);		/* ptr to intput record DATA_HDR.	*/

int merge_check
   (DATA_HDR	*oh,		/* ptr to output record DATA_HDR.	*/
    DATA_HDR	*ih,		/* ptr to input record DATA_HDR.	*/
    int		output_slew_threshold,	/* max output slew threshold.	*/
    double	bdif);		/* slew between this and prev record.	*/

int flush_record
   (ST_INFO	*out,		/* ptr to output stream struct.		*/
    int		nrecords);	/* # of records to flush (<0 -> all)	*/ 

int append_to_output 
   (ST_INFO	*st_p,		/* ptr to ouput stream struct.		*/
    int		slew);		/* slew between this and prev record.	*/

int pad_out
   (ST_INFO	*out,		/* ptr to output stream struct.		*/
    int		data_bytes,	/* # of data bytes in output record.	*/
    int		pad_len);	/* # of bytes to pad record.		*/

int flush_output
   (ST_INFO	*out,		/* ptr to output stream struct.		*/
    int		nrecords);	/* # of records to flush (<0 -> all)	*/ 

int hdr_cmp
   (DATA_HDR	*hdr1,		/* ptr to first DATA_HDR.		*/
    DATA_HDR	*hdr2);		/* ptr to second DATA_HDR.		*/

int same_type_data_stream 
   (DATA_HDR	*ih,		/* ptr to first DATA_HDR.		*/
    DATA_HDR	*oh);		/* ptr to second DATA_HDR.		*/

int same_rate_data_stream 
   (DATA_HDR	*ih,		/* ptr to first DATA_HDR.		*/
    DATA_HDR	*oh);		/* ptr to second DATA_HDR.		*/

void make_out_sum_hdr
   (ST_INFO	*out,		/* output structure.			*/
    ST_INFO	*st_p);		/* input structure.			*/

void make_out_cur_hdr
   (ST_INFO	*out);		/* ptr to output stream struct.		*/

int verify_block 
   (ST_INFO	*st_p);		/* ptr to input stream struct.		*/

int is_per_record_blockette 
   (int		n);		/* blockette number.			*/

int strip_blockette 
   (int		n);		/* blockette number.			*/

int add_required_blockettes 
   (DATA_HDR	*hdr);		/* DATA_HDR for record.			*/

int delete_unwanted_blockettes 
   (DATA_HDR	*hdr);		/* DATA_HDR for record.			*/

int merge_blockettes 
   (DATA_HDR	*oh,		/* output record DATA_HDR.		*/
    DATA_HDR	*ih,		/* input record DATA_HDR.		*/
    int		delete_flag);	/* delete_flag.				*/

void write_ascii_stream
   (ST_INFO	*out);		/* ptr to output stream struct.		*/

void build_diff (
    int		*data,
    int		*diff,
    int		nsamples,
    int		prev);

void init_out_hdr 
   (DATA_HDR	*oh,
    DATA_HDR	*ih,
    ST_INFO	*out);

void update_b1000
   (DATA_HDR	*oh,
    int		blksize,
    int		data_type);

void update_b1001
   (DATA_HDR	*oh,
    int		num_data_frames);

double best_rate (DATA_HDR *hdr);

ST_INFO *flush_file 
   (ST_INFO	*out,		/* ptr to output stream struct.		*/
    int		close_flag);	/* flag to close file.			*/

ST_INFO *open_stream
   (ST_INFO	*phead,		/* ptr to stream struct linked list.	*/
    char	*file,		/* filename to open.			*/
    char	*mode);		/* mode for open.			*/

ST_INFO *limit_stream (
    ST_INFO	*p,		/* ptr to ST_INFO file structure.	*/
    off_t	ioffset,	/* initial offset.			*/
    off_t	streamlimit);	/* length of stream.			*/

int suspend_stream 
   (ST_INFO	*phead);	/* ptr to stream struct linked list.	*/

int suspend_file 
   (ST_INFO	*phead);	/* ptr to stream struct linked list.	*/

int reopen_file
   (ST_INFO	*st_p);		/* ptr to stream struct to reopen.	*/

ST_INFO *close_stream
   (ST_INFO	*st_p);		/* ptr to stream struct to close.	*/

int fill_buffer
   (ST_INFO	*st_p,		/* ptr to input stream struct.		*/
    int		n);		/* number of bytes desired in IOB.	*/

void write_stream
   (ST_INFO	*out);		/* ptr to output stream struct.		*/

IOB *new_iob (void);

IOB *dup_iob 
   (IOB *old_iob);		/* ptr to IOB to be duplicated.		*/

void free_iob 
   (IOB *iob);			/* ptr to IOB to free.			*/

void print_stream_summary
   (ST_INFO	*out_p);	/* ptr to ouput stream struct.		*/

int parse_duration
   (char	*str);		/* duration string.			*/

void compute_duration 
   (DATA_HDR	*hdr);		/* DATA_HDR for record.			*/

int after_duration
   (DATA_HDR	*hdr);		/* DATA_HDR for record.			*/

int cross_duration
   (DATA_HDR	*hdr);		/* DATA_HDR for record.			*/

int intersect_duration
   (DATA_HDR	*hdr);		/* DATA_HDR for record.			*/

char *build_filename
   (DATA_HDR	*hdr,		/* DATA_HDR for record.			*/
    char	*pattern);	/* filename pattern.			*/

void transform_data_buffer (
    int		src_fmt,		/* source data format.		 */
    int		dest_fmt);		/* destination data format.	 */

#ifdef __cplusplus
}
#endif
