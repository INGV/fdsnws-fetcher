/************************************************************************/
/* Input and output channel info structure.				*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

/*	$Id: st_info.h,v 1.10 2014/09/12 22:17:33 doug Exp $ 	*/

/************************************************************************/
/*  Channel information structure.  One allocated for each file.	*/
/*  This is used to store channel information in a manner that is	*/
/*  independent of both the input and output format.			*/
/************************************************************************/

#include <sys/param.h>

#define	ST_CHANNEL_LEN	5
#define	ST_STATION_LEN	8

typedef struct _iob {
    off_t	    pos;	/* position in file if closed.		*/
    char	    mode[4];	/* mode for opening file.		*/
    FILE	    *fp;	/* file pointer for output data file.	*/
    int		    deferred;	/* file opening deferred.		*/
    int		    bufsize;	/* size of buffer.			*/
    int		    avail;	/* index of next input byte.		*/
    int		    free;	/* index of next free byte.		*/
    double          dummy;      /* align buf on double word boundry     */
    char	    buf[BUFSIZE];	/* actual data buffer.		*/
} IOB;

typedef struct _st_info {
    char	    station[8]; /* name of station.			*/
    char	    channel[4];	/* name of channel.			*/
    char	    network[4];	/* name of network.			*/
    char	    location[4];/* name of location.			*/
    char	    filename[MAXPATHLEN];   /* filename of input file.	*/
    off_t	    ioffset;	/* initial stream offset.		*/
    off_t	    streamlimit;/* # of bytes left to read in stream,	*/
				/* negative means read to eof.		*/
    INT_TIME	    begtime;	/* beginning time of data stream.	*/
    INT_TIME	    endtime;	/* end time of data stream.		*/
    int		    hdr_type;	/* type of input data stream.		*/
    int		    blksize;	/* input blocksize.			*/
    int		    data_type;	/* data type of stream.			*/
    int		    rate;	/* data rate of stream.			*/
    int		    rate_mult;	/* data rate_mult of stream.		*/
    int		    cont_blk;	/* # of continuous data records.	*/
    int		    num_blk;	/* # of data records written for comp.	*/
    int		    cur_slew;	/* current slew for this record.	*/
    int		    total_slew;	/* total time slew in ticks.		*/
    int		    max_slew;	/* maximum slew at any time.		*/
    int		    min_slew;	/* minimum slew at any time.		*/
    int		    max_step;	/* abs(max slew step per record).	*/
    int		    num_blocks;	/* # of records read from this file.	*/
    int		    used;	/* has the stream been used yet.	*/
    FILE	    *tp;	/* file pointer for time corr data file.*/
    char	    *vfh;	/* volume file hdr for telemetry files.	*/
    DATA_HDR	    *sum_hdr;	/* ptr to summary header structure.	*/
    DATA_HDR	    *prev_hdr;	/* ptr to previous header structure.	*/
    DATA_HDR	    *last_hdr;	/* ptr to most recent header structure.	*/
    DATA_HDR	    *cur_hdr;	/* ptr to current header structure.	*/
    int		    num_samples;/* # of samples, pointed to by data.	*/
    IOB		    *iob;	/* i/o buffer for buffered i/o.		*/
    struct _st_info *next;	/* ptr to next stream structure in list.*/
    struct _st_info *prev;	/* ptr to prev stream structure in list.*/
} ST_INFO;

typedef struct _record_list {
    DATA_HDR	*hdr;		/* ptr to DATA_HDR for record.		*/
    IOB		*iob;		/* I/O structure for record.		*/
} RECORD_LIST;
