/************************************************************************/
/*  Command line parsing routines.					*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef lint
static const char sccsid[] = "$Id: parse_cmdline.c,v 1.23 2014/09/12 22:17:33 doug Exp $ ";
#endif

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <sys/stat.h>
#include <ctype.h>
#include <libgen.h>

#define BUF_SIZE 2048

#include "qlib2.h"

#include "params.h"
#include "st_info.h"
#include "procs.h"
#include "externals.h"

static int str_cp (char *dest, char **sp, char t);
static int num_cp (int *val, char **sp, int n);
static int parse_filename (char *filename, char *pattern);

void split_fileinfo
   (char *str, 
    char *filename, 
    off_t *ioffset,
    off_t *streamlimit);

#define	argc	(*pargc)
#define	argv	(*pargv)

/************************************************************************/
/*  parse_cmdline:							*/
/*	Parse command line.						*/
/************************************************************************/
int parse_cmdline 
   (int		*pargc,		/* ptr to argc.				*/
    char	***pargv)	/* ptr to argv.				*/
{
    char    *span = NULL;
    int	    span_flag = 0;
    char    *p;
    INT_TIME	*pt;

    /* Variables needed for getopt. */
    extern char	*optarg;
    extern int	optind, opterr;
    int		c;

    int	nfiles = 0;
    char *blksize_str = NULL;
    char *strip_blockette_str = NULL;

    char *file_list_file =  NULL;
    FILE *ListFILE;
    char line_buffer[BUF_SIZE];
    char filename[BUF_SIZE];
    off_t ioffset;
    off_t streamlimit;
    int n;
    int s;
    int my_wordorder;
    int wordorder_found = 0;
    int hdr_wordorder_found = 0;
    int data_wordorder_found = 0;
    char R = 0;
    ST_INFO *st_p;
    
    char *opts;
    char *qmerge_opts =  "hnTvcaeurHml:G:g:d:b:o:i:f:t:s:x:D:S:C:L:N:V:F:I:O:P:p:X:w:R:";
/*  char *qverify_opts = "hvnf:t:s:G:g:d:i:D:S:C:L:N:V:I:R:"; */

    cmdname = basename(*argv);
    if ((my_wordorder = get_my_wordorder()) < 0) {
	fprintf (info, "Error: determining computer wordorder\n");
	exit(1);
    }
    seed_version = 2.3;
    default_network_id = DEFAULT_NETWORK;
    stream_tol = -1;
    block_tol = -1;
    output_blksize = DEFAULT_OUTPUT_BLKSIZE;
    output_hdr_wordorder = SEED_BIG_ENDIAN;
    output_data_wordorder = SEED_BIG_ENDIAN;
    set_hdr_wordorder(output_hdr_wordorder);
    set_data_wordorder(output_data_wordorder);
    input_data_fmt = STEIM1;
    output_data_fmt = UNKNOWN_DATATYPE;
    duration_date_flag = 'n';		/* use nominal date in fname.	*/
    output_record_type = '\0';
#ifndef	NO_AUTO_VERIFY
    verify_data = 1;
#endif
    syntax = qmerge_syntax;
    opts = qmerge_opts;
    if (strcmp(cmdname,"qverify")==0) {
	char *p;
	qverify = 1;
	verify_data = 1;
	syntax = qverify_syntax;
	opts = qmerge_opts;
	no_output = 1;
	if ((p=getenv("QVERIFY_PATTERN"))) {
	    verify.pattern = p;
	}
    }
    if (strcmp(cmdname,"Rmerge")==0) R = 'R';
    if (strcmp(cmdname,"Dmerge")==0) R = 'D';
    if (strcmp(cmdname,"Qmerge")==0) R = 'M';
    if (strcmp(cmdname,"Qmerge")==0) R = 'Q';
    if (R != 0) {
	if (! ((output_record_type = set_record_type(R)) == R)) {
	    fprintf (info, "Error: Invalid Record Type Quality char: %c\n", R);
	    exit(1);
	}
    }

    /*	Parse command line options.					*/
    while ( (c = getopt(argc,argv,opts)) != -1)
	switch (c) {
	case '?':
	case 'h':   print_syntax(cmdname,syntax,info); exit(0); break;
	case 'n':   
	    if (qverify) ++quiet; else ++no_output; 
	    break;
	case 'T':   ++exact_trim; break;
	case 'v':   ++verify_data; break;
	case 'c':   ++make_index; break;
	case 'a':   ++append_output; break;
	case 'e':   ++event_only_flag; break;
	case 'u':   ++unique_flag; break;
	case 'r':   ++repack_flag; break;
	case 'H':   ++print_file_hdr; break;
	case 'l':   stream_delimiter = optarg[0]; break;
	case 'd':   debug_option = atoi(optarg); break;
	case 'G':   stream_tol = atoi(optarg) * USECS_PER_TICK; break;
	case 'g':   block_tol = atoi(optarg) * USECS_PER_TICK; break;
	case 'b':   blksize_str = optarg; break;
	case 'o':   outfile = optarg; break;
	case 'x':   strip_blockette_str = optarg; break;
	case 'm':   multichannel++; ignore_hdr++; break;
	case 'S':   
	    if (qverify) {
		if ((n=strlen(optarg)) > SDR_STATION_LEN) return (-1);
		strcpy (verify.station_id, optarg);
		uppercase(verify.station_id);
		++verify.station_flag;
	    }
	    else station_id = optarg;
	    break;
	case 'C':
	    if (qverify) {
		if ((n=strlen(optarg)) > SDR_CHANNEL_LEN) return (-1);
		strcpy (verify.channel_id, optarg);
		uppercase(verify.channel_id);
		++verify.channel_flag;
	    }
	    else channel_id = optarg; 
	    break;
	case 'N':
	    if (qverify) {
		if ((n=strlen(optarg)) > SDR_NETWORK_LEN) return (-1);
		strcpy (verify.network_id, optarg);
		uppercase(verify.network_id);
		++verify.network_flag;
	    }
	    else network_id = optarg;
	    break;
	case 'L':
	    if (qverify) {
		if ((n=strlen(optarg)) > SDR_LOCATION_LEN) return (-1);
		strcpy (verify.location_id, optarg);
		uppercase(verify.location_id);
		++verify.location_flag;
	    }
	    else location_id = optarg;
	    break;
	case 'V':   
	    if (qverify) verify.pattern = optarg;
	    else seed_version = atof(optarg); 
	    break;
	case 'F':   file_list_file = optarg; break;
	case 'w':
	    p = optarg;
	    wordorder_found = 0;
	    while (p && *p) {
		if (strcasecmp(optarg, "0") == 0 || strcasecmp(optarg, "1") == 0) { 
		    output_hdr_wordorder = atoi(optarg);
		    output_data_wordorder = output_hdr_wordorder;
		    set_hdr_wordorder(output_hdr_wordorder); 
/*::		    set_data_wordorder(output_data_wordorder); */
		    hdr_wordorder_found = 1;
		    data_wordorder_found = 1;
		    wordorder_found = 1;
		    p += 1;
		    continue;
		}
		if (strcasecmp(optarg, "h0") == 0 || strcasecmp(optarg, "h1") == 0) { 
		    output_hdr_wordorder = atoi(optarg+1);
		    set_hdr_wordorder(output_hdr_wordorder); 
		    hdr_wordorder_found = 1;
		    wordorder_found = 1;
		    p += 2;
		    continue;
		}
		if (strcasecmp(optarg, "d0") == 0 || strcasecmp(optarg, "d1") == 0) { 
		    output_data_wordorder = atoi(optarg+1);
/*::		    set_data_wordorder(output_data_wordorder); */
		    data_wordorder_found = 1;
		    wordorder_found = 1;
		    p += 2;
		    continue;
		}
		p = NULL;
	    }
	    if (! wordorder_found) {
		fprintf (info, "Error: invalid wordorder option: %s\n", optarg);
		exit(1);
	    }
	    break;
	case 'I':   
	    input_data_fmt = decode_data_format(optarg); 
	    if (qverify) {
		verify.input_data_fmt = input_data_fmt;
		++verify.input_data_fmt_flag;
	    }
	    break;
	case 'O':
	    output_data_fmt = decode_data_format(optarg); 
	    if (output_data_fmt == UNKNOWN_DATATYPE) {
		fprintf (stderr, "Error: invalid output datatype specified\n");
		exit(1);
	    }
	    break;
	case 'P':   file_duration = optarg; break;
	case 'p':   duration_date_flag = optarg[0]; break;
	case 'i':
	    /* Ignore some type of information. */
	    if (strcasecmp(optarg, "time") == 0) { ++ignore_hdr; break; }
	    if (strcasecmp(optarg, "rate") == 0) { ++ignore_rate; break; }
	    if (strcasecmp(optarg, "d0") == 0) { ++ignore_d0_errors; break; }
	    if (strcasecmp(optarg, "No_d0") == 0) { ++ignore_d0_fixing; break; }
	    if (strcasecmp(optarg, "dq") == 0) { ++ignore_dq; break; }
	    if (qverify && strcasecmp(optarg, "V") == 0) { ++verify.ignore_pattern; break; }
	    fprintf (info, "Error: invalid ignore option: %s\n", optarg);
	    exit(1);
	    break;
	case 'f':
	    if ((pt = parse_date (optarg)) == NULL) {
		fprintf (info, "Error: invalid date: %s\n", optarg);
		exit(1);
	    }
	    start_time = *pt;
	    ++start_flag;
	    break;
	case 't':
	    if ((pt = parse_date (optarg)) == NULL) {
		fprintf (info, "Error: invalid date: %s\n", optarg);
		exit(1);
	    }
	    end_time = *pt;
	    ++end_flag;
	    break;
	case 's':
	    span = optarg; ++span_flag; break;
	case 'D':
	    /* Date display format.   */
	    if (strcmp (optarg, "j") == 0) date_fmt = JULIAN_FMT;
	    else if (strcmp (optarg, "j,") == 0) date_fmt = JULIAN_FMT_1;
	    else if (strcmp (optarg, "m") == 0) date_fmt = MONTH_FMT;
	    else if (strcmp (optarg, "m,") == 0) date_fmt = MONTH_FMT_1;
	    else {
		fprintf (info, "Error: invalid format for date display: %s\n", optarg);
		exit(1);
	    }
	    break;
	case 'R':
	    R = optarg[0];
	    if (islower(R)) R = toupper(R);
	    if (! ((output_record_type = set_record_type(R)) == R)) {
		fprintf (info, "Error: Invalid Record Type Quality char: %c\n", R);
		exit(1);
	    }
	    break;
	default:
	    fprintf (info, "Error: unknown option: %c\n", c);
	    exit(1);
	}
    stripped_blockette = make_strip_list (strip_blockette_str, seed_version);
    if (make_index) ++no_output;
    if (multichannel && (station_id || network_id || channel_id || location_id ||
			 file_duration || make_index || print_file_hdr)) {
	fprintf (info, "Error: one or more specified options are mutually exclusive with multichannel option\n");
	exit(1);
    }
    if (file_duration) {
	if (parse_duration (file_duration) < 0) {
	    fprintf (info, "Error: invalid duration: %s\n", file_duration);
	    exit(1);
	}
	if (outfile) {
	    filename_pattern = outfile;
	    outfile = NULL;
	}
    }
    if (! (duration_date_flag == 'n' || duration_date_flag == 'd')) {
	fprintf (stderr, "Error: Invalid option: -p%c\n", duration_date_flag);
	exit(1);
    }
    if (no_output) outfile = "/dev/null";
    if (outfile == NULL && ! file_duration) info = stderr;
    if (end_flag && span_flag) {
	fprintf (stderr, "Error: span and endtime mutually exclusive\n");
	exit(1);
    }
    if (span_flag && !start_flag) {
	fprintf (stderr, "Error: span not valid without start time\n");
	exit(1);
    }
    if (span_flag && ! valid_span(span)) {
	    fprintf (stderr, "Error: invalid span specification: %s\n", span);
	    exit(1);
	}
    if (span_flag) {
	if (! valid_span(span)) {
	    fprintf (info, "Error: invalid timespan: %s\n", span);
	    exit(1);
	}
	end_time = end_of_span (start_time, span);
	++end_flag;
    }
    if (qverify) {
	verify.start_time = start_time;
	verify.end_time = end_time;
	verify.start_flag = start_flag;
	verify.end_flag = end_flag;
	start_flag = end_flag = 0;
	verify.record_type = (output_record_type) ? output_record_type : ' ';
    }
    if (blksize_str) {
	output_blksize = get_blksize(blksize_str);
	if (output_blksize < 0 || output_blksize > MAX_BLKSIZE) {
	    fprintf (stderr, "Error: Invalid blksize: %s\n", blksize_str);
	    exit(1);
	}
	if (qverify) {
	    verify.blksize = output_blksize;
	    verify.blksize_flag++;
	}
    }
    if (input_data_fmt == UNKNOWN_DATATYPE) {
	fprintf (stderr, "Error: invalid input datatype specified\n");
	exit(1);
    }

    /* NOTE:  2005/04/05    Doug Neuhauser				*/
    /* Each specific data format is endian-specific.			*/
    /* Therefore, do not allow users to specify a data wordorder.	*/
    if (data_wordorder_found && (output_data_fmt != UNKNOWN_DATATYPE)) {
	fprintf (info, "Warning: Data format may override specified data wordorder.\n");
	/* WARNING - THIS MAY CHANGE */
	/* Currently all defined MSEED data formats are big-endian. */
	output_data_wordorder = SEED_BIG_ENDIAN;
	set_data_wordorder(output_data_wordorder); 
    }

    outmode = (append_output) ? "a" : "w";
    /* If file_duration, defer actual filename an opening until later.	*/
    if (file_duration) outfile = "";
    open_stream (&st_head_out, outfile, outmode);
    st_head_out.blksize = output_blksize;
    st_head_out.data_type = output_data_fmt;
    if (st_head_out.next != NULL) {
	ST_INFO	*out = st_head_out.next;
	out->data_type = output_data_fmt;
	out->blksize = output_blksize;
    }
    else {
	fprintf (info, "Error: unable to open output file.\n:");
	exit(1);
    }

    /*	Skip over all options and their arguments.			*/
    argv = &(argv[optind]);
    argc -= optind;

    /* If the user specified a file_list_file, then open the		*/
    /* file_list_file and read the names of the data files from it.	*/
    /* Otherwise, the remaining arguments are the input files.		*/
    /* If there is not file_list_file or data files on the cmdline,	*/
    /* then assume 1 file from stdin.					*/
    /* Open the files and allocate the appropriate data structures.	*/

    if (qverify) {
	if (verify.ignore_pattern) verify.pattern = "";
	if (file_list_file) {
	    fprintf (info, "Error: file_list_file not valid in this version of the program\n");
	    exit(1);
	}
	if (argc != 1) {
	    fprintf (info, "Error: One and only one filename must be specified\n");
	    exit(1);
	}
	if (! verify.pattern) {
	    char *p, *q, c;
	    /* Remove the double %% from the default pattern. */
	    verify.pattern = strdup(DEFAULT_VERIFY_PATTERN);
	    p = verify.pattern;
	    q = DEFAULT_VERIFY_PATTERN;
	    while (*q) {
		c = *(p++) = *(q++);
		if (c == '%' && *q == '%') q++;
	    }
	    *p = '\0';
	}
	if (! verify.pattern) {
	    fprintf (info, "Error: No verify pattern specified for filename.\n");
	    exit(1);
	}
    }

    if (file_list_file) {
	if ((ListFILE = fopen(file_list_file, "r")) == NULL) {
	    fprintf (info, "Error: Unable to open file_list_file: %s\n", file_list_file);
	    exit(1);
	}
	while (fgets(line_buffer, BUF_SIZE - 1, ListFILE) != NULL) {
	    if (line_buffer[0] == '#')
		continue;  /* skip it, it's a comment */
	    /* remove the newline */
	    s = strlen(line_buffer);
	    line_buffer[s - 1] = '\0';
	    split_fileinfo(line_buffer, filename, &ioffset, &streamlimit);
	    st_p = open_stream (&st_head_in, line_buffer, "r");
	    limit_stream (st_p, ioffset, streamlimit);
	    ++nfiles;
	    if (nfiles > 1 && multichannel) {
		fprintf (info, "Error: only one input file allowed with -m option\n");
		exit(1);
	    }
	}
	fclose(ListFILE);
    }
    else {
	nfiles = argc;
	if (nfiles > 1 && multichannel) {
	    fprintf (info, "Error: only one input file allowed with -m option\n");
	    exit(1);
	}
	do {
	    if (qverify) {
		if (parse_filename(*argv, verify.pattern) != 0) {
		    fprintf (info, "Error: matching filename %s to verify pattern %s.\n",
			     *argv, verify.pattern);
		    exit(1);
		}
	    }
	    if (nfiles > 0) {
		strcpy (line_buffer, *argv++);
		split_fileinfo(line_buffer, filename, &ioffset, &streamlimit);
		st_p = open_stream (&st_head_in, filename, "r");
		limit_stream (st_p, ioffset, streamlimit);
	    }
	    else {
		st_p = open_stream (&st_head_in, NULL, "r");
	    }
	} while (--argc > 0);
    }

    return(0);
}

/************************************************************************/
/*  get_blksize:							*/
/*	Parse blksize_str and return blocksize.  Ensure it is valid, ie	*/
/*	it is a power of 2, and within the valid blksize boundaries.	*/
/*	Return -1 on error.						*/
/************************************************************************/
int get_blksize
   (char	*str)		/* string containing blksize.		*/
{
    int blksize, n, m;
    char *p;
    blksize = strtol (str, &p, 10);
    switch (*p) {
      case 0:	break;
      case 'k':
      case 'K':	blksize *= 1024; break;
      default:	blksize = -1;
    }
    if (blksize < 0) return (-1);
    if (blksize == 0) return (0);
    n = (int)roundoff(log2((double)blksize));
    m = (int)pow(2.0,(double)n);
    if (m != blksize) return (-1);
    return (blksize);
}

/************************************************************************/
/*  parse_range:							*/
/*	Parse a range string of the format:				*/
/*	    i | i-j[,k-l]* | all					*/
/*	Return a ptr to the malloced range array.  Range array is	*/
/*	terminated by a (0,0) value.					*/
/************************************************************************/
RANGE *parse_range
   (char	*optarg)	/* string containing blockette range.	*/
{
    char *str = optarg;
    char *p;
    int first, last;
    int n = 0;
    RANGE *r = NULL;

    if (optarg == NULL) return (NULL);
    r = (RANGE *)malloc (sizeof(RANGE));
    if (strcasecmp(str, "all")==0) {
	r[n].first = 1;
	r[n].last = 65536;
	n++;
	r = (RANGE *)realloc (r, (n+1) * sizeof(RANGE));
    }
    else {
	while (*str != '\0') {
	    first = strtol (str, &p, 10);
	    if (first == 0) {
		fprintf (stderr, "Error: Invalid blockette list: %s\n", optarg);
		exit(1);
	    }
	    switch (*p) {
	      case ':':
	      case '-':
		str = ++p;
		last = strtol (str, &p, 10);
		break;
	      case ',':
	      case 0:
		last = first;
		break;
              default:
		fprintf (stderr, "Error: Invalid blockette list: %s\n", optarg);
		exit(1);
	    }
	    r[n].first = first;
	    r[n].last = last;
	    n++;
	    r = (RANGE *)realloc (r, (n+1) * sizeof(RANGE));
	    if (*p != '\0') ++p;
	    str = p;
	}
    }
    r[n].first = r[n].last = 0;
    return (r);
}

/************************************************************************/
/*  make_strip_list:							*/
/*	Create a list of blockettes to be stripped (removed).		*/
/************************************************************************/
RANGE *make_strip_list 
   (char	*str,		/* blockette list and/or range string.	*/
    double	version)	/* seed version number.			*/
{
    RANGE *r;
    int n, i;

    /* Parse string into an array of blockette ranges.			*/
    /* The array must terminate with a (0,0) range.			*/
    r = parse_range (str);
    if (r == NULL) {
	r = (RANGE *)malloc (sizeof(RANGE));
	r[0].first = r[0].last = 0;
    }

    /* Count the number of actual ranges from the string.		*/
    n = 0;
    for (n=0; r[n].first != 0; n++) ;

    /* Examine the pre-defined list of per-record blockettes.		*/
    /* If the seed version number of the blockette is greater than the	*/
    /* the desired seed version, add the blockette number onto the end	*/
    /* of the blockette range array.					*/
    for (i=0; per_record_blockette[i].blockette!=0; i++) {
	if (per_record_blockette[i].seed_version > version) {
	    r[n].first = r[n].last = per_record_blockette[i].blockette;
	    n++;
	    r = (RANGE *)realloc (r, (n+1) * sizeof(RANGE));
	}
    }
    /* Examine the pre-defined list of unique blockettes.		*/
    /* If the seed version number of the blockette is greager than the	*/
    /* the desired seed version, add the blockette number onto the end	*/
    /* of the blockette range array.					*/
    for (i=0; unique_blockette[i].blockette!=0; i++) {
	if (unique_blockette[i].seed_version > version) {
	    r[n].first = r[n].last = unique_blockette[i].blockette;
	    n++;
	    r = (RANGE *)realloc (r, (n+1) * sizeof(RANGE));
	}
    }

    /* Ensure that the last blockette range array entry is (0,0).	*/
    r[n].first = r[n].last = 0;
    return (r);
}

/************************************************************************/
/*  str_cp:								*/
/*	Copy a string until the terminator character or EOS is found.	*/
/*	Update src ptr.							*/
/*	Return:	0 on success, non-zero on error.			*/
/************************************************************************/
static int str_cp (char *dest, char **sp, char t) 
{
    while (**sp && **sp != t) {
	*dest++ = **sp;
	++(*sp);
    }
    *dest = '\0';
    return (0);
}

/************************************************************************/
/*  num_cp:								*/
/*	Copy a number for the specified number of digits.		*/
/*	Update src ptr.							*/
/*	Error if the specified number of digits are not found.		*/
/*	Return:	0 on success, non-zero on error.			*/
/************************************************************************/
static int num_cp (int *val, char **sp, int n) 
{
    static char str[BUF_SIZE];
    char *dest = str;
    while (n > 0 && isdigit(**sp)) {
	*dest++ = **sp;
	++(*sp);
	--n;
    }
    *dest = '\0';
    if (n > 0) return (-1);
    *val = atoi(str);
    return (0);
}

/************************************************************************/
/*  parse_filename:							*/
/*	Parse filename for verify version of the program.		*/
/*	Return:	0 on success, non-zero on failure.			*/
/************************************************************************/
static int parse_filename (char *filename, char *pattern)
{
    static char copy[BUF_SIZE];
    static char pat[BUF_SIZE];
    static char str[BUF_SIZE];
    char *p, *f, *s;
    int n;

    strcpy (verify.filename, filename);
    strcpy (copy, filename);
    strcpy (pat, pattern);
    p = pat;

    /* Parse filename. */
    f = copy;
    /* Skip leading directory portion of filename. */
    if ((s=strrchr(f,'/'))) f = ++s;

    /* Using the pattern, parse the filename.	*/
    /*  NOTE: Allow %% to reduce to a single % 	*/
    /*  so that a pattern string can be printed	*/
    /*	in a printf string.			*/
    /*	%S or %s = station			*/
    /*	%N or %n = network			*/
    /*	%C or %c = channel			*/
    /*	%L or %l = location			*/
    /*	%Y	 = 4 digit year			*/
    /*	%j	 = 3 digit day of year		*/
    /*	%m	 = 2 digit month		*/
    /*	%d	 = 2 digit day of month		*/
    /*	%H	 = 2 digit hour			*/
    /*	%M	 = 2 digit minute		*/
    /*	%X or %x = match rest of token		*/

    /* Using pattern, pick up the specified components from filename.	*/
    /* Return an error if the filename does not match the pattern.	*/
    
    while (*p && *f) {
	switch (*p) {
	  case '%':
	    ++p;
	    if (*p == '%') ++p;		/* Treat %% as %.		*/
	    switch (*p) {
	      case 'S':
	      case 's':
		if (str_cp (str, &f, '.')) return (-1);
		if ((n=strlen(str)) > SDR_STATION_LEN) return (-1);
		if (! verify.station_flag) strcpy (verify.station_id, str);
		uppercase(verify.station_id);
		++verify.station_flag;
		++p;
		break;
	      case 'N':
	      case 'n':
		if (str_cp (str, &f, '.')) return (-1);
		if ((n=strlen(str)) > SDR_NETWORK_LEN) return (-1);
		if (! verify.network_flag) strcpy (verify.network_id, str);
		uppercase(verify.network_id);
		++verify.network_flag;
		++p;
		break;
	      case 'C':
	      case 'c':
		if (str_cp (str, &f, '.')) return (-1);
		if ((n=strlen(str)) > SDR_CHANNEL_LEN) return (-1);
		if (! verify.channel_flag) strcpy (verify.channel_id, str);
		uppercase(verify.channel_id);
		++verify.channel_flag;
		++p;
		break;
	      case 'L':
	      case 'l':
		if (str_cp (str, &f, '.')) return (-1);
		if ((n=strlen(str)) > SDR_LOCATION_LEN) return (-1);
		if (! verify.location_flag) strcpy (verify.location_id, str);
		uppercase(verify.location_id);
		++verify.location_flag;
		++p;
		break;
	      case 'Y':
		if (num_cp (&n, &f, 4)) return (-1);
		verify.year = n;
		++verify.year_flag;
		++p;
		break;
	      case 'J':
	      case 'j':
		if (num_cp (&n, &f, 3)) return (-1);
		if (n < 0 || n > 366) return (-1);
		verify.doy = n;
		++verify.doy_flag;
		++p;
		break;
	      case 'm':
		if (num_cp (&n, &f, 2)) return (-1);
		if (n < 0 || n > 12) return (-1);
		verify.month = n;
		++verify.month_flag;
		++p;
		break;
	      case 'd':
		if (num_cp (&n, &f, 2)) return (-1);
		if (n < 0 || n > 31) return (-1);
		verify.day = n;
		++verify.day_flag;
		++p;
		break;
	      case 'H':
		if (num_cp (&n, &f, 2)) return (-1);
		if (n < 0 || n > 23) return (-1);
		verify.hour = n;
		++verify.hour_flag;
		++p;
		break;
	      case 'M':
		if (num_cp (&n, &f, 2)) return (-1);
		if (n < 0 || n > 59) return (-1);
		verify.minute = n;
		++verify.minute_flag;
		++p;
		break;
	      case 'X':
	      case 'x':
		if (str_cp (str, &f, '.')) return (-1);
		++p;
	      default:
		return (-1);
	    }
	    break;
	  default:
	    if (*p != *f) return (-1);
	    ++p; ++f;
	    break;
	}
    }
    /* If we still have more pattern left, treat it as an error.    */
    if (*p) return (-1);
    return(0);
}

/************************************************************************/
/*  split_fileinfo:							*/
/*	Split input string into filename:offset:length			*/
/*  return: filename, offset (0 if none), length (-1 if none)		*/
/************************************************************************/
void split_fileinfo
   (char *str, 
    char *filename, 
    off_t *ioffset,
    off_t *streamlimit)
{
    char *f;
    off_t ioff, slimit;
    strcpy (filename, str);
    *ioffset = 0;
    *streamlimit = -1;
    f = tail(filename);
    if (stream_delimiter) {
	char *p1 = NULL;
	char format[80];
	int n = 0;
	p1 = strchr(f, stream_delimiter);
	if (p1 == NULL) return;
	sprintf (format, "%%d%c%%d", stream_delimiter);
	n = sscanf (p1+1,format,&ioff, &slimit);
	if (n != 2) return;
	*ioffset = ioff;
	*streamlimit = slimit;
	*p1 = '\0';
    }
    return;
}
