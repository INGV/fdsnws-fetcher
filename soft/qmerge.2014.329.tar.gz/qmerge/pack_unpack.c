/************************************************************************/
/*  Routines to pack and unpack data.					*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

/* Modifications:
1999/02/15  Doug Neuhauser
    unpack_sdr_data: 
	Take blksize from record header, NOT from stream info, since this
	record may have already been reblocked.
*/

#ifndef lint
static const char sccsid[] = "$Id: pack_unpack.c,v 1.10 2014/09/12 22:17:33 doug Exp $ ";
#endif

#include <stdio.h>
#include <stdlib.h>

#include "qlib2.h"

#include "params.h"
#include "st_info.h"
#include "externals.h"

/************************************************************************/
/*  unpack_sdr_data:							*/
/*	Unpack SEED data record and place in supplied buffer.		*/
/*	If req_samples < 0, this implies a "fast" unpack request,	*/
/*	and can only be used if the data format is known.		*/
/*  Return:  data format on success, UNKNOWN_DATATYPE on error.		*/
/************************************************************************/
int unpack_sdr_data
   (ST_INFO	*st_p,		/* ptr to input stream structure.	*/
    void	*databuff,	/* ptr to data array.			*/
    int		*diffbuff,	/* ptr to difference array.		*/
    int         offset,         /* databuff AND diffbuff offset		*/
    int		req_samples)	/* # samples to request (neg -> fast).	*/
{
    DATA_HDR *hdr = st_p->cur_hdr;
    int format = hdr->data_type;
    int nbytes = hdr->blksize - hdr->first_data;
    void *pf = st_p->iob->buf + hdr->first_data;
    int num_samples, abs_req_samples;
    int *p_int_data;
    float *p_float_data;
    double *p_double_data;

    if (hdr->first_data == 0) nbytes = 0;
    num_samples = hdr->num_samples;
    abs_req_samples = (req_samples >= 0) ? req_samples : -req_samples;
    if (num_samples == 0) return (format);

    switch (format) {
    case INT_16:
	p_int_data = (int*)databuff;
	if (unpack_int_16 ((short int *)pf, nbytes, num_samples, req_samples,
			   p_int_data+offset, hdr->data_wordorder, NULL) == abs_req_samples) {
	    diffbuff = (int*)databuff;
	    return (INT_16);
	}
	break;
      case INT_32:
	p_int_data = (int*)databuff;
	if (unpack_int_32 ((int *)pf, nbytes, num_samples, req_samples,
			   p_int_data+offset, hdr->data_wordorder, NULL) == abs_req_samples) {
	    diffbuff = (int*)databuff;
	    return (INT_32);
	}
	break;
      case INT_24:
	p_int_data = (int*)databuff;
	if (unpack_int_24 ((unsigned char *)pf, nbytes, num_samples, req_samples,
			   p_int_data+offset, hdr->data_wordorder, NULL) == abs_req_samples) {
	    diffbuff = (int*)databuff;
	    return (INT_24);
	}
	break;
      case STEIM1:
	p_int_data = (int*)databuff;
	if (unpack_steim1 ((FRAME *)pf, nbytes, num_samples, req_samples,
			   p_int_data+offset, diffbuff+offset, &(hdr->x0),
			   &(hdr->xn), hdr->data_wordorder, NULL) == abs_req_samples) {
	    return(STEIM1);
	}
	break;
      case STEIM2:
	p_int_data = (int*)databuff;
	if (unpack_steim2 ((FRAME *)pf, nbytes, num_samples, req_samples,
			   p_int_data+offset, diffbuff+offset, &(hdr->x0),
			   &(hdr->xn), hdr->data_wordorder, NULL) == abs_req_samples) {
	    return(STEIM2);
	}
	break;
      case IEEE_FP_SP:
	p_float_data = (float*)databuff;
	if (unpack_fp_sp ((float *)pf, nbytes, num_samples, req_samples,
			  p_float_data+offset, hdr->data_wordorder, NULL)) {
	  diffbuff = (int *)databuff;
	  return(IEEE_FP_SP);
	}
	break;
      case IEEE_FP_DP:
	p_double_data = (double*)databuff;
	if (unpack_fp_dp ((double *)pf, nbytes, num_samples, req_samples,
			  p_double_data+offset, hdr->data_wordorder, NULL)) {
	  diffbuff = (int *)databuff;
	  return(IEEE_FP_DP);
	}
	break;
      case GEOSCOPE_MULTIPLEX_24:
      case GEOSCOPE_MULTIPLEX_16_GR_3:
      case GEOSCOPE_MULTIPLEX_16_GR_4:
      case USNN:
      case CDSN:
      case GRAEFENBERG_16:
      case IPG_STRASBOURG_16:
      case SRO:
      case HGLP:
      case DWWSSN_GR:
      case RSTN_16_GR:
	fprintf (info, "Error: unsupported data format %d - aborting.\n", format);
	exit(1);
	break;
      default:	/* Unknown format.  Try items below.			*/
	/* 	Either we don't know the format, or it has changed.  	*/
	/*	Try all verifiable formats in order.			*/
	p_int_data = (int*)databuff;
	if (unpack_steim1 ((FRAME *)pf, nbytes, num_samples, abs_req_samples,
			   p_int_data+offset, diffbuff+offset, &(hdr->x0),
			   &(hdr->xn), hdr->data_wordorder, NULL) == abs_req_samples) {
/*::	    if (verify_data) fprintf (info, "Using STEIM-1 compression\n");*/
	    hdr->data_type = STEIM1;
	    return(STEIM1);
	}
	if (unpack_steim2 ((FRAME *)pf, nbytes, num_samples, abs_req_samples,
			   p_int_data+offset, diffbuff+offset, &(hdr->x0),
			   &(hdr->xn), hdr->data_wordorder, NULL) == abs_req_samples) {
/*::	    if (verify_data) fprintf (info, "Using STEIM-2 compression\n");*/
	    hdr->data_type = STEIM2;
	    return(STEIM2);
	}
	fprintf (info, "Warning: seq=%d Unknown data format %d or decode error.\n", 
	     hdr->seq_no, hdr->data_type);
	hdr->data_type = UNKNOWN_DATATYPE;
	return(UNKNOWN_DATATYPE);
	break;
    }

    return(UNKNOWN_DATATYPE);
}

/************************************************************************/
/*  get_first_info:							*/
/*	Extract first data value and difference value in first frame.	*/
/*  Return: datatype of miniSEED data.					*/
/************************************************************************/
int get_first_info
   (ST_INFO	*st_p,		/* ptr to input stream structure.	*/
    int		*px0,		/* ptr to first value X0 (returned).	*/
    int		*pd0)		/* ptr to first difference (returned).	*/
{
    DATA_HDR *hdr = st_p->cur_hdr;
    int format = hdr->data_type;
    int req_samples;
    int  *diffbuff = NULL;	/* ptr to unpacked diff array.	*/
    int  *databuff = NULL;	/* ptr to unpacked data array.	*/

    if (databuff == NULL && 
	(databuff = (int *)malloc(hdr->num_samples * sizeof(int))) == NULL ) {
	fprintf (stderr, "Error: unable to malloc databuff\n");
	exit(1);
    }
    if (diffbuff == NULL && 
	(diffbuff = (int *)malloc(hdr->num_samples * sizeof(int))) == NULL ) {
	fprintf (stderr, "Error: unable to malloc diffbuff\n");
	exit(1);
    }

    /* If we don't know the format, we must get the first value by	*/
    /* conventional methods (ie request first value).			*/
    /* If we know the format, we can get the first value by "fast"	*/
    /* method by requesting -1 samples.					*/
    /* NOTE: "fast" method assumes that the format correctly known,	*/
    /* and does not verify block integrity for compressed formats.	*/
    req_samples = (hdr->data_type == UNKNOWN_DATATYPE) ? 1 : -1;
    format = unpack_sdr_data (st_p, databuff, diffbuff, 0, req_samples);
    if (format != UNKNOWN_DATATYPE) {
	*px0 = databuff[0];
	*pd0 = diffbuff[0];
    }
    free (diffbuff);
    free (databuff);
    return (format);
}

/************************************************************************/
/*  repack_sdr_data:							*/
/*	Repack SEED data and place in supplied buffer.			*/
/*  Return: return code from specific packing routines.			*/
/************************************************************************/
int repack_sdr_data 
   (void	*p_sdf,		/* ptr to SDR structure.		*/
    void	*data,		/* unpacked data array.			*/
    int		diff[],		/* unpacked diff array.			*/
    int		ns,		/* num_samples.				*/
    int		nb,		/* max number of data bytes.		*/
    int		format,		/* current data format.			*/
    int		pad,		/* flag to specify padding to nf.	*/
    int		wordorder,	/* wordorder of data.			*/
    int		*pnbytes,	/* number of bytes actually packed.	*/
    int		*pnsamples)	/* number of samples actually packed.	*/
{
    int nf;			/* # of input frames (calc from nb).	*/
    int oframes;		/* # of output frames.			*/
    int n = 0;			/* return code from repack functions.	*/
    switch (format) {
      case INT_16:
	n = (pack_int_16 ((short int *)p_sdf,data,ns,nb,pad,wordorder,pnbytes,pnsamples));
	break;
      case INT_24:
	n = (pack_int_24 ((unsigned char *)p_sdf,data,ns,nb,pad,wordorder,pnbytes,pnsamples));
	break;
      case INT_32:
	n = (pack_int_32 ((int *)p_sdf,data,ns,nb,pad,wordorder,pnbytes,pnsamples));
	break;
      case STEIM1:
	nf = nb / sizeof(FRAME);
	n = (pack_steim1 ((SDF *)p_sdf,data,diff,ns,nf,pad,wordorder,&oframes,pnsamples));
	*pnbytes = oframes * sizeof(FRAME);
	break;
      case STEIM2:
	nf = nb / sizeof(FRAME);
	n = (pack_steim2 ((SDF *)p_sdf,data,diff,ns,nf,pad,wordorder,&oframes,pnsamples));
	*pnbytes = oframes * sizeof(FRAME);
	break;
      case IEEE_FP_SP:
	n= (pack_fp_sp ((float *)p_sdf,data,ns,nb,pad,wordorder,pnbytes,pnsamples));
	break;
      case IEEE_FP_DP:
	n= (pack_fp_dp ((double *)p_sdf,data,ns,nb,pad,wordorder,pnbytes,pnsamples));
	break;
      case GEOSCOPE_MULTIPLEX_24:
      case GEOSCOPE_MULTIPLEX_16_GR_3:
      case GEOSCOPE_MULTIPLEX_16_GR_4:
      case USNN:
      case CDSN:
      case GRAEFENBERG_16:
      case IPG_STRASBOURG_16:
      case SRO:
      case HGLP:
      case DWWSSN_GR:
      case RSTN_16_GR:
	fprintf (info, "Error: unsupported data format %d - aborting.\n", format);
	exit(1);
	break;
      default:	/* unknown format.	*/
	fprintf (info, "Error: unknown data format - aborting.\n");
	exit(1);
	break;
    }
    return (n);
}
