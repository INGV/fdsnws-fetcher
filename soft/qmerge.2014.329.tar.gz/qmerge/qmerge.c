/************************************************************************/
/*  qmerge -	merge multiple quanterra data streams into single	*/
/*		continuous output data stream.				*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef lint
static const char sccsid[] = "$Id: qmerge.c,v 1.26 2014/09/12 22:31:26 doug Exp $ ";
#endif

#include <stdio.h>
#include "version.h"

#include "qlib2.h"

#include "params.h"

char *qmerge_syntax[] = {
"%s version " VERSION,
"%s  [-o output_file | -n] [-a] [-m] [-T] [-f date] [-t date | -s interval] [-e]",
"    [-u] [-P duration] [-pn | -pd]",
"    [-g tol] [-G tol] [-V version] [-x blockette_list|all]",
"    [-S station] [-C channel] [-N network] [-L location]",
"    [-D j|m] [-v] [-b blksize] [-i time | d0 | no_d0 | rate] [-c] [-H] [-d n]",
"    [-F file_list_file] [-w dn | hn] [-I input_data_fmt] [-O output_data_fmt]",
"    [-r] [-R record_type] [-h] [-l c] [input_file_1 ... input_file_n]",
"    where:",
"	-o outfile  Name of output file (or template filename with -P option).",
"	-a	    Append output to file instead of overwriting file.",
"	-n	    No data output.  Equivalent to -o /dev/null.",
"	-m	    Multichannel mode.  You can specify only 1 input file,",
"		    but it can contain multiple channels of data.",
"	-T	    Exact trim -- trim data to closest specified time.",
"		    Default is to trim to nearest inclusive block boundary.",
"	-f date	    From date - ignore data before this date.",
"	-t date	    To date - ignore data from this date on.",
"		    Date can be in formats:",
"			yyyy/mm/dd/hh:mm:ss.ffff",
"			yyyy/mm/dd.hh:mm:ss.ffff",
"			yyyy/mm/dd,hh:mm:ss.ffff",
"			yyyy.ddd,hh:mm:ss.ffff",
"			yyyy,ddd,hh:mm:ss.ffff",
"		    You may leave off any trailing 0 components of the time.",
"	-s interval span interval.  Alternate way of specifying end time.",
"		    Interval can be an integer followed immediately by",
"		    S, M, H, or d for seconds, minutes, hours, or days.",
"	-e	    Output only data blocks that have event flags turned on.",
"	-u	    Unique data flag.  Assume ALL input data is unique,",
"		    and suppress the removal of apparent duplicate data caused",
"		    by apparent data overlaps between data records.",
"	-P duration Partition output into distinct files of specified duration.",
"		    Duration may be 'NU' where N = decimal number, and",
"		    U is one of the following characters: y = year,",
"		    m = months, d = days, H = hours, M = minutes, S = seconds.",
"	-pn | -pd   Create name for partitioned output file based on nominal",
"		    partition time or on first data time.",
"		    Default is based on nominal parition time.",
"	-b blksize  Specify output blksize in bytes (or 0).  Valid blksize",
"		    is between 256 and 8192 inclusive, and blksize=2^N.",
"		    0 means use the blksize of the first used input record.",
"	-g tol	    Explicit tolerance for merging blocks in ticks (1/10 msec).",
"		    Blocks will be merged if the time diff is < tol.",
"		    Default is " STRING(MTOL_MULT) " of the data sample interval.",
"	-G TOL	    Explicit tolerance for time gaps in ticks (1/10 msec).",
"		    Default is " STRING(TTOL_MULT) " of data sample interval.",
"	-V version  Specify SEED version number for data header and blockettes.",
"		    Default version is 2.2",
"	-x list|all Strip the specified blockettes or all blockettes.",
"		    List can be comma-delimted and include a span, such as:",
"		    200-500,1001 or the string 'all' for all blockettes.",
"	-S station  Set the 5 char station name to the specified station name.",
"	-C channel  Set the 3 char channel name to the specified channel name.",
"	-N network  Set the 2 char network code (eg BK).",
"	-L location Set the 2 char location code (normally blank).",
"	-D j | m    Display dates in julian or month and day format.",
"	-i time	    Ignore time span info in header.",
"	-i rate	    Ignore changes in sample rate.",
"	-i d0	    Ignore (silently fix) d0 discrepencies between blocks.",
"	-i no_d0    Ignore and do NOT fix d0 discrepencies between blocks",
"		    (unless data is reblocked).",
"	-i dq	    Ignore MiniSEED Data Quality type (Q,D,R,M) when",
"		    selecting best input stream",
"	-v	    Verify internal consistency of all data frames and blocks.",
"	-c	    Write a content index line of station, channel, network,",
"		    location, and blksize of the first file to stdout.",
"		    Blank network and location code will be displayed as '" PRINTABLE_BLANK_LOCATION "'.",
"		    Do not process files.",
"	-H	    Write content index info and file header timespan info",
"		    to stdout for each file.  Timespan will be displayed only.",
"		    for SEED telemetry files.  Do not process files.",
"	-d n	    Debug output (OR of any of the following values:)",
"			1 = time slews",
"			2 = time info",
"			4 = block info",
"			8 = block headers",
"			16 = flags",
"			32 = input stream",
"			64 = output stream",
"			128 = filelimits",
"			1024 = output ascii",
"			2048 = output ASCII - 1 hdr per contiguous data segment",
"	-F file_list_file",
"		    File containing a list of data files, one file per line.",
"		    If this option is used, no input_file names are read from",
"		    the command line.",
"	-w output_wordorder",
"		    Specified the word order for the header and/or data",
"		    portions of the output MiniSEED records.",
"		    Option may be used more than once.  Valid word orders are:",
"		    0 = little endian (Intel/VAX) header and data.",
"		    1 = bit endian (SPARC/Motorola) header and data.",
"		    h0 = little endian header.	h1 = big endian header.",
"		    d0 = little endian data.	d1 = big endian data.",
"		    This option may be used multiple times to specify different",
"		    header and data word orders.",
"		    The default word order is big endian header and data.",
"	-I input_data_format",
"		    Specifies the data format of input pre-MiniSEED SEED Data",
"		    Records (SDR) without a blockette 1000 that defines",
"		    the data format within the record.",
"		    Valid formats are STEIM1, STEIM2, INT_16, INT_32, INT_24,",
"			IEEE_FP_SP, IEEE_FP_DP.",
"		    Default data format for SEED Data Records is STEIM1.",
"	-O output_data_format",
"		    Specifies the output data format for the MiniSEED records.",
"		    Valid formats are STEIM1, STEIM2, INT_16, INT_32, INT_24,",
"			IEEE_FP_SP, IEEE_FP_DP.",
"		    The default is the data format of the input data.",
"		    This option MUST be specified if there are multiple",
"		    input data formats.",
"	-r	    Repack the data into new records.",
"	-R record_type",
"		    Specify the SEED record_type field used for data quality.",
"			D = unknown quality (backwards compatible)",
"			R = Raw data (not QC-ed)",
"			M = Merged data",
"			Q = QC-ed (Quality controlled)",
"		    Default is the same as input records.",
"	-l c	    Specify character for optional delimiter for offset and len",
"		    in input filename.",
"	-h	    Help - prints syntax message.",
"	input_file(s)",
"		    Input file(s) containing quanterra data.",
"		    If no input file is specified, input is read from stdin.",
NULL };

char *qverify_syntax[] = {
"%s version " VERSION,
"%s  [-n] [-S station] [-C channel] [-N network] [-L location] [-b blksize]",
"    [-V verify_pattern] [-I input_data_fmt]  [-g tol] [-G tol] [-D j|m]",
"    [-i time] [-i d0] [-i no_d0] [-i V] [-v] [-d n] [-R record_type] [-h]"
"    input_file",
"    where:",
"	-n	    No data output (default).  Kept for qmerge compatibility.",
"	-S station  Set the 5 char station name to the specified station name.",
"		    This overrides the station name derived from the filename.",
"	-C channel  Set the 3 char channel name to the specified channel name.",
"		    This overrides the station name derived from the filename.",
"	-N network  Set the 2 char network code (eg BK).",
"		    This overrides the network code derived from the filename.",
"	-L location Set the 2 char location code (normally blank).",
"		    This overrides the location code derived from the filename.",
"	-b blksize  Specify blksize in bytes to be verified for input file.",
"		    Must be between 256 and 8192 inclusive, and blksize = 2^N.",
"	-V verify_pattern",
"		    Specifies the pattern of the filename from which verified",
"		    items should be derived, such as station, channel, network,",
"		    location, date, and time.  The default verify pattern is",
"		    " DEFAULT_VERIFY_PATTERN,
"	-I input_data_format",
"		    Specifies the input data format to be verified in input file.",
"		    Valid formats are STEIM1, STEIM2, INT_16, INT_32, INT_24.",
"		    Default format for non-MiniSEED records is STEIM1.",
"	-g tol	    Explicit tolerance for merging blocks in ticks (1/10 msec).",
"		    Blocks will be merged if the time diff is < tol.",
"		    Default is " STRING(MTOL_MULT) " of the data sample interval.",
"	-G TOL	    Explicit tolerance for time gaps in ticks (1/10 msec).",
"		    Default is " STRING(TTOL_MULT) " of data sample interval.",
"	-D j | m    Display dates in julian or month and day format.",
"	-i time	    Ignore time span info in header.",
"	-i d0	    Ignore (silently fix) d0 discrepencies between blocks.",
"	-i no_d0    Ignore and do NOT fix d0 discrepencies between blocks",
"		    (unless data is reblocked).",
"	-i V	    Ignore any verify pattern.  Assume all verification info",
"		    is specified with command line options.",
"	-v	    Verify internal consistency of all data frames and blocks.",
"		    Kept for qmerge compatibility.",
"	-d n	    Debug output (OR of any of the following values:)",
"			1 = time slews",
"			2 = time info",
"			4 = block info",
"			8 = block headers",
"			16 = flags",
"			32 = input stream",
"			64 = output stream",
"			1024 = output ascii",
"	-R record_type",
"		    Verify the SEED record_type field used for data quality.",
"			D = unknown quality (backwards compatible)",
"			R = Raw data (not QC-ed)",
"			Q = QC-ed (Quality controlled)",
"	-h	    Help - prints syntax message.",
"	input_file",
"		    Input file(s) containing data.",
"		    You must specify exactly 1 input file.",
NULL };

/************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "st_info.h"
#include "procs.h"
#define	EXTERN
#define	DEFINE
#include "externals.h"


/************************************************************************/
/*  main:   main program.						*/
/************************************************************************/
int main
   (int		argc,
    char	**argv)
{
    ST_INFO	*st_p;		/* ptr to input stream structure.	*/
    ST_INFO	*out_p;		/* ptr to output stream structure.	*/
    ST_INFO	*prev_stream;	/* ptr to prev input stream structure.	*/
    int		bias, start_bias, run_bias;
    INT_TIME	*stime;
    INT_TIME	*etime;
    int		new_stream;
    struct {
	char	station[8];
	char	channel[8];
	char	network[4];
	char	location[4];
	int	blksize;
    }  index;

    /*	Initialization.							*/
    outfile = NULL;		/* empty initial output directory.	*/
    fpin = stdin;		/* assume input to come from stdin.	*/
    info = stdout;
    date_fmt = JULIAN_FMT;
    run_bias = NO_BIAS;
    memset((void *)&index,0,sizeof(index));
    if (init_qlib2(1) != 1) {
	fprintf (stderr, "Error: initializing qlib2\n");
	exit(1);
    }
    sec_per_year(1970);		/* force leapsecond initialization.	*/

    debug_option = 0;

    if (parse_cmdline (&argc, &argv)) {
	fprintf (info, "Error: parsing command line\n");
	print_syntax(cmdname,syntax,info);
	exit(1);
    }

    if (debug(DEBUG_TIME)) {
	if (start_flag)
	    fprintf (info, "interval start time = %s\n", time_to_str(start_time,date_fmt));
	if (end_flag)
	    fprintf (info, "interval stop time = %s\n", time_to_str(end_time,date_fmt));
    }

    /*	Determine the block size and format of each input stream.	*/
    for (st_p = st_head_in.next; st_p != NULL; st_p = st_p->next) {
	int status;
	status = get_stream_info (st_p);
	if (print_file_hdr) {
	    if (st_p->vfh) {
		/* Print telemetry header if one exists, even if no data. */
		char station_id[6], location_id[3], channel_id[4], network_id[3];
		char reclen_str[3], type_str[4];
		char date_str[40];
		int blksize;
		char *p;
		INT_TIME *pt, begtime, endtime;
		int i, j;
		unsigned char type;
		char *vb = st_p->vfh+8;
		charncpy (type_str,vb,3);
		type = atoi(type_str);
		switch (type) {
		    case 5:		/* field volume */
		    case 10:		/* volume id */
		    break;
		    case 8:		/* telemetry volume */
		    trim(charncpy(station_id,vb+13,5));
		    trim(charncpy(location_id,vb+18,2));
		    trim(charncpy(channel_id,vb+20,3));
		    /* Skip 4 variable strings */
		    p = vb+23;
		    i = 4;
		    j = st_p->blksize;
		    while (i > 0 && j-- > 0) {
			if (*p++ == '~') --i;
		    }
		    /* Copy network if not at the end of the volume blockette. */
		    if (j > 0) trim(charncpy(network_id,p,2));
		    /* Get blksize. */
		    charncpy(reclen_str,vb+11,2);
		    blksize = (int)pow(2.0,(double)atoi(reclen_str));
		    /* Get volume begtime and endtime. */
		    charvncpy(date_str,vb+23,22,0);
		    if ((pt = parse_date(date_str)) != NULL) begtime = *pt;
		    else fprintf (info, "Unable to get start time from volume hdr\n");
		    charvncpy(date_str,vb+23,22,1);
		    if ((pt = parse_date(date_str)) != NULL) endtime = *pt;
		    else fprintf (info, "Unable to get end time from volume hdr\n");
		    break;
		  default:
		    fprintf (info, "Error: Unknown volume blockette %d\n", type);
		    exit(1);
		}
		fprintf (stdout, "%s.%s.%s.%s %d %s to ",
			 station_id, network_id, channel_id, location_id,
			 blksize, time_to_str(begtime,date_fmt+1));
		fprintf (stdout, "%s\n", time_to_str(endtime,date_fmt+1));
	    }
	    else if ((! missing_time(st_p->begtime)) && (! missing_time(st_p->endtime))) {
		fprintf (stdout, "%s.%s.%s.%s %d %s to ",
			 st_p->station, st_p->network, st_p->channel, st_p->location,
			 st_p->blksize, time_to_str(st_p->begtime,date_fmt+1));
		fprintf (stdout, "%s\n", time_to_str(st_p->endtime,date_fmt+1));
	    }
	    else if (status != EOF) {
		/* Print file info if data exists. */
		char rate_str[80];
		if (st_p->rate_mult == 1) {
		    sprintf (rate_str, "%d ", st_p->rate);
		}
		else {
		    sprintf (rate_str, "%.4lf ", sps_rate(st_p->rate,
							  st_p->rate_mult));
		}
		fprintf (stdout, "%s.%s.%s.%s %d %s \n", 
			 st_p->station, st_p->network, st_p->channel,
			 st_p->location, st_p->blksize, rate_str);
	    }
	}
	if (status == EOF) {
	    /* Save stream and channel info if not null.		*/
	    /* All files may be empty of data, but a file hdr will	*/
	    /* have the station and channel info in the header.	*/
	    if ((int)strlen(st_p->station) > 0) {
		strcpy (index.station, st_p->station);
		strcpy (index.channel, st_p->channel);
		strcpy (index.network, st_p->network);
		strcpy (index.location, st_p->location);
		index.blksize = st_p->blksize;
	    }
	    st_p = close_stream(st_p);
	}
    }
    if (print_file_hdr) exit(0);

    /*  If index is desired, return info from first available file.	*/
    if (make_index) {
	if ((st_p = st_head_in.next) != NULL) {
	    fprintf (stdout, "%-5.5s %-3.3s %-2.2s %-2.2s %4d\n", 
		     st_p->station, st_p->channel, 
		     (st_p->network[0]) ? st_p->network : PRINTABLE_BLANK_LOCATION,
		     (st_p->location[0]) ? st_p->location : PRINTABLE_BLANK_LOCATION,
		     st_p->blksize);
	    exit(0);
	}
	else if ((int)strlen(index.station) > 0) {
	    fprintf (stdout, "%-5.5s %-3.3s %-2.2s %-2.2s %4d\n", 
		     index.station, index.channel,
		     (index.network[0]) ? index.network : PRINTABLE_BLANK_LOCATION,
		     (index.location[0]) ? index.location : PRINTABLE_BLANK_LOCATION,
		     index.blksize);
	    exit(0);
	}
	else {
	    fprintf (stderr, "Error: no index info for file(s)\n");
	    exit(1);	/* No info for index is an ERROR.		*/
	}
    }

    /*	Get the first block for each stream to check data format.	*/
    /*  Determine whether we need to repack the data based on differing	*/
    /*  data formats.							*/
/*::
    in_fmt = UNKNOWN_DATATYPE;
    for (st_p = st_head_in.next; st_p != NULL; st_p = st_p->next) {
	get_block_info (st_p);
	this_fmt = st_p->cur_hdr->data_type;
	if (in_fmt == UNKNOWN_DATATYPE) in_fmt = this_fmt;
	if (output_data_fmt != UNKNOWN_DATATYPE && in_fmt != this_fmt && ! repack_flag) {
	    fprintf (info, "Warning: multiple data formats found - repack option turned on.\n");
	    repack_flag = 1;
	}
	if (output_data_fmt != UNKNOWN_DATATYPE && in_fmt != output_data_fmt && ! repack_flag) {
	    fprintf (info, "Warning: input and output data formats differ - repack option turned on.\n");
	    repack_flag = 1;
	}
    }
::*/
    /*	Initial step 0:

	If we don't have a starting time, take the file with the earliest
	starting time.  If we have multiple files with same starting point,
	pick the first one with the LARGEST blocksize.

	If we have a start time, position each stream to the first block such
	that the end of the current block does not preceed the start time.

	Select the (first of equal) streams that have the largest (?) block.
    */
    /*	Induction step i+1:

	If we have an empty output block, pick the best input file.
	If we have multiple files with the same starting point, pick the
	first one with the LARGEST blocksize.

	If we have a non-empty output block, pick the best input file.
	If we have multiple files with the same starting point, pick the
	first one with the SMALLEST blocksize.

	If the input block will not fit into the output block, purge the
	output block and start the induction step over again.
    */

    start_bias = (start_flag) ? START_BIAS : run_bias;
    bias = start_bias;

    /*	Initialize search parameters.					*/
    st_p = NULL;
    out_p = st_head_out.next;
    stime = (start_flag) ? &start_time : NULL;
    etime = (end_flag) ? &end_time : NULL;

    /*	Loop reading input and creating output.				*/
    /*	Now find the "best" stream to use.				*/
    /*	By definition, all streams have current block info.		*/
    prev_stream = st_p;
    int used_data_from_stream = 0;
    while ( (st_p = find_best_stream (st_p, out_p, stime, etime, bias)) != NULL ) {
	/* Process the data in the current block.			*/
	new_stream = (prev_stream != st_p);
	if (new_stream) {
	    if (debug(DEBUG_STREAM)) fprintf (info, "time %s using stream %s unit %d\n",
		time_to_str(st_p->cur_hdr->begtime,date_fmt), st_p->filename, fileno(st_p->iob->fp));
	    prev_stream = st_p;
	}
	prev_stream = st_p;
	if (output_blksize == 0) output_blksize = st_p->blksize;
	if (! used_data_from_stream) new_stream = 1;
	used_data_from_stream = process_block (st_p, new_stream);
	out_p = st_head_out.next;
	if (! multichannel) stime = NULL;
	bias = run_bias;
    }
    out_p = flush_file(out_p,1);
    print_stream_summary(out_p);
    return(0);
}

/************************************************************************/
/*  print_stream_summary:						*/
/*	Print stream summary info.					*/
/************************************************************************/
void print_stream_summary
   (ST_INFO	*out_p)		/* ptr to ouput stream struct.		*/
{
    int		seconds, usecs;
    INT_TIME	endtime;

    if (out_p->num_samples <= 0) return;

    /*  If repack_flag, there cannot be any slew by definition.		*/
    /*  Compute endtime with that assumption.				*/
    if (repack_flag) {
    time_interval2 (out_p->sum_hdr->num_samples, 
		    out_p->sum_hdr->sample_rate, out_p->sum_hdr->sample_rate_mult,
		    &seconds, &usecs);
	endtime = add_time (out_p->sum_hdr->begtime, seconds, usecs);
    }
    else {
	time_interval2 (1, out_p->sum_hdr->sample_rate, out_p->sum_hdr->sample_rate_mult,
			&seconds, &usecs);
	endtime = add_time (out_p->sum_hdr->endtime, seconds, usecs);
    }
 
    /*	Output summary information for the output stream.		*/
    if (quiet) return;
    fprintf (info, "%s.%s.%s.%s ",
	     out_p->sum_hdr->station_id, out_p->sum_hdr->network_id,
	     out_p->sum_hdr->channel_id, out_p->sum_hdr->location_id);
    if (out_p->sum_hdr->sample_rate_mult == 1)
	fprintf (info, "rate=%d ", out_p->sum_hdr->sample_rate);
    else
	fprintf (info, "rate=%.4lf ", sps_rate(out_p->sum_hdr->sample_rate,
					       out_p->sum_hdr->sample_rate_mult));
    fprintf (info, "(%s to ",
	     time_to_str(out_p->sum_hdr->begtime,date_fmt));
    fprintf (info, "%s) : %d points, %.1lf msec correction, ", 
	     time_to_str(endtime,date_fmt), out_p->sum_hdr->num_samples, 
	     ((double)out_p->total_slew)/USECS_PER_MSEC);
    fprintf (info, "(min,max,max_step = %.1lf,%.1lf,%.1lf msec)\n",
	     ((double)out_p->min_slew)/USECS_PER_MSEC, 
	     ((double)out_p->max_slew)/USECS_PER_MSEC,
	     ((double)out_p->max_step)/USECS_PER_MSEC);
}
