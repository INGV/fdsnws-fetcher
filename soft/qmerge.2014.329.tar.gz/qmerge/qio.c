/************************************************************************/
/*  I/O routines.							*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef lint
static const char sccsid[] = "$Id: qio.c,v 1.14 2014/09/12 22:17:33 doug Exp $ ";
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>

#include "qlib2.h"

#include "params.h"
#include "st_info.h"
#include "procs.h"
#include "externals.h"

#define	info    stderr

/************************************************************************/
/*  open_stream:							*/
/*	Open the specified stream, and allocate all structures		*/
/*	required for its support.					*/
/*  return:								*/
/*	ptr to new ST_INFO structure for the opened file.		*/
/************************************************************************/
ST_INFO *open_stream
   (ST_INFO	*phead,		/* ptr to stream struct linked list.	*/
    char	*file,		/* filename to open.			*/
    char	*mode)		/* mode for open.			*/
{
    ST_INFO *p;

    if ( (p = (ST_INFO *)malloc(sizeof(ST_INFO))) == NULL) {
	fprintf (info, "Error: unable to malloc st_info structure.\n");
	exit(1);
    }
    memset ((void *)p, 0, sizeof(ST_INFO));
    p->ioffset = 0;
    p->streamlimit = -1;
    p->iob = new_iob();
    strcpy (p->iob->mode, mode);
    if (p->iob->mode[0] == 'w' && no_output) {
	/* Don't open output file if output is suppressed.		*/
	p->iob->fp = NULL;
	if (debug(DEBUG_STREAM)) {
	    fprintf (info, "suppressed opening output file\n");
	    fflush (info);
	}
    }
    else if (file == NULL) {
	if (strcmp(mode,"r")==0) {
	    strcpy (p->filename, "<stdin>");
	    p->iob->fp = stdin;
	}
	else {
	    strcpy (p->filename, "<stdout>");
	    p->iob->fp = stdout;
	}
    }
    else {
	strcpy (p->filename, file);
	if (strlen(p->filename) > 0) {
	    int save_errno;
	    errno = 0;		/* Clear errno before we open file.	*/
	    p->iob->fp = fopen (p->filename, mode);
	    save_errno = errno;
	    if (p->iob->fp == NULL && (errno == EMFILE || errno == 0)) {
		/* Too many open files or no available stdio streams.	*/
		/* Close a stdio stream and try again.			*/
		suspend_stream (&st_head_in);
		p->iob->fp = fopen (p->filename, mode);
	    }
	    if (p->iob->fp == NULL) {
		/* We still cannot open the file.  Print error and die.	*/
		char *err = strerror(save_errno);
		fprintf (info, "Error: unable to open file %s - %s\n", 
			 p->filename, (err) ? err : "Unknown error");
		exit(1);
	    }
	    if (debug(DEBUG_STREAM)) {
		fprintf (info, "file %s open unit %d\n", p->filename, 
			 fileno(p->iob->fp));
		fflush (info);
	    }
	}
	else {
	    /* If filename is blank, defer opening file until later.	*/
	    p->iob->fp = NULL;
	    p->iob->deferred = 1;
	    if (debug(DEBUG_STREAM)) {
		fprintf (info, "file <duration> open deferred\n");
		fflush (info);
	    }
	}
    }

    /* Link this structure into the linked list.  Insert the new	*/
    /* structure at the head of the list, between the header and the	*/
    /* previous first element.						*/
    p->next = phead->next;	/* point forward to old first struct.	*/
    p->prev = phead;		/* point back to head.			*/
    phead->next = p;		/* point head to me.			*/
    if (p->next != NULL) {
	p->next->prev = p;	/* point old first struct back to me.	*/
    }

    return (p);
}

/************************************************************************/
/*  limit_stream:							*/
/*	Limit the initial offset and length of the specified stream.	*/
/*  return:								*/
/*	ptr to ST_INFO structure for the file.				*/
/************************************************************************/
ST_INFO *limit_stream (
    ST_INFO	*p,		/* ptr to ST_INFO file structure.	*/
    off_t	ioffset,	/* initial offset.			*/
    off_t	streamlimit)	/* length of stream.			*/
{
    p->ioffset = ioffset;
    p->streamlimit = streamlimit;
    return (p);
}

/************************************************************************/
/*  suspend_stream:							*/
/*	Find an open stream, save its position, and close it.		*/
/*  return:								*/
/*	0 on success, -1 on failure.					*/
/************************************************************************/
int suspend_stream 
   (ST_INFO	*phead)		/* ptr to stream struct linked list.	*/
{
    static int warning_sent = 0;
    ST_INFO *st_p;
    for (st_p = phead->next; st_p != NULL; st_p = st_p->next) {
	if (st_p->iob->fp != NULL && st_p->iob->fp != stderr &&
	    st_p->iob->fp != stdin && st_p->iob->fp != stdout &&
	    (st_p->iob->pos = ftello (st_p->iob->fp)) >= 0) {
	    if (debug(DEBUG_STREAM) && ! warning_sent) {
		fprintf (info, "Warning: too many open files -- reclaiming file units\n"),
		fflush (info);
		warning_sent = 1;
	    }
	    if (debug(DEBUG_STREAM)) {
		fprintf (info, "suspend stream: %s\n", st_p->filename);
		fflush (info);
	    }
	    fclose (st_p->iob->fp);
	    st_p->iob->fp = NULL;
	    return (0);
	}
    }
    return (-1);
}

/************************************************************************/
/*  reopen_stream:							*/
/*	Reopen stream that was temporarily closed.			*/
/************************************************************************/
int reopen_stream
   (ST_INFO	*st_p)		/* ptr to stream struct to reopen.	*/
{
    st_p->iob->fp = fopen (st_p->filename, st_p->iob->mode);
    if (st_p->iob->fp == NULL) {
	suspend_stream (&st_head_in);
	st_p->iob->fp = fopen (st_p->filename, st_p->iob->mode);
    }
    if (st_p->iob->fp == NULL) {
	fprintf (info, "Error: unable to re-open file %s\n", st_p->filename);
	exit (1);
    }
    if (debug(DEBUG_STREAM)) {
	fprintf (info, "reopen_stream:  %s unit %d\n", st_p->filename,
		 fileno(st_p->iob->fp));
	fflush (info);
    }
    if (fseeko (st_p->iob->fp, st_p->iob->pos, SEEK_SET) != 0) {
	fprintf (info, "Error: unable to re-position file %s\n", st_p->filename);
	exit (1);
    }
    return (0);
}

/************************************************************************/
/*  close_stream:							*/
/*	Close the specified stream, and deallocate all structures	*/
/*	required for its support.					*/
/*  return:								*/
/*	addr of prev stream structure from linked list.			*/
/************************************************************************/
ST_INFO *close_stream
   (ST_INFO	*st_p)		/* ptr to stream struct to close.	*/
{
    ST_INFO *prev;
    /*	Close the stream.   */
    if (debug(DEBUG_STREAM)) {
	if (st_p->iob->fp) fprintf (info, "file %s close unit %d\n", 
				    st_p->filename, fileno(st_p->iob->fp));
	else fprintf (info, "file %s close unit %s\n", 
		      "<deferred>", "<none>");
	fflush (info);
    }
    if (st_p->iob->fp) fclose (st_p->iob->fp);

    /*  Unchain this ST_INFO from the linked list.			*/
    /*  We ALWAYS have a prev structure, since there is a dummy head	*/
    /*	for the list, but not always a next struct.			*/
    st_p->prev->next = st_p->next;    /* unlink fwd pointer.		*/
    if (st_p->next != NULL) st_p->next->prev = st_p->prev;

    /* Save pointer to this stream's prev so we can return it as the	*/
    /* function value.							*/
    prev = st_p->prev;

    /* Now deallocate all info that was allocated for this stream.	*/
    free_iob (st_p->iob);
    if (st_p->sum_hdr) free_data_hdr (st_p->sum_hdr);
    if (st_p->prev_hdr) free_data_hdr (st_p->prev_hdr);
    if (st_p->last_hdr) free_data_hdr (st_p->last_hdr);
    if (st_p->cur_hdr) free_data_hdr (st_p->cur_hdr);
    free (st_p);
    return (prev);
}

/************************************************************************/
/*  fill_buffer:							*/
/*	Ensure that the input buffer has the specified amount of input	*/
/*	in its input buffer.						*/
/*  return:								*/
/*	index of next free (unused) byte IOB.				*/
/************************************************************************/
int fill_buffer
   (ST_INFO	*st_p,		/* ptr to input stream struct.		*/
    int		n)		/* number of bytes desired in IOB.	*/
{
    int		*pfree = &(st_p->iob->free);
    int		*pavail = &(st_p->iob->avail);
    int		nbytes_in_buf = *pfree - *pavail;
    int		nread;

    /*	Want to ensure that at least N bytes are in the buffer.		*/
    /*	In addition, shift data in the buffer so that it starts		*/
    /*	at the beginning of the buffer.					*/
    /*	This way we ensure that there is sufficient room.		*/

    /*	Shift data in buffer (if necessary).				*/
    if (nbytes_in_buf < 0) nbytes_in_buf = 0;
    if (nbytes_in_buf > 0 && *pavail > 0)
	/* WARNING: OVERLAPPING COPY.  memcpy cannot be used.		*/
	bcopy (st_p->iob->buf+*pavail, st_p->iob->buf, nbytes_in_buf);
    *pavail = 0;
    *pfree = nbytes_in_buf;
    
    /*	Add data to the buffer (if necessary).				*/
    n -= nbytes_in_buf;
    /*  Ensure that the file is actually open.				*/
    if (n > 0 && st_p->iob->fp == NULL) {
	reopen_stream (st_p);
	if (st_p->iob->fp == NULL) {
	    fprintf (info, "Error: unable to re-open file %s\n", st_p->filename);
	    exit(1);
	}
    }

    /* Perform any initial positioning that may be required.	*/
    if (st_p->ioffset) {
	if (fseeko (st_p->iob->fp, st_p->ioffset, SEEK_SET) != 0) {
	    fprintf (info, "Error: positioning to offset %ld in file %s\n", 
		     st_p->ioffset, st_p->filename);
	    exit(1);
	}
	st_p->ioffset = 0;
    }

    /* Limit amount of data read to streamlimit. */
    if (st_p->streamlimit >= 0 && n > st_p->streamlimit) n = st_p->streamlimit;

    while (n > 0 && (nread = fread (st_p->iob->buf+nbytes_in_buf, 1, n, st_p->iob->fp)) > 0) {
	*pfree += nread;
	if (st_p->streamlimit >= 0) st_p->streamlimit -= nread;
	n -= nread;
    }
    return (*pfree);
}

/************************************************************************/
/*  write_stream:							*/
/*	Write output block to output stream, and update summary info.	*/
/************************************************************************/
void write_stream
   (ST_INFO	*out)		/* ptr to output stream struct.		*/
{
    int		nw;
    int		blksize = out->blksize;
    if (out->iob->fp) {
	if ((nw = fwrite (out->iob->buf, blksize, 1, out->iob->fp)) != 1 ) {
	    fprintf (stderr, "Error: writing output unit %d for file %s\n", 
		     fileno(out->iob->fp), out->filename);
	    /*:: fprintf (stderr, "tried to write %d bytes, wrote %d\n", blksize, nw);*/
	    exit(1);
	}
    }
    /* Update information in the main stream structure.			*/
    ++(out->num_blk);
    ++(out->cont_blk);
    out->num_samples += out->cur_hdr->num_samples;
}

/************************************************************************/
/*  Routines to create, duplicate, and free IOBs.			*/
/************************************************************************/
IOB *new_iob ()
{
    IOB *iob;
    if ((iob = (IOB *)malloc (sizeof (IOB))) == NULL) {
	fprintf (info, "Error: cannot malloc new iob\n");
	exit(1);
    }
    memset ((void *)iob, 0, sizeof (IOB));
    iob->bufsize = sizeof(iob->buf);
    return (iob);
}
	    
IOB *dup_iob 
   (IOB *old_iob)		/* ptr to IOB to be duplicated.		*/
{
    IOB *iob;
    if ((iob = (IOB *)malloc (sizeof (IOB))) == NULL) {
	fprintf (info, "Error: cannot malloc new iob\n");
	exit(1);
    }
    memcpy ((void *)iob, (void *)old_iob, sizeof(IOB));
    return (iob);
}

void free_iob 
   (IOB *iob)			/* ptr to IOB to free.			*/
{
    free (iob);
}
