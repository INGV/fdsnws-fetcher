/************************************************************************/
/*  External variables.							*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

/*	$Id: externals.h,v 1.14 2014/09/12 22:17:32 doug Exp $ 	*/

#ifndef	EXTERN
#define	EXTERN	extern
#endif	/* EXTERN */


/***************************** External variables   *********************/

/*  Command line information.						*/
/*  Command line options (flags)					*/
EXTERN double	seed_version;		/* seed version number.		*/
EXTERN int	start_flag;		/* starting time specified.	*/
EXTERN int	end_flag;		/* ending time specified.	*/
EXTERN int	no_output;		/* do not write output.		*/
EXTERN int	quiet;			/* do not write summary lines.	*/
EXTERN int	exact_trim;		/* trim data to exact time.	*/
EXTERN int	ignore_hdr;		/* ignore time in hdr (if avail)*/
EXTERN int	ignore_rate;		/* ignore rate change.		*/
EXTERN int	ignore_d0_errors;	/* silently fix d0 errors.	*/
EXTERN int	ignore_d0_fixing;	/* DO NOT FIX d0 errors.	*/
EXTERN int	ignore_dq;		/* ignore data quality rectype.	*/
EXTERN int	make_index;		/* make station+channel index.	*/
EXTERN int	print_file_hdr;		/* print file header info.	*/
EXTERN int	verify_data;		/* verify data packet integrity.*/
EXTERN int	append_output;		/* append output to file.	*/
EXTERN int	event_only_flag;	/* output only events.		*/
EXTERN int	unique_flag;		/* assume all data is unique.	*/
EXTERN int	repack_flag;		/* repack data into new records.*/
EXTERN int	multichannel;		/* process multichannel input.	*/

/*  Command line arguments.						*/
EXTERN char	*cmdname;		/* command name.		*/
EXTERN int	debug_option;		/* debug options.		*/
EXTERN int	date_fmt;		/* format for printing date.	*/
EXTERN int	input_data_fmt;		/* input data fmt (non-MINISEED)*/
EXTERN int	output_data_fmt;	/* output data fmt.		*/
EXTERN int	stream_tol;		/* cont data tol in ticks.	*/
EXTERN int	block_tol;		/* block merge tol in ticks.	*/
EXTERN int	output_blksize;		/* output blksize.		*/
EXTERN int	output_hdr_wordorder;	/* output hdr wordorder.	*/
EXTERN int	output_data_wordorder;	/* output data wordorder.	*/
EXTERN INT_TIME	start_time;		/* starting time for selection.	*/
EXTERN INT_TIME	end_time;		/* ending time for selection.	*/
EXTERN RANGE	*stripped_blockette;	/* blockette list to strip.	*/
EXTERN char	*station_id;		/* explicit new station name.	*/
EXTERN char	*channel_id;		/* explicit new channel name.	*/
EXTERN char	*location_id;		/* location id for output data.	*/
EXTERN char	*network_id;		/* network id for output data.	*/
EXTERN char	*default_network_id;	/* default network id.		*/
EXTERN char	*file_duration;		/* output file duration string.	*/
EXTERN char	duration_date_flag;	/* what date to use in filename.*/
EXTERN char	output_record_type;	/* record_type Quality char.	*/
EXTERN char	stream_delimiter;	/* delimiter from file:off:len	*/

/*  Misc external info.							*/
EXTERN FILE	*fpin;			/* input FILE pointer.		*/
EXTERN FILE	*info;			/* information FILE pointer.	*/
EXTERN char	*outfile;		/* output file name.	*/
EXTERN ST_INFO	st_head_in;		/* hdr struture to linked list	*/
					/* of input stream structures.	*/
EXTERN ST_INFO	st_head_out;		/* hdr struture to linked list	*/
					/* of output stream structures.	*/
EXTERN char	**syntax;		/* command line syntax info.	*/
#ifndef	DEFINE
EXTERN char	*qmerge_syntax[];	/* command line syntax info.	*/
EXTERN char	*qverify_syntax[];	/* command line syntax info.	*/
#endif
EXTERN char	*outmode;		/* append or overwrite.		*/
EXTERN int	init_duration;		/* is duration initialized?	*/
EXTERN INT_TIME	beg_duration;		/* start output file timespan.	*/
EXTERN INT_TIME end_duration;		/* end output file duration.	*/

/* File information.							*/
EXTERN char	*tmpbuff;		/* temp data buffer for copy.   */
EXTERN char	*databuff;		/* data buffer for uncompress.	*/
EXTERN int	*diffbuff;		/* diff buffer for uncompress.	*/
EXTERN int	max_num_samples;	/* total samples in block.	*/ 

/************************************************************************/
/* Verify variables							*/
int qverify;
struct _verify {
    char filename[2048];
    char *pattern;
    int ignore_pattern;
    int blksize_flag, input_data_fmt_flag;
    int blksize, input_data_fmt;
    int start_flag, end_flag;
    INT_TIME start_time, end_time;
    int station_flag, network_flag, channel_flag, location_flag;
    int year_flag, doy_flag, month_flag, day_flag, hour_flag, minute_flag;
    char station_id[SDR_STATION_LEN+1];
    char network_id[SDR_NETWORK_LEN+1];
    char channel_id[SDR_CHANNEL_LEN+1]; 
    char location_id[SDR_LOCATION_LEN+1];
    char record_type;	/* record_type Quality char.	*/
    int year;
    int doy;
    int month;
    int day;
    int hour;
    int minute;
} verify;

/************************************************************************/
/*  In order to properly handle blockettes, we need to classify 
    blockettes into 2 types:
    1.	Blockettes that are associated with fixed data records, eg there
	can be at most 1 copy of that blockette per fixed data record,
	and it contains info about that record.  Examples are blockettes
	100, 1000, 1001.
    2.	Blockettes that describe information not directly associated
	with a fixed data record.  There can be multiple unique copies
	of these blockettes in a single data record.  Examples are
	blockettes 2xx, 3xx, 5xx.
*/

/***************************** External variables   *********************/

#ifdef DEFINE
char *filename_pattern = "%S.%N.%C.%L.D.%Y.%j.%T";

BLOCKETTE_INFO per_record_blockette[] = 
    {	{100,  2.3},
	{1000, 2.3},
	{1001, 2.3},	/* may be 2.4	*/
	{0,    0.0},
    };

BLOCKETTE_INFO unique_blockette[] = 
    {	{200,  2.0},
	{201,  2.0},
	{202,  2.0},
	{300,  2.0},
	{310,  2.0},
	{320,  2.0},
	{390,  2.0},
	{395,  2.0},
	{400,  2.0},
	{405,  2.0},
	{500,  2.3},	/* may be 2.4	*/
	{0,    0.0},
    };
#else
extern char *filename_pattern;
extern BLOCKETTE_INFO per_record_blockette[];
extern BLOCKETTE_INFO unique_blockette[];
#endif	/* DEFINE   */

