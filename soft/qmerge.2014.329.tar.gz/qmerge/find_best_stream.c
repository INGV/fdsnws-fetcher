/************************************************************************/
/*  Routines to select best input stream.				*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef lint
static const char sccsid[] = "$Id: find_best_stream.c,v 1.10 2014/09/12 22:17:32 doug Exp $ ";
#endif

#include <stdio.h>
#include <math.h>

#include "qlib2.h"

#include "params.h"
#include "st_info.h"
#include "procs.h"
#include "externals.h"

static int dq(char record_type);
static double min_sample_slew (double slew, int points_per_sample);

/************************************************************************/
/*  find_best_stream:							*/
/*	Find the best input stream from which to read.			*/
/************************************************************************/
ST_INFO *find_best_stream 
   (ST_INFO	*in_p,		/* ptr to current input stream.		*/
    ST_INFO	*out_p,		/* ptr to output stream.		*/
    INT_TIME	*stime,		/* ptr to desired start time, or NULL.	*/
    INT_TIME	*etime,		/* ptr to desired end time, or NULL.	*/
    int		bias)		/* bias flag for best stream selection.*/
{
    ST_INFO	*st_p;
    ST_INFO	*best_p = NULL;
    double	cmp, tdif;
    double	slew, minslew;
    double	best_slew, best_minslew;
    double	usecs_per_sample;
    int		seconds, usecs;
    int		cur_dq, best_dq;
    int		tolerance;
    INT_TIME	exptime;


    /*	If either we have a start time OR we have no current stream,	*/
    /*	then position all input streams.				*/
    if (stime != NULL || in_p == NULL) {
	for (st_p = st_head_in.next; st_p != NULL; st_p = st_p->next) {
	    /*	If possible, use header time for a fast check to	*/
	    /*	determine whether desired time interval is in this file.*/
	    if ( (! ignore_hdr) && (! missing_time(st_p->begtime)) && 
		(! missing_time(st_p->endtime)) && 
		(stime != NULL || etime != NULL) ) {
		if ((stime != NULL && tdiff(st_p->endtime,*stime) < 0) ||
		    (etime != NULL && tdiff(st_p->begtime,*etime) > 0)) {
		    st_p = close_stream(st_p);
		    continue;
		}
	    }
	    if (position_stream (st_p, stime, etime) == EOF) 
		st_p = close_stream(st_p);
	}
    }

    /*	Now search for the "best" stream based on:			*/
    /*	    absolute start time (if any).				*/
    /*	    current input stream.					*/
    /*	    characteristics (if any) of current output stream.		*/
    /*	    specified bias.						*/
    /*	NOTE:								*/
    /*	    We should never be called with both a start time AND	*/
    /*	    a current input stream (except for multichannel mode).	*/

    /*	If we have a current input stream, get the next block.		*/
    if (in_p != NULL) {
	/*  Get the next block of the current input stream.		*/
	if (position_stream (in_p, stime, etime) == EOF) {
	    /* EOF -- close it and unset current input stream.		*/
	    in_p = close_stream(in_p);
	    in_p = NULL;
	}
    }

    /*	If we have a start time, look for the "best" stream that	*/
    /*	contains the start time.					*/
    /*	If no block intersects the start time, take the earliest block.	*/
    if (stime != NULL) {
	for (st_p = st_head_in.next; st_p != NULL; st_p = st_p->next) {
	    cmp = tdiff(st_p->cur_hdr->begtime,*stime);
	    if (cmp <= 0) {
		/*  Block intersects start time -- possible candidate.	*/
		/*  Select "best" stream based on bias.			*/
		if (best_p == NULL) {
		    best_p = st_p;
		    continue;
		}
		best_dq = dq(best_p->cur_hdr->record_type);
		cur_dq = dq(st_p->cur_hdr->record_type);
		/* Is this stream better than the one that we have?	*/
		if ((! ignore_dq) && (cur_dq > best_dq)) {
		    best_p = st_p;
		    continue;
		}
		if ((ignore_dq) || (cur_dq == best_dq)) switch (bias) {
		case LARGE_BLOCK_BIAS:
		    if (st_p->blksize > best_p->blksize) best_p = st_p;
		    break;
		case SMALL_BLOCK_BIAS:
		    if (st_p->blksize < best_p->blksize) best_p = st_p;
		    break;
		default:    /* Stay with what we have.			*/
		    break;
		}
	    }
	}
	/*  If we have chosen a "best" stream, return.			*/
	/*  Otherwise, ignore start time and continue the search.	*/
	if (best_p != NULL) return (best_p);
	else stime = NULL;
    }

    /*	If no start time and not current input stream, just search for	*/
    /*	for the earliest block.						*/
    /*	Break ties with the best quality stream.			*/
    if (stime == NULL && in_p == NULL) {
	for (st_p = st_head_in.next; st_p != NULL; st_p = st_p->next) {
	    if (best_p == NULL) { best_p = st_p; continue; }
	    best_dq = dq(best_p->cur_hdr->record_type);
	    cur_dq = dq(st_p->cur_hdr->record_type);
	    tdif = tdiff(st_p->cur_hdr->begtime,best_p->cur_hdr->begtime);
	    if (tdif < 0 || (tdif == 0 && cur_dq > best_dq)) {
		best_p = st_p;
		continue;
	    }
	}
	return (best_p);
    }

    /*	We have a current input stream and not explicit start time.	*/
    else {  /*	(stime == NULL && in_p != NULL)				*/
	/*  Blindly stay with the current input stream unless there is	*/
	/*  a non-acceptable time slew or time gap.			*/
	/* For qverify on no-data files, stay with current file.	*/
	if (qverify && (in_p->cur_hdr->num_samples == 0 || 
			     in_p->cur_hdr->sample_rate == 0)) {
	    return (in_p);
	}
	/* Compute expected time of next sample.			*/
	time_interval2 (1,in_p->cur_hdr->sample_rate,in_p->cur_hdr->sample_rate_mult,
			&seconds,&usecs);
	usecs_per_sample = (double)seconds * USECS_PER_SEC + usecs;
	if (out_p->last_hdr != NULL) 
	    exptime = add_dtime (out_p->last_hdr->endtime, usecs_per_sample);
	else
	    exptime = add_dtime (out_p->sum_hdr->endtime, usecs_per_sample);

	/* Positive slew -> gap, negative slew -> overlap.		*/
	tolerance = TOL(in_p->cur_hdr->sample_rate, in_p->cur_hdr->sample_rate_mult);
	slew = tdiff (in_p->cur_hdr->begtime, exptime);
	if (fabs(slew) < DIHUGE && fabs(slew) < tolerance) {
	    /*	Current stream is within slew tolerance, so use it.	*/
	    return(in_p);
	}

	/*  Next record of current stream is NOT within slew tolerance.	*/
	/*  Search for a "better" stream.				*/
	/*  There are several possible criteria we can use:		*/
	/*  1.  Minimize data gap.					*/
	/*	Look for stream with record starting before exptime.	*/
	/*  2.  Minimize data slew.					*/
	/*	Look for stream with minimal time slew between the 	*/
	/*	expected time (module sample rate) is better.		*/
	/*  3.  Better MiniSEED quality stream.				*/
	/*  Start by assuming current stream is best stream.		*/
	
	minslew = min_sample_slew(slew,usecs_per_sample);
	best_p = in_p;
	best_dq = dq(best_p->cur_hdr->record_type);
	best_slew = slew;
	best_minslew = minslew;

	for (st_p = st_head_in.next; st_p != NULL; st_p = st_p->next) {
	    /* Compare "best" stream to this stream".			*/
	    slew = tdiff(st_p->cur_hdr->begtime,exptime);
	    minslew = min_sample_slew (slew, usecs_per_sample);
	    cur_dq = dq(st_p->cur_hdr->record_type);

	    if (best_slew > 0 && slew > 0 && slew < best_slew) {
		/* Reduces data gap.	*/
		best_p = st_p;
		best_slew = slew;
		best_minslew = minslew;
		best_dq = cur_dq;
		continue;
	    }
	    if (best_slew > tolerance && slew < 0) {
		/* Reduces data gap.	*/
		best_p = st_p;
		best_slew = slew;
		best_minslew = minslew;
		best_dq = cur_dq;
		continue;
	    }
	    if (fabs(best_slew) >= tolerance && fabs(slew) < tolerance) {
		/* Reduce tolerance for next sample. */
		best_p = st_p;
		best_slew = slew;
		best_minslew = minslew;
		best_dq = cur_dq;
		continue;
	    }
	    /* See if the streams are "equally good" other than data quality. */
	    if ((!ignore_dq) && fabs(best_minslew) < tolerance && fabs(slew) < tolerance &&
		cur_dq > best_dq) {
		/* Higher data quality.	*/
		best_p = st_p;
		best_slew = slew;
		best_minslew = minslew;
		best_dq = cur_dq;
		continue;
	    }
	}
	return (best_p);
    }
}

/************************************************************************/
/*  dq:									*/
/*	Find the best input stream from which to read.			*/
/*  Return prioritized quality value of data quality (record_type).	*/
/*  Higher is better.							*/
/*  Order from highest to lowest:    Q, D, M, R				*/
/*	D is considered higher than R because it is "unknown quality"	*/
/*	    and cannot be worse than R.					*/
/*	M is considered higher than R because it was constructed from	*/
/*	    multiple record types.					*/
/************************************************************************/

static int dq(char record_type)
{
    int dq;
    switch (record_type) {
      case 'Q':	
	dq = 10; break;
      case 'D':
	dq = 6; break;
      case 'M':
	dq = 6; break;
      case 'R':
	dq = 4; break;
      default:
	dq = 0; break;
    }
    return dq;
}

static double min_sample_slew 
    (double slew,
     int points_per_sample)
{
    /* For positive slew, return slew;				*/
    /* For negative slew, find slew to within +- half sample.	*/
    if (slew < 0) {
	slew = fmod(slew, points_per_sample);
	if (slew < -0.5 * points_per_sample) slew += points_per_sample;
    }
    return slew;
}
