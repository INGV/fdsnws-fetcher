/************************************************************************/
/*  Routines for file duration processing.				*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismographic Station						*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef lint
static const char sccsid[] = "$Id: duration.c,v 1.10 2014/09/12 22:17:32 doug Exp $ ";
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <qlib2.h>

#include "params.h"
#include "st_info.h"
#include "externals.h"

static int  duration_val = 0;
static char duration_unit = 'M';

double myanint(double x)
{
    return( (x)>=0 ?
        floor(x + .5) : -floor(.5 - x) );
}

/************************************************************************/
/*  NOTE:   The end_duration represents the end of the open interval	*/
/*	    AFTER the last sample time.					*/
/*	    The endtime of the packet is the time of the last sample.	*/
/************************************************************************/

/************************************************************************/
/*  parse_duration:							*/
/*	Parse duration string into external variables:			*/
/*	    duration_val:   numeric value for duration.			*/
/*	    duration_unit:  character denomination for duration.	*/
/*  return:								*/
/*	    0 on success, -1 on error.					*/
/*	    Allow a duration_val of 0.					*/
/*	    This will use template for constructing output filename.	*/
/************************************************************************/
int parse_duration
   (char	*str)		/* duration string.			*/
{
    char *p;
    int error = 0;
    int i;
    duration_val = strtol (str, &p, 10);
    duration_unit = p ? *p : 'M';
    /* Check on the integrity of the duration string.			*/
    switch (duration_unit) {
      case 'y':
      case 'Y':
	if (duration_val != 0) {
	    if (duration_val != 1) ++error;	/* only allow 1 year.	*/
	}
	break;
      case 'm':
	if (duration_val != 0) {
	    i = 12 / duration_val;
	    if (i * duration_val != 12) ++error;
	}
	break;
      case 'd':
	if (duration_val != 0) {
	    i = duration_val;
	    if (i <= 0 || i > 366) ++error;
	}
	break;
      case 'H':
	if (duration_val != 0) {
	    i = 24 / duration_val;
	    if (i * duration_val != 24) ++error;
	}
	break;
      case 'M':
	if (duration_val != 0) {
	    i = 60 / duration_val;
	    if (i * duration_val != 60) ++error;
	}
	break;
      case 'S':
	if (duration_val != 0) {
	    i = 60 / duration_val;
	    if (i * duration_val != 60) ++error;
	}
	break;
      default:
	++error;
	break;
    }
    if (error || duration_val < 0) {
	fprintf (info, "Error: invalid duration: %s\n", str);
	return (-1);
    }
    return (0);
}


/************************************************************************/
/*  compute_duration:							*/
/*	Compute start and end duration based on time in DATA_HDR.	*/
/*	Set external variables:						*/
/*	    beg_duration, end_duration.					*/
/************************************************************************/
void compute_duration 
   (DATA_HDR	*hdr)		/* DATA_HDR for record.			*/
{
    EXT_TIME bt, et;
    int duration_valN = (duration_val == 0) ? 1 : duration_val;
    bt = int_to_ext(hdr->begtime);
    switch (duration_unit) {
      case 'y':
      case 'Y':
	bt.month = 1;
	bt.day = 1; 
	bt.hour = bt.minute = bt.second = bt.usec = 0;
	bt.doy = mdy_to_doy (bt.month, bt.day, bt.year);
	if (duration_val > 0) {
	    et = bt;
	    et.year += duration_val;
	    et = normalize_ext (et);
	}
	break;
      case 'm':
	bt.month -= (bt.month-1) % duration_valN;
	bt.day = 1; 
	bt.hour = bt.minute = bt.second = bt.usec = 0;
	bt.doy = mdy_to_doy (bt.month, bt.day, bt.year);
	if (duration_val > 0) {
	    et = bt;
	    et.month += duration_val;
	    et.doy = mdy_to_doy (et.month, et.day, et.year);
	    et = normalize_ext (et);
	}
	break;
      case 'd':
	bt.doy -= (bt.doy-1) % duration_valN;
	bt.hour = bt.minute = bt.second = bt.usec = 0;
	dy_to_mdy (bt.doy, bt.year, &bt.month, &bt.day);
	if (duration_val > 0) {
	    et = bt;
	    et.doy += duration_val;
	    et = normalize_ext (et);
	}
	break;
      case 'H':
	bt.hour -= bt.hour % duration_valN;
	bt.minute = bt.second = bt.usec = 0;
	if (duration_val > 0) {
	    et = bt;
	    et.hour += duration_val;
	    et = normalize_ext (et);
	}
	break;
      case 'M':
	bt.minute -= bt.minute % duration_valN;
	bt.second = bt.usec = 0;
	if (duration_val > 0) {
	    et = bt;
	    et.minute += duration_val;
	    et = normalize_ext (et);
	}
	break;
      case 'S':
	bt.second -= bt.second % duration_valN;
	bt.usec = 0;
	if (duration_val > 0) {
	    et = bt;
	    et.second += duration_val;
	    et = normalize_ext (et);
	}
	break;
      default:
	fprintf (info, "Error: invalid duration unit: %c\n", duration_unit);
	exit(1);
    }
    beg_duration = ext_to_int(bt);
    if (duration_val > 0) {
	end_duration = ext_to_int(et);
    }
    else {
	end_duration = beg_duration;
    }
    init_duration = 1;
}

/************************************************************************/
/*  after_duration:							*/
/*	Determine whether start time is after (incl) end duration.	*/
/*  return:								*/
/*	1 on true, 0 on false.						*/
/************************************************************************/
int after_duration
   (DATA_HDR	*hdr)		/* DATA_HDR for record.			*/
{
    if (tdiff(end_duration,beg_duration) == 0) return (0);
    if (tdiff(hdr->begtime,end_duration) >= 0) return (1);
    else return (0);
}

/************************************************************************/
/*  cross_duration:							*/
/*	Determine whether record crosses a duration boundary.		*/
/*  return:								*/
/*	1 on true, 0 on false.						*/
/************************************************************************/
int cross_duration
   (DATA_HDR	*hdr)		/* DATA_HDR for record.			*/
{
    if (tdiff(end_duration,beg_duration) == 0) return (0);
    if ((tdiff(beg_duration,hdr->begtime) > 0 && tdiff(beg_duration,hdr->endtime) <= 0) ||
	(tdiff(end_duration,hdr->begtime) > 0 && tdiff(end_duration,hdr->endtime) <= 0))
    return (1);
    else return (0);
}

/************************************************************************/
/*  intersect_duration:							*/
/*	Determine sample offset within record to split for duration.	*/
/*	Check the results to ensure that roundoff in sample duration	*/
/*	computation does not give the wrong offset.			*/
/*  return:								*/
/*	sample_offset in record (1 to nsamples-1)			*/
/************************************************************************/
int intersect_duration
   (DATA_HDR	*hdr)		/* DATA_HDR for record.			*/
{
    double diff, d;
    int seconds, usecs;
    int n, m;

#if QMERGE_DEBUG
    fprintf (info, "Duration is %s to ", time_to_str(beg_duration,date_fmt));	/*:: debug */
    fprintf (info, "%s\n", time_to_str(end_duration,date_fmt));	/*:: debug */
    fprintf (info, "Data is %s to ", time_to_str(hdr->begtime,date_fmt));   /*:: debug */
    fprintf (info, "%s\n", time_to_str(hdr->endtime,date_fmt));	/*:: debug */
#endif
    if (tdiff(end_duration,beg_duration) == 0) {
	fprintf (info, "Error: record does not intersect duration\n");
	exit (1);
    }

    if ((diff=tdiff(beg_duration,hdr->begtime)) > 0 && tdiff(beg_duration,hdr->endtime) <= 0) {
	if (hdr->rate_spsec != 0) {
	    double dusecs_per_point = ((double)(1.0/hdr->rate_spsec))*USECS_PER_SEC;
	    d = diff / dusecs_per_point;
	}
	else 
	    d = dsamples_in_time2 (hdr->sample_rate, hdr->sample_rate_mult, diff);
#if QMERGE_DEBUG
	fprintf (info, "intersect_duration: test 1, diff = %lf, d = %.15lf\n", diff , d); /*:: debug */
#endif
	n = ceil(d);
	m = floor(d);
	if (n != m) {
	    int second2, usec2;
#if QMERGE_DEBUG
	    fprintf (info, "intersect_duration: ceil(d) = %d\n", n);  /*:: debug */
#endif
	    time_interval2 (n, hdr->sample_rate, hdr->sample_rate_mult, &seconds, &usecs);
#if QMERGE_DEBUG
	    fprintf (info, "intersect_duration: floor(d) = %d\n", m);  /*:: debug */
#endif
	    time_interval2 (m, hdr->sample_rate, hdr->sample_rate_mult, &second2, &usec2);
	    if ((tdiff(add_time(hdr->begtime,seconds,usecs),beg_duration) >= 0) &&
		(tdiff(add_time(hdr->begtime,second2,usec2),beg_duration) >= 0 )) 
		n = m;
#if QMERGE_DEBUG
	    fprintf (info, "intersect_duration: n = %d\n", n);	/*:: debug */
#endif
	}
    }

    else if ((diff=tdiff(end_duration,hdr->begtime)) > 0 && tdiff(end_duration,hdr->endtime) <= 0) {
	if (hdr->rate_spsec != 0) {
	    double dusecs_per_point = ((double)(1.0/hdr->rate_spsec))*USECS_PER_SEC;
	    d = diff / dusecs_per_point;
	}
	else 
	    d = dsamples_in_time2 (hdr->sample_rate, hdr->sample_rate_mult, diff);
#if QMERGE_DEBUG
	fprintf (info, "intersect_duration: test 2, diff = %lf, d = %.15lf\n", diff , d); /*:: debug */
#endif
	n = ceil(d);
	m = floor(d);
	if (n != m) {
	    int second2, usec2;
#if QMERGE_DEBUG
	    fprintf (info, "intersect_duration: ceil(d) = %d\n", n);  /*:: debug */
#endif
	    time_interval2 (n, hdr->sample_rate, hdr->sample_rate_mult, &seconds, &usecs);
#if QMERGE_DEBUG
	    fprintf (info, "intersect_duration: floor(d) = %d\n", m);  /*:: debug */
#endif
	    time_interval2 (m, hdr->sample_rate, hdr->sample_rate_mult, &second2, &usec2);
	    if ((tdiff(add_time(hdr->begtime,seconds,usecs),end_duration) >= 0) &&
		(tdiff(add_time(hdr->begtime,second2,usec2),end_duration) >= 0))
		n = m;
#if QMERGE_DEBUG
	    fprintf (info, "intersect_duration: n = %d\n", n);	/*:: debug */
#endif
	}
    }

    else {
	fprintf (info, "Error: record does not intersect duration\n");
	exit (1);
    }

    if (n <= 0 || n >= hdr->num_samples) {
	fprintf (info, "Error: computing intersect_duration: %d for record with %d samples\n",
		 n, hdr->num_samples);
	fprintf (info, "Duration is %s to ", time_to_str(beg_duration,date_fmt));
	fprintf (info, "%s\n", time_to_str(end_duration,date_fmt));
	fprintf (info, "Data is %s to ", time_to_str(hdr->begtime,date_fmt));
	fprintf (info, "%s\n", time_to_str(hdr->endtime,date_fmt));
	exit (1);
    }
    return (n);
}

/************************************************************************/
/*  build_filename:							*/
/*	Build a filename from the template format.			*/
/************************************************************************/
char *build_filename
   (DATA_HDR	*hdr,		/* DATA_HDR for record.			*/
    char	*pattern)	/* filename pattern.			*/
{
    static char name[2048];
    char *ip, *op;
    EXT_TIME et;
    ip = pattern;
    op = name;
    switch (duration_date_flag) {
      case 'n':
	et = int_to_ext(beg_duration); 
	break;
      case 'd':
	et = int_to_ext(hdr->begtime); 
	break;
      default:	
	fprintf (info, "Error: Invalid duration date flag: %c\n", 
			 duration_date_flag);
	exit(1);
    }

    while (*ip != '\0') {
	switch (*ip) {
	  case ('%'):
	    switch (*++ip) {
	    case ('S'):
		sprintf (op, "%s", hdr->station_id);
		uppercase(op);
		op += strlen(hdr->station_id); break;
	    case ('s'):
		sprintf (op, "%s", hdr->station_id);
		lowercase(op);
		op += strlen(hdr->station_id); break;
	    case ('N'):
		sprintf (op, "%s", hdr->network_id);
		uppercase(op);
		op += strlen(hdr->network_id); break;
	    case ('n'):
		sprintf (op, "%s", hdr->network_id);
		lowercase(op);
		op += strlen(hdr->network_id); break;
	    case ('C'):
		sprintf (op, "%s", hdr->channel_id);
		uppercase(op);
		op += strlen(hdr->channel_id); break;
	    case ('c'):
		sprintf (op, "%s", hdr->channel_id);
		lowercase(op);
		op += strlen(hdr->channel_id); break;
	    case ('L'):
		sprintf (op, "%s", hdr->location_id);
		uppercase(op);
		op += strlen(hdr->location_id); break;
	    case ('l'):
		sprintf (op, "%s", hdr->location_id);
		lowercase(op);
		op += strlen(hdr->location_id); break;
	    case ('Y'):
		sprintf (op, "%04d", et.year);
		op += 4; break;
	    case ('y'):
		sprintf (op, "%02d", et.year % 100);
		op += 2; break;
	    case ('m'):
		sprintf (op, "%02d", et.month);
		op += 2; break;
	    case ('d'):
		sprintf (op, "%02d", et.day);
		op += 2; break;
	    case ('j'):
		sprintf (op, "%03d", et.doy);
		op += 3; break;
	    case ('H'):
		sprintf (op, "%02d", et.hour);
		op += 2; break;
	    case ('M'):
		sprintf (op, "%02d", et.minute);
		op += 2; break;
	    case ('T'):
	    case ('t'):
		sprintf (op, "%02d%02d%02d", et.hour, 
			 et.minute, et.second);
		op += 6; break;
	    case ('%'):
		strcpy (op, "%");
		op += 1; break;
	    default:
		fprintf (info, "Warning: invalid duration format: %%%c\n", *ip);
		sprintf (op, "%%%c", *ip);
		break;
	    }
	    ++ip; break;
	default:    *op++ = *ip++; break;
	}
    }
    *op = '\0';
    return(name);
}
