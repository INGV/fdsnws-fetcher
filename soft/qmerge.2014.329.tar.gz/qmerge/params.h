/************************************************************************/
/*  Parameters for qmerge:						*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

/*	$Id: params.h,v 1.11 2014/09/12 22:17:33 doug Exp $ 	*/

#ifndef	DEFAULT_NETWORK
#define	DEFAULT_NETWORK	"BK"
#endif

/* NOTE:  Specify pattern with double percents so that it can be    */
/* used in printf string.  The code that used the string will	    */
/* treat a %% as a single % for the purposes of pattern matching.   */
#ifndef	DEFAULT_VERIFY_PATTERN
#define	DEFAULT_VERIFY_PATTERN	"%%S.%%N.%%C.%%L.D.%%Y.%%j"
#endif

#define NULLDEV		"/dev/null"

#define	DEBUG
#define	DEBUG_SLEW	1
#define	DEBUG_TIME	2
#define	DEBUG_BLOCK	4
#define	DEBUG_HDRS	8
#define	DEBUG_FLAG	16
#define	DEBUG_STREAM	32
#define	DEBUG_OUT	64
#define	DEBUG_FILELIMIT	128
#define	DEBUG_ASCII	1024
#define	DEBUG_ASCII_1	2048
#define	DEBUG_ANY	0xFFFF
#define	    debug(val)  (debug_option & (val))

/*  Global parameters used throughout the program.			*/
/*  MAX_BLKSIZE:    maximum blocksize for input data.			*/
/*  BUFSIZE:	    size of input and output file buffers.		*/
/*  NOTE:   BUFSIZE must be large enough enought to hold any type of 	*/
/*	    file header, AND large enough to hold a block of data as	*/
/*	    well as additional STEIM blocks caused by reblocking.	*/

/*  The maximum number of samples per byte, based on the highest	*/
/*  compression algorithm supported.					*/
#define	MAX_SAMPLES_PER_BYTE	2

#define	MAX_BLKSIZE	8192
#define	BUFSIZE		(MAX_BLKSIZE * 2 )

#define	QDA_HDR_SIZE	64
#define	SDR_HDR_SIZE	64
#define	DRM_HDR_SIZE	64	/* This is WRONG -- look it up! */
#define	DRM_FILE_HDR_SIZE	sizeof(STORE_FILE_HEAD)
#define	MAX_HDR_SIZE		sizeof(STORE_FILE_HEAD)
#ifndef	PRINTABLE_BLANK_LOCATION
#define	PRINTABLE_BLANK_LOCATION    "--"
#endif

/*  RATE(rate) is in samples/second.					*/
/*  TOL(rate) = max size of gap in ticks that can be tolerated between	*/
/*  adjacent blocks of data at specified sample rate without causing a	*/
/*  hard time tear.							*/
/*  MERGE_TOL(rate) = max size of gap in ticks that can be tolerated	*/
/*  when merging adjacent blocks of data at specified sample rate 	*/
/*  without causing the start of a new block.				*/
/*  NOTE:  values are still defined in terms of TICKS.			*/

#define	TTOL_MULT		.4
#define	TOL(rate,mult)		((TTOL_MULT*USECS_PER_SEC)/(sps_rate(rate,mult)))
#define	MTOL_MULT		.1
#define	MERGE_TOL(rate,mult)	((MTOL_MULT*USECS_PER_SEC)/(sps_rate(rate,mult)))
#define	SPS_80_THRESHOLD	(1*TICKS_PER_MSEC*USECS_PER_TICK)

#define	SMALL_BLOCK_BIAS	1
#define	LARGE_BLOCK_BIAS	2
#define	NO_BIAS			0
#define	START_BIAS		SMALL_BLOCK_BIAS
#define	RUN_BIAS		NO_BIAS
#define	DEFAULT_OUTPUT_BLKSIZE	4096
#define	out_frames_per_block(blksize,hdrsize)	((int)((blksize-(hdrsize))/FRAMESIZE))

/* Flags for merge_blockette	*/
#define	BL_UNIQUE_COPY		1	/* For unique blockettes: Copy unless identical blockette exists.	*/
#define	BL_UNIQUE_MOVE		2	/* For unique blockettes: Move unless identical blockette exists.	*/
#define	BL_PER_RECORD_COPY	4	/* For per_record blockettes: Copy unless blockette number exists.	*/
#define	BL_PER_RECORD_MOVE	8	/* For per_record blockettes: Move unless blockette number exists.	*/
#define	BL_PER_RECORD_UPDATE	16	/* For per_record blockettes: Update contents if blockette exists.	*/

typedef struct _range {
    int	first;			/* first value in range.		*/
    int	last;			/* last value in range.			*/
} RANGE;

typedef struct _blockette_info {
    int blockette;		/* blockette number.			*/
    double seed_version;	/* earliest seed version containing it	*/
} BLOCKETTE_INFO;


