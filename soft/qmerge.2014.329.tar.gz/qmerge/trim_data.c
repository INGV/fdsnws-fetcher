/************************************************************************/
/*  Routine to unpack, trim and repack current input record.		*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef lint
static const char sccsid[] = "$Id: trim_data.c,v 1.19 2014/09/12 22:17:33 doug Exp $ ";
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <math.h>

#include "qlib2.h"

#include "params.h"
#include "st_info.h"
#include "procs.h"
#include "externals.h"

/************************************************************************/
/*  trim_data:								*/
/*	Trim beginning and/or end of input data record(s).		*/
/*	Unpack all records, coalesce all blockettes, trim data,		*/
/*	optionally set new initial diff, and reblock into one or more	*/
/*	records.							*/
/*	It is assumed the ptr st_p->cur_hdr is same as hdrs[0],	so	*/
/*	st_p->cur_hdr is updated to point to the first new header.	*/
/************************************************************************/
void trim_data 
   (ST_INFO	*st_p,		/* ptr to input stream struct.		*/
    int		begin_trim_pts,	/* # points to discard on head.		*/
    int		end_trim_pts,	/* # points to discard on tail.		*/
    int		split_offset,	/* sample offset to split record.	*/
    int		new_d0_flag,	/* flag to set new init diff.		*/
    int		new_d0,		/* new initial diff value.		*/
    int		blksize,	/* desired output blksize.		*/
    int		data_type_out,	/* desired output data format.		*/
    RECORD_LIST	record_list[],	/* list of records.			*/
    int		max_records)	/* max number of records in list.	*/
{
    int		    *p;
    void	    *pdata = (void *)databuff;	/* ptr to unpacked data	*/
    int             *pdiff = diffbuff;		/* ptr to unpacked diffs*/
    int		    npts;		/* total # of data points.	*/
    int		    n;			/* index of next pt to output.	*/
    int		    seconds, usecs;	/* seconds and usecs for time.	*/
    double	    dusecs;		/* double precision usecs.	*/
    double	    dusecs_per_point;	/* # of usecs in 1 data pt.	*/
    int		    data_type_in;	/* data type of input data.	*/
    DATA_HDR	    *hdr;		/* current header.		*/
    DATA_HDR	    *master_hdr;	/* master composite hdr.	*/
    void	    *p_repack;		/* ptr to repacked SEED Data.	*/
    BS		    *bs;		/* ptr to blockette structure.	*/
    BS		    *delete_bs;		/* blockette structure to free.	*/
    BLOCKETTE_HDR   *bh;		/* ptr to blockette hdr.	*/
    int		    bl_type;		/* blockette type.		*/
    int		    bl_len;		/* blockette length.		*/
    int		    bl_size;		/* total size of all blockettes.*/
    int		    bl_index;		/* index for blockette insert.	*/
    int		    h;			/* indices.			*/
    int		    status;		/* status from repack data.	*/
    int		    nbytes;		/* # data bytes in output rec.	*/
    int		    maxpts;		/* max # pts for output record.	*/
    int		    nsamples;		/* # data pts in output record.	*/
    int		    hdr_size;		/* size of header + blockettes.	*/
    int		    max_data_bytes;	/* max # data bytes in record.	*/
    int		    data_offset;	/* offset (in bytes) of data.	*/
    int		    unique_info_added;	/* flag for unique info in frame*/
    int		    pad = 1;		/* flag to pad out all frames.	*/
    int		    steim_comp_in;	/* flag for steim compression.	*/
    int		    steim_comp_out;	/* flag for steim compression.	*/
    MS_ATTR	    attr;
    int		    *pidata;
    float	    *pfdata;
    double	    *pddata;

    steim_comp_in = ((bs = find_blockette(st_p->cur_hdr,1000)) &&
	(bh = (BLOCKETTE_HDR *)(bs->pb)) &&
	! (IS_STEIM_COMP(((BLOCKETTE_1000 *)bh)->format))) ? 0 : 1;

    /* Trimming or reblocking data may cause an expansion in the number	*/
    /* of bytes used to represent this input record.  The original	*/
    /* record may have already been unpacked and repacked into one or	*/
    /* more records.  We must therefore unpack all records on the list,	*/
    /* trim the data or fix the initial differences, and then repack	*/
    /* the data into one or more records.				*/
    /* Since each record needs to be constructed with the data located	*/
    /* at the appropriate offset within the IOB buffer, we allocate a	*/
    /* separate IOB for each new record that we recreate.		*/
    /*									*/
    /* It is the responsibility of the calling routine to free the 	*/
    /* DATA_HDRs and IOBs in the record_list.				*/

    /* Make a master hdr which is a copy of the first on the list.	*/
    /* This hdr will get a copy of every unique blockette from every	*/
    /* hdr on the list.							*/
    master_hdr = dup_data_hdr(record_list[0].hdr);
    if (master_hdr == NULL) {
	fprintf (info, "Error: duplicating data_hdr\n");
	exit(1);
    }
    delete_blockette (master_hdr, -1);
    master_hdr -> num_data_frames = 0;

    if (debug(DEBUG_STREAM)) {
	fprintf (info, "trim_data: trimming input record: %d points from head, %d points from tail\n",
		 begin_trim_pts, end_trim_pts);
	fflush (info);
    }

    /* Loop over all records in the list, saving all unique blockettes	*/
    /* and unpacking all data frames.					*/
    /* Free the hdrs and iobs for the records after they are unpacked.	*/
    npts = 0;
    for (h=0; record_list[h].hdr!=NULL; h++) {
	if (debug(DEBUG_STREAM)) {
	    fprintf (info, "trim_data: unpacking, seq=%d.%d, n_samples=%d, time=%s\n",
		 record_list[h].hdr->seq_no, h, record_list[h].hdr->num_samples,
		 time_to_str(record_list[h].hdr->begtime,date_fmt));
	    fflush (info);
	}
	merge_blockettes (master_hdr, record_list[h].hdr, BL_UNIQUE_COPY + BL_PER_RECORD_COPY);
	st_p->cur_hdr = record_list[h].hdr;
	st_p->iob = record_list[h].iob;

	data_type_in = unpack_sdr_data (st_p, pdata, pdiff, npts,
				     st_p->cur_hdr->num_samples);
	if (data_type_in == UNKNOWN_DATATYPE) {
	    fprintf (info, "Error: unknown or corrupt record seq=%d, aborting\n",
		     st_p->cur_hdr->seq_no);
	    st_p->cur_hdr->num_samples = st_p->cur_hdr->num_data_frames = 0;
	    st_p->cur_hdr->xn = st_p->cur_hdr->x0;
	    exit(1);
	}
	/* If no explicit output data format, set to input data format.	*/
	if (data_type_out == UNKNOWN_DATATYPE) data_type_out = data_type_in;


	/* Update unpacked data count and free the record. */
	npts += st_p->cur_hdr->num_samples;
	free_data_hdr (record_list[h].hdr);
	free_iob (record_list[h].iob);
	record_list[h].hdr = NULL;
	record_list[h].iob = NULL;

	/* Update unpacked data buffer and data difference pointers. */
	pdiff = diffbuff + npts;
	switch (mseed_to_data_format(data_type_in)) {
	  case DATA_FMT_INT:
	    pidata = (int *)databuff;
	    pdata = (int *)(pidata + npts);
	    break;
	  case DATA_FMT_FLOAT:
	    pfdata = (float *)databuff;
	    pdata = (float *)(pfdata + npts);
	    break;
	  case DATA_FMT_DOUBLE:
	    pddata = (double *)databuff;
	    pdata = (double *)(pddata + npts);
	    break;
	  default:
	    fprintf (info, "Error: unsupported MiniSEED data format: %d\n", data_type_in);
	    exit(1);
	}
    }

    if (npts < 0) {
	fprintf (stderr, "Error: requesting unpack/repack of %d samples\n", npts);
	exit(1);
    }

    /* Add required blockettes and remove any unwanted blockettes. */
    if (add_required_blockettes(master_hdr) != 0) {
	fprintf (info, "Error: adding required blockettes\n");
	exit(1);
    }
    delete_unwanted_blockettes(master_hdr);

    /* Transform data buffer if output data type is different from input data type */
    transform_data_buffer(mseed_to_data_format(data_type_in),
			  mseed_to_data_format(data_type_out));

    /* Build diff values if input data did not have diffs and output requires it. */
    /* If we require diffs, data should by now be in integer format. */
    /* Get previous value from output stream's sum_hdr xn. */
    steim_comp_out = IS_STEIM_COMP(data_type_out);
    if (steim_comp_out && ! steim_comp_in) {
	ST_INFO *out = st_head_out.next;
	int prev = out->sum_hdr->xn;
	build_diff ((int *)databuff, diffbuff, st_p->cur_hdr->num_samples, prev);
    }
    if (new_d0_flag) *diffbuff = new_d0;

    /* Repack the data into output frames into one or more records.	*/
    h = 0;
    n = begin_trim_pts;
    npts -= end_trim_pts;
    while (n < npts && h < max_records) {
	int ok;
	unique_info_added = 0;

	/* Make a new header, and initialize it from the master hdr.	*/
	hdr = record_list[h].hdr = dup_data_hdr(master_hdr);
	if (hdr == NULL) {
	    fprintf (info, "Error: duplicating data_hdr\n");
	    exit(1);
	}
	delete_blockette (hdr, -1);
	record_list[h].iob = new_iob();
	hdr->num_samples = hdr->num_data_frames = hdr->num_blockettes = 0;
	hdr->first_data = hdr->first_blockette = 0;
	/* Explicitly set the desired output data_wordorder.		*/
	hdr->data_wordorder = output_data_wordorder;
	/* Explicitly set the desired blksize.				*/
	hdr->blksize = blksize;
	/* Explicitly set the desired data_type.			*/
	hdr->data_type = data_type_out;

	/* Copy and/or move all blockettes that fit from the master_hdr	*/
	/* over to this header.						*/
	/* Make 2 passes through the master blockette list --		*/
	/* first for blockettes that must be applied to every record,	*/
	/* then for unique blockettes assigned to only 1 record.	*/
	bl_size = 0;
	for (bs=master_hdr->pblockettes; bs!=NULL; bs=bs->next) {
	    bl_type = bs->type;
	    bl_len = bs->len;
/*::	    if (debug(DEBUG_STREAM)) fprintf (info, "trim_data: found blockette %d in master_hdr\n", bl_type);*/
	    if (! is_per_record_blockette(bl_type)) break;
	    if (hdr->first_blockette == 0) hdr->first_blockette = 48;
	    if (bl_size + (int)bs->len + hdr->first_blockette <= blksize) {
		bl_index = (bl_type == 1000) ? 0 : -1;
		ok = add_blockette (hdr, bs->pb, bs->type, bs->len, bs->wordorder, bl_index);
		if (ok != 1) {
		    fprintf (info, "Error: unable to add blockette\n");
		    exit(1);
		}
		bl_size += bs->len;
	    }
	    else {
		fprintf (stderr, "Error: unable to fit minimal blockettes in output record\n");
		exit(1);
	    }
	}
	for (bs=master_hdr->pblockettes,delete_bs=NULL;
	     bs!=NULL; 
	     bs=bs->next,delete_pblockette(hdr,delete_bs),delete_bs=NULL) {
/*::	    bl_type = ((BLOCKETTE_HDR*)(bs->pb))->type; */
	    bl_type = bs->type;
	    bl_len = bs->len;
	    if (is_per_record_blockette(bl_type)) continue;
	    if (hdr->first_blockette == 0) hdr->first_blockette = 48;
	    if (bl_size + (int)bs->len + hdr->first_blockette <= blksize) {
		bl_index = -1;
		ok = add_blockette (hdr, bs->pb, bs->type, bs->len, bs->wordorder, bl_index);
		if (ok != 1) {
		    fprintf (info, "Error: unable to add blockette\n");
		    exit(1);
		}
		delete_bs = bs;
		bl_size += bs->len;
		++unique_info_added;
	    }
	}

	/* Ensure that we have room for something unique in this record-*/
	/* either unique blockette or data.  If not, the output		*/
	/* blocksize is too small, and we have deadlock.		*/
	attr = get_ms_attr (hdr);
	if (attr.alignment == 0) {
	    fprintf (info, "Error: getting ms_attr\n");
	    exit(1);
	}
	if (hdr->first_blockette == 0) hdr_size = 48;
	else hdr_size = hdr->first_blockette + bl_size;
	hdr_size = ((hdr_size+attr.alignment-1)/attr.alignment)*attr.alignment;
	data_offset = hdr_size;
	max_data_bytes = (blksize - hdr_size);
	if (unique_info_added == 0 && 
	    (max_data_bytes == 0 || max_data_bytes < attr.sample_size)) {
	    fprintf (stderr, "Error: unable to fit data into output record\n");
	    exit(1);
	}

	switch(mseed_to_data_format(data_type_out)) {
	case DATA_FMT_INT:
	  pdata = ((int*)databuff)+n;
	  break;
	case DATA_FMT_FLOAT:
	  pdata = ((float*)databuff)+n;
	  break;
	case DATA_FMT_DOUBLE:
	  pdata = ((double*)databuff)+n;
	  break;
	default:
	  fprintf (info, "Error: unknown output data_type: %d\n", data_type_out);
	  exit(1);
	  break;
	}

	/* Pack the remaining space in the record with data frames.	*/
	/* pdata = (int*)databuff + n; */
	pdiff = diffbuff + n;

	maxpts = (split_offset > n && split_offset < npts) ? 
	    split_offset - n : npts - n;
	p_repack = (void *)(record_list[h].iob->buf+data_offset);
	nbytes = nsamples = 0;
	if (max_data_bytes > 0) {
	    status = repack_sdr_data (p_repack, pdata, pdiff, maxpts,
				      max_data_bytes, hdr->data_type, pad, 
				      hdr->data_wordorder, &nbytes, &nsamples);
	}
	hdr->num_samples = nsamples;
	hdr->num_data_frames =  (steim_comp_out) ? nbytes / sizeof(FRAME) : 0;
	hdr->first_data = (nsamples > 0) ? data_offset : 0;

	/*  Update the header information to reflect new data interval. */
	/*  We are now preserving for each repacked record:		*/
	/*	a.  num_ticks_correction.				*/
	/*	b.  The ACTIVITY_TIME_GAP, ACTIVITY_CALIB_PRESENT,	*/
	/*	    and ACTIVITY_EVENT_IN_PROGRESS flags.		*/
	/*	a.  hdrtime, which may or may not have			*/
	/*	    num_ticks_correction added in.			*/
	/*  Compute new begtime, hdrtime, and endtime in a manner that	*/
	/*  prevents overflows.						*/
	if (hdr->rate_spsec != 0) {
	    dusecs_per_point = ((double)(1.0/hdr->rate_spsec))*USECS_PER_SEC;
	    dusecs = dusecs_per_point * n;
	    hdr->begtime = add_dtime(master_hdr->begtime, dusecs);
	    hdr->hdrtime = add_dtime(master_hdr->hdrtime, dusecs);
	    hdr->endtime = add_dtime(hdr->begtime, dusecs_per_point * (nsamples-1));
/*::	    if (debug(DEBUG_STREAM)) fprintf (info, "trim_data: using blockette 100 info in reassembled record\n");*/
	}
	else {
	    time_interval2 (n, hdr->sample_rate, hdr->sample_rate_mult, 
			    &seconds, &usecs);
	    hdr->begtime = add_time (master_hdr->begtime, seconds, usecs);
	    hdr->hdrtime = add_time (master_hdr->hdrtime, seconds, usecs);
	    time_interval2 (nsamples-1, hdr->sample_rate, hdr->sample_rate_mult, 
			    &seconds, &usecs);
	    hdr->endtime = add_time (hdr->begtime, seconds, usecs);
/*::	    if (debug(DEBUG_STREAM)) fprintf (info, "trim_data: no blockette 100 in reassmbled record\n");*/
	}

	p = (int *)(record_list[h].iob->buf + hdr->first_data + 4);
	if (steim_comp_out) {
	    hdr->x0 = *(p++);
	    hdr->xn = *(p++);
	    if (hdr->data_wordorder != my_wordorder) {
		swab4 (&hdr->x0);
		swab4 (&hdr->xn);
	    }
	}
	else hdr->x0 = hdr->xn = 0;
	hdr->num_ticks_correction = master_hdr->num_ticks_correction;
	if (h != 0) {
	    hdr->activity_flags &= (ACTIVITY_TIME_GAP | 
				    ACTIVITY_BEGINNING_OF_EVENT |
				    ACTIVITY_CALIB_PRESENT);
	}

	if (debug(DEBUG_STREAM)) {
	    double dusec1;
	    if (hdr->rate_spsec != 0) dusec1 = ((double)1.0/hdr->rate_spsec) * USECS_PER_SEC;
	    else {
		time_interval2 (1, hdr->sample_rate, hdr->sample_rate_mult, &seconds, &usecs);
		dusec1 = seconds * USECS_PER_SEC * usecs;
	    }
	    fprintf (info, "trim_data: repacking, seq=%d.%d, n_samples=%d, ",
		     record_list[h].hdr->seq_no, h, record_list[h].hdr->num_samples);
	    fprintf (info, "time=%s to ", time_to_str(record_list[h].hdr->begtime,date_fmt));
	    fprintf (info, "%s\n", time_to_str(add_dtime(record_list[h].hdr->endtime, dusec1),date_fmt));
	    fflush (info);
	}

	n += nsamples;
	h++;
    }

    if (n < npts) {
	/* We ran out of records.  Die an ungraceful death. */
	fprintf (info, "Error: exceeded %d records available\n", max_records);
	exit(1);
    }

    /* Set the stream's current header to point to the new header, and	*/
    /* free the master header that held the union of all blockettes.	*/
    st_p->cur_hdr = record_list[0].hdr;
    st_p->iob = record_list[0].iob;
    free_data_hdr(master_hdr);

    if (debug(DEBUG_STREAM)) {
	fprintf (info, "trim_data: data repacked into %d records:\n", h);
	fflush (info);
    }

    return;
}
