/************************************************************************/
/*  Version number.							*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

/*	$Id: version.h,v 1.43 2014/11/25 20:01:56 doug Exp $ 	*/

#define	VERSION	"1.4.57 (2014.329)"

/*
Modification History
------------------------------------------------------------------------
Date	 Ver	Who What
------------------------------------------------------------------------
2014/11/24 1.4.57 (2014.329)
	Fix same_type_data_stream() in process_utils.c to compare full SNCL.
2014/09/14 1.4.56 (2014.258)
	Fix close output file and open new output file with -P option.
	Fix debugging output.
2014/08/29 1.4.55 (2014.241)
	Add support for multichannel miniSEED (1 input stream only).
2013/09/16 1.4.54 (2013.259)
	Update parse_cmdline() to use basename function.
	Add missing #include to qio.c
	Cleaned up all code to minimize warnings.
	Fix unpacking/reformatting/repacking code in trim_data.
2013/05/22 1.4.53 (2013.142)
	Fix find_best_stream() logic to properly select stream.
	Mod in 1.4.52 incorrectly skipped stream under certain conditions.
2013/04/29 1.4.52 (2013.119)
	Add getting overall timespan from seekable SDR files with volhdr.
	Add priority for record's data quality (record_type).
	Remove record warning when using data from new stream.
2012/10/125 1.4.51 (2012.299)
	Option -n for qverify now suppresses data summary output.
2012/10/18  1.4.50 (2012.292)
	qverify verify record type of first record if no record type specified.
2011/07/29  1.4.49 (2011.210)
	Fixed bug in trim_data and unpack_sdr_data that caused data 
	d0 errors and aborted processing if calling trim_data
	with multiple records (previously unpacked and repacked)
	records in record_list.
2011/02/15  1.4.48 (2011.046)
	Added precision to dp floating point output format.
2010/04/26  1.4.47 (2010.116)
	Added support for 'M' MiniSEED records.
2010/04/05  1.4.46 (2010.095)
	Removed spurious "stop here" messages in trim_data.c
2009/07/08  1.4.45 (2009.189)
	Fixed rounding problem with use of log2() on linux.
2009/04/30  1.4.44 (2009.120)
	Relax output restrictions to allow a multiple STEIM formats 
	in an output stream.
2008/06/25  1.4.43 (2008.177)
	Add "-i rate" option.  
	Allow duration_val of 0 to generate filename from template.
2007/06/12  1.4.42 (2007.168)
	Fix detection of blockette 1000 in arch-independent fashion.
	Fix merge_blockettes, cleanup code with lint.
2007/04/06  1.4.41 (2007.096)
	Fix append_to_output to recreate out-cur_hdr and out->sum_hdr
	after closing a duration file.
2007/03/07  1.4.40 (2007.066)	Doug Neuhauser
	Fix rate comparison in process_utils.c/same_type_data_stream().
2006/12/20  1.4.39 (2006.354)	Doug Neuhauser
	Fix error in help output for -s option.
2005/11/17  1.4.38 (2005.321)	Doug Neuhauser
	Fix process_blockk to properly discard record when all samples have been trimmed.
	Fix trim_data debug code to detech when all samples have been trimmed.
2005/10/16  1.4.37 (2005.289)	Doug Neuhauser
	Fix process_block to detect when all samples have been trimmed from input record.
2005/09/05  1.4.36 (2005.248)	Doug Neuhauser
	Specifying a  blksize of 0 will use the blksize of the first used MiniSEED record.
2005/06/29  1.4.35 (2005.180)	Doug Neuhauser
	Default wordorder to big endian.
	Do not allow little endian data (violates DDL for currently defined datatypes).
	Preserve input record_type unless explicitly set by program.
2005/03/28  1.4.34  (2005.087)	Doug Neuhauser
	Add "-l char" option to specify filename delimiter for optional offset and len.
2004/04/07  1.4.33  (2004.098)	Doug Neuhauser
	Fix trim_data() and intersect_duration() to properly use
	blockette 100 precise sample rate.
2004/02/04  1.4.32  (2004.035)	Doug Neuhauser
	Properly handle blockette 100 with precise sample rate.
2003/08/08  1.4.31  (2003.220)	Doug Neuhauser
	Allow channel index of SEED telemetry files with no data records.
	Changed handling of content printing and header printing for
	telemetry files with no data.
	Change default token string for blank location from "__" to "--".
	See CHANGES file.
2003/07/29  1.4.30  (2003.210)	Doug Neuhauser
	Added error handling for qlib2 with no exit.  See CHANGES file.
2003/06/27  1.4.29  (2003.178)	Doug Neuhauser
	Added -d 2048 option.  See CHANGES file.
2003/01/19  1.4.29b (2003.019)	Doug Neuhauser
	Converted for use with qlib2_init(1).
2003/01/02  1.4.28 (2003.002)	Doug Neuhauser
	Add recognition of Rmerge, Qmerge, and Dmerge as way to initialize
	the -R argument.
2002/11/22 1.4.27 (2002.326)	Doug Neuhauser
	Fix delete_unwanted_blockettes() to correctly get blockette number.
	Change filename_pattern to include location code.
	Do not merge records with different record_type unless output 
	record_type is explicitly specified.
2002/05/21 1.4.25b (2002.171)	Doug Neuhauser
	Fix delete_unwanted_blockettes() to perform short swab if necessary.
	Add -Q option for new record_type quality indicator (D,Q,R).
2002/05/21 1.4.24 (2002.141)	Doug Neuhauser
	Added data output option for explicit data format conversion.
	Added repacking option.
	Fixed duration code, replaced -O 0|1 with -w 0|1.
	Add -O output_format option.
	Fix merge_blockette code.
	Change default verify pattern to include location code.
2001/12/02 1.4.23 (2001.353)	Doug Neuhauser
	qio.c, version.h
	Fix closing and opening files if no stdio streams available.
2001/12/02 1.4.22 (2001.336)	Doug Neuhauser
	process_utils.c, parse_cmdline.c, version.h
	Fix creation of b1000 when input hdr is non-native wordorder.
	Fix parsing -w option.
2001/11/20 1.4.21 (2001.342)	Doug Neuhauser (shoule be 2001.324)
	qmerge.c, version.h
	Fix -O output_data_format help.
2001/10/15 1.4.20 (2001.288)	Doug Neuhauser
	qmerge.c, version.h
	Fix -H code.
2001/07/23 1.4.19 (2001.204)	Doug Neuhauser
	process_utils.c, version.h
	Fix merge_blockette code.
2001/07/03 1.4.18 (2001.184)	Doug Neuhauser
	process_block.c, process_utils.c, qmerge.c, procs.h, parse_cmdline.c, duration.c, version.h
	Fixed duration code, replaced -O 0|1 with -w 0|1.
	Added data output option for explicit data format conversion.
	Added repacking option.
2000/10/25 1.4.17 (2000.300)	Doug Neuhauser
	parse_cmdline.c, qmerge.c, version.h
	Added -w option to specify wordorder of header and/or data.
2000/10/05 1.4.16 (2000.278)	Doug Neuhauser
	process_block.c version.h
	Convert usecs_per_point from int to double, change all add_time to add_dtime
	to handle data with rate=-14400 (4 hour interval).
	Output gap to microsecond precision.
2000/04/21 1.4.15 (2000.112)	Doug Neuhauser
	procs.h, extennals.h, version.h
	Fixed header files for compilation by C++.
1999/11/10 1.4.14 (1999.314)	Doug Neuhauser
	parse_cmdline.c, version.h
	Qverify now turn on verify_data automatically.
1999/07/07 1.4.13 (1999.188)	Doug Neuhauser
	process_block.c, find_best_stream.c, qmerge.c, version.h
	Added support for qverify on non-data files (eg LOG, ACE, event detections).
1999/04/23 1.4.12 (1999.145)	Doug Neuhauser
	process_block.c process_utils.c get_stream_info.c qio.c params.h 
	qmerge.c st_info.h externals.h parse_cmdline.c version.h
	Header for summary message now uses the format "station.network.channel.location".
	Added location code and blksize to -c and -H output.
	Integrated code for qverify.
1999/04/08 1.4.11 (1999.098)	Doug Neuhauser
	process_utils.c
	Changed UWORD to SEED_UWORD datatype to reflect qlib2 change.
1999/04/02 1.4.10 (1999.092)	Doug Neuhauser
	process_block.c
	Removed d0 warning messages when using -i no_d0 option.
1999/04/01 1.4.9 (1999.091)	Doug Neuhauser
	externals.h
	Removed duplicate declaration of outfile.
1999/02/15 1.4.8 (1999.046)	Doug Neuhauser
	pack_unpack.c/unpack_sdr_data: 
	Take blksize from record header, NOT from stream info, since this
	record may have already been reblocked.
1998/12/30 1.4.7 (1998.364)   Doug Neuhauser
	From Sid Hellman:  Add line in process_block.c/write_seed_hdr to
	include location code.
1998/06/10 1.4.6 (1998.161)   Doug Neuhauser
	Fixed merge_tol() in process_utils.c to check for explicitly 
	set block_tol value instead of stream_tol value.
	Changed param.h to use parameters instead of constants for the 2 
	tol multipliers.  Use the parameters in help output in qmerge.c.
1998/05/28 1.4.5 (1998.149)   Doug Neuhauser
	Added -u option to specify that all input data is unique.
	This suppressed trimming out presumed duplicate data from
	overlapping data blocks.
	Standardized on "Error:" prefix for fatal error message.s
1997/11/08 1.4.4 (1997.314)   Doug Neuhauser
	Fixed code to allow duration (-P and -p) and -n to coexist.
	Changed -n option to suppress file open and writing instead
	of relying on /dev/null.  Added "deferred" flag to iob.
	Fixed ref to outdated out_p in qmerge.c.
1997/10/21 1.4.3 (1997.294)   Doug Neuhauser
	Added duration code ( -P and -p options) to split output
	into files of specified time duration.
1997/09/15 1.4.2 (1997.258)   Doug Neuhauser
	Fixed problem with unpack/repack of records.
	Added -I option to specify default input format.
*/
