# http://pyrocko.org - GPLv3
#
# The Pyrocko Developers, 21st Century
# ---|P------/S----------~Lg----------

'''
Squirrel - dataset inspection and management.
'''

from pyrocko.squirrel import main

if __name__ == '__main__':
    main()
