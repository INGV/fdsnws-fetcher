# http://pyrocko.org - GPLv3
#
# The Pyrocko Developers, 21st Century
# ---|P------/S----------~Lg----------

'''
Clients to retrieve earthquake catalogs and seismic waveforms from online
resources.
'''
