[//]: # (Thank you for helping us improve Pyrocko. Please include enough details so that we can reproduce your issue.)
