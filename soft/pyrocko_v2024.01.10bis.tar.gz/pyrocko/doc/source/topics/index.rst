Special Topics
==============

Conceptual overviews on certain ingredients of Pyrocko.

.. toctree::
   :maxdepth: 2

   pyrocko-gf
   pseudo-dynamic-rupture
   squirrel
