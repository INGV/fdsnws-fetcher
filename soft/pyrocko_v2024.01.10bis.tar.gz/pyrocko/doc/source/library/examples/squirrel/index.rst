
.. image:: /static/squirrel.svg
   :align: left

Squirrel-powered data access
----------------------------

Code examples on how to use the :doc:`Squirrel framework
</library/reference/pyrocko.squirrel>` for seismological data handling.

.. raw:: html

   <div style="clear:both"></div>

.. toctree::
   :maxdepth: 2

   cli_tool
