
Applications
============

Applications for everyday seismological practice.

.. toctree::
   :maxdepth: 1

   snuffler/index
   cake/index
   fomosto/index
   jackseis/index
   colosseo/index
   squirrel/index
   sparrow/index
   pyrocko/index
