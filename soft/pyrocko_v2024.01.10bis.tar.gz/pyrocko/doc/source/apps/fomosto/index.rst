Fomosto - *Green's function database management*
================================================

Fomosto is a command line tool contained in the Pyrocko package to manage
pre-calculated Green's function stores.

.. toctree::
   :maxdepth: 2

   tutorial
   backends
