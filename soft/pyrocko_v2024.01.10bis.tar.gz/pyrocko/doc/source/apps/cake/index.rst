Cake - *travel-times and ray paths for 1D layered media*
========================================================

Cake is a command line tool contained in Pyrocko, which can solve some
classical seismic ray theory problems for 1D layered earth models (layer cake
models).

.. toctree::
   :maxdepth: 2

   manual
