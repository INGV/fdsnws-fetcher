# Pyrocko Data repository

Data that ships with `pyrocko` is living in here.
