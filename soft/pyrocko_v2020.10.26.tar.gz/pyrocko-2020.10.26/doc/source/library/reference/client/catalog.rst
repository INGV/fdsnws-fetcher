Online earthquake catalogs (``client.catalog``)
===============================================

.. automodule :: pyrocko.client.catalog
    :members:


``client.catalog.Geofon``
-------------------------

.. autoclass :: pyrocko.client.catalog.Geofon
    :show-inheritance:
    :members:

``client.catalog.GlobalCMT``
----------------------------

.. autoclass :: pyrocko.client.catalog.GlobalCMT
    :show-inheritance:
    :members:

``client.catalog.USGS``
-----------------------

.. autoclass :: pyrocko.client.catalog.USGS
    :show-inheritance:
    :members:

``client.catalog.Saxony``
-------------------------

.. autoclass :: pyrocko.client.catalog.Saxony
    :show-inheritance:
    :members:
