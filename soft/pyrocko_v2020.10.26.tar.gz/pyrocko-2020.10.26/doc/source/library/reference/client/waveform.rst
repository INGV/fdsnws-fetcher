Online waveform and station metadata archives (``client``)
==========================================================

``client.fdsn``
---------------

.. automodule :: pyrocko.client.fdsn
    :members:
    :show-inheritance:


``client.iris``
---------------

.. automodule:: pyrocko.client.iris
    :members:
