Seismic Velocity Datasets (``dataset``)
=======================================

``dataset.crust2x2``
--------------------

.. automodule :: pyrocko.dataset.crust2x2
    :members:


``dataset.crustdb``
-------------------

.. automodule :: pyrocko.dataset.crustdb
    :members: CrustDB, VelocityProfile

