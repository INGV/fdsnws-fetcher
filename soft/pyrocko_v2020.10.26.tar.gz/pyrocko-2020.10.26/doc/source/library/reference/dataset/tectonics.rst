Tectonic Datasets (``dataset.tectonics``)
=========================================

``dataset.tectonics.PeterBird2003``
-----------------------------------

.. autoclass:: pyrocko.dataset.tectonics.PeterBird2003
    :members:

.. autoclass:: pyrocko.dataset.tectonics.Plate
    :members:

``dataset.tectonics.GSRM1``
---------------------------

.. autoclass:: pyrocko.dataset.tectonics.GSRM1
    :members:
