Topographic Datasets (``dataset.topo``)
=======================================

.. automodule :: pyrocko.dataset.topo
    :members:


``dataset.topo.etopo1``
-----------------------

.. automodule :: pyrocko.dataset.topo.etopo1
    :members:


``dataset.topo.srtmgl3``
------------------------

.. automodule :: pyrocko.dataset.topo.srtmgl3
    :members:
