Geographic Datasets (``dataset``)
=================================

``dataset.geonames``
--------------------

.. automodule :: pyrocko.dataset.geonames
    :members:


``dataset.gshhg``
-----------------

.. automodule :: pyrocko.dataset.gshhg
    :members: GSHHG, Polygon
