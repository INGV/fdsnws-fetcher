``client``
==========

.. automodule::
    pyrocko.client


.. toctree::
    :maxdepth: -1
    :hidden:

    client/waveform
    client/catalog
