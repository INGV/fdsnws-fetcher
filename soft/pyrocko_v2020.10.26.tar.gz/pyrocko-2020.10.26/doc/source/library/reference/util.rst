``util``
========

.. automodule:: pyrocko.util
    :members:
