``gui.snuffling``
=================

.. automodule:: pyrocko.gui.snuffling
    :members:
