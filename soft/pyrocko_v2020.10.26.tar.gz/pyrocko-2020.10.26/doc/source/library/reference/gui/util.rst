``gui.util``
============

.. automodule:: pyrocko.gui.util
    :members:
