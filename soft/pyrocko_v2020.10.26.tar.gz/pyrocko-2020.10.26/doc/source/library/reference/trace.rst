``trace``
=========

.. automodule:: pyrocko.trace
   :members:
