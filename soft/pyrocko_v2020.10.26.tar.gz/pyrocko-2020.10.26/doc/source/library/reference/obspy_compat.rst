``obspy_compat``
================

.. automodule:: pyrocko.obspy_compat
    :members:
