GMT powered automatic maps
==========================

``plot.automap``
----------------

.. automodule:: pyrocko.plot.automap
    :members: Map
