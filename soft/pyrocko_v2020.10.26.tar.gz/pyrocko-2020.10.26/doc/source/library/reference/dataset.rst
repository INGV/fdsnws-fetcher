``dataset``
===========

.. automodule ::
    pyrocko.dataset



.. toctree::
    :maxdepth: 2

    dataset/topographic
    dataset/tectonics
    dataset/geographic
    dataset/seismic_velocities
