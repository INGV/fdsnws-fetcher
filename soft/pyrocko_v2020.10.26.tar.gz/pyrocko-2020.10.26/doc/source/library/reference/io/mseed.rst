``pyrocko.io.mseed``
===================================

.. automodule:: pyrocko.io.mseed
    :members:
