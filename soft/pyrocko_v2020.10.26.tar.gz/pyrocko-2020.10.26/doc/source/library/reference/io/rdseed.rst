``pyrocko.io.rdseed``
===================================

.. automodule:: pyrocko.io.rdseed
    :members:
