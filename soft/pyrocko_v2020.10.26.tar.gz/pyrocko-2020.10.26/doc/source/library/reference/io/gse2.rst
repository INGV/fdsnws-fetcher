``pyrocko.io.gse2``
===================================

.. automodule:: pyrocko.io.gse2
    :members:
