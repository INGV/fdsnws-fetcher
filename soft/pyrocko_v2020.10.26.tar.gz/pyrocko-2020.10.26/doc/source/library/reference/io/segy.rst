``pyrocko.io.segy``
===================================

.. automodule:: pyrocko.io.segy
    :members:
