``model.event``
===============

.. automodule :: pyrocko.model.event
    :members:
