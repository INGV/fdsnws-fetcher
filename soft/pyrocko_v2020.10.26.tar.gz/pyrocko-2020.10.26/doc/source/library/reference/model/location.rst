``model.location``
==================

.. automodule :: pyrocko.model.location
    :members:
