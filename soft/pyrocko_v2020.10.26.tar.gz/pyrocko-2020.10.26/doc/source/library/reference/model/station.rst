``model.station``
=================

.. automodule :: pyrocko.model.station
    :members:
