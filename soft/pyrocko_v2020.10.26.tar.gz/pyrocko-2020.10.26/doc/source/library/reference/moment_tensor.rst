``moment_tensor``
=================

.. automodule:: pyrocko.moment_tensor
    :members:
