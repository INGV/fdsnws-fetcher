Snuffler - *seismogram browser and workbench*
=============================================

Snuffler is a seismogram browser and workbench.

.. toctree::
   :maxdepth: 2

   manual
   tutorial
   extensions
