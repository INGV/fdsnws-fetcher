## Documentation Styleguide

Please follow this style guide when documenting `pyrocko`:

* Title style is __first-letter-capital__
* Reference modules/classes in *examples*

