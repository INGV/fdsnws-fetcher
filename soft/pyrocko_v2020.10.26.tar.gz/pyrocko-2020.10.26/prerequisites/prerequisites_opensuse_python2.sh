#!/bin/bash

sudo zypper -n install make git gcc python-devel python-setuptools \
    python-numpy python-numpy-devel python-scipy python-matplotlib \
    python-matplotlib-qt5 python-matplotlib-qt4 python-matplotlib-tk \
    python-qt5 python-qt4 \
    python-PyYAML python-progressbar python-Jinja2 \
    python-requests \
    python-nose python-coverage

