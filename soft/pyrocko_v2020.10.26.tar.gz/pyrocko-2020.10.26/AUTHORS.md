# The Pyrocko developers

This following list includes contributors how have directly touched code or documentation of Pyrocko. 
It is not a complete list, in the sense that many others have influenced the development of Pyrocko through discussion, bug reports and more.

* Sebastian Heimann
* Marius Kriegerowski
* Marius Isken
* Hannes Bathke
* Malte Metz
* Simone Cesca
* Simon Daout
* Francesco Grigoli
* Carina Juretzek
* Henning Lilienkamp
* Richard McGraw
* Tobias Megies
* Nima Nooshiri
* Gesa Petersen
* Andreas Steinberg
* Henriette Sudhaus
* Timothy Willey
* Thoralf Dietrich
* Torsten Dahm
